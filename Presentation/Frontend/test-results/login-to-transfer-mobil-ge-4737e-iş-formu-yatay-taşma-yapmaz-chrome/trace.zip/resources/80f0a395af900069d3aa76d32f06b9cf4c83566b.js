import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/contacts/components/copy-wallet-code-button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Check, Copy } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport2_react["useState"];
export function CopyWalletCodeButton({ code }) {
  _s();
  const [state, setState] = useState("idle");
  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setState("copied");
    } catch {
      setState("error");
    }
  };
  return /* @__PURE__ */ jsxDEV("span", { className: "copy-contact-wrap", children: [
    /* @__PURE__ */ jsxDEV("button", { className: "copy-contact-button", type: "button", onClick: () => void copyCode(), "aria-label": `${code} cüzdan kodunu kopyala`, children: [
      state === "copied" ? /* @__PURE__ */ jsxDEV(Check, { size: 16 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
        lineNumber: 19,
        columnNumber: 29
      }, this) : /* @__PURE__ */ jsxDEV(Copy, { size: 16 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
        lineNumber: 19,
        columnNumber: 51
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: state === "copied" ? "Kopyalandı" : "Kopyala" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
        lineNumber: 20,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
      lineNumber: 18,
      columnNumber: 5
    }, this),
    state === "error" && /* @__PURE__ */ jsxDEV("small", { role: "alert", children: "Kopyalanamadı" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
      lineNumber: 22,
      columnNumber: 27
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_s(CopyWalletCodeButton, "gMLLIQe6dQVAb09qOP2iVQXuaWg=");
_c = CopyWalletCodeButton;
var _c;
$RefreshReg$(_c, "CopyWalletCodeButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/copy-wallet-code-button.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0I0Qjs7QUFsQjVCLFNBQVNBLE9BQU9DLFlBQVk7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBR2xCLGdCQUFTQyxxQkFBcUIsRUFBRUMsS0FBdUIsR0FBRztBQUFBQyxLQUFBO0FBQy9ELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJTCxTQUFzQyxNQUFNO0FBRXRFLFFBQU1NLFdBQVcsWUFBWTtBQUMzQixRQUFJO0FBQ0YsWUFBTUMsVUFBVUMsVUFBVUMsVUFBVVAsSUFBSTtBQUN4Q0csZUFBUyxRQUFRO0FBQUEsSUFDbkIsUUFBUTtBQUNOQSxlQUFTLE9BQU87QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUFPLHVCQUFDLFVBQUssV0FBVSxxQkFDckI7QUFBQSwyQkFBQyxZQUFPLFdBQVUsdUJBQXNCLE1BQUssVUFBUyxTQUFTLE1BQU0sS0FBS0MsU0FBUyxHQUFHLGNBQVksR0FBR0osSUFBSSwwQkFDdEdFO0FBQUFBLGdCQUFVLFdBQVcsdUJBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQixJQUFNLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQzNELHVCQUFDLFVBQU1BLG9CQUFVLFdBQVcsZUFBZSxhQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsU0FGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQ0EsVUFBVSxXQUFXLHVCQUFDLFdBQU0sTUFBSyxTQUFRLDZCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsT0FMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1QO0FBQ0Y7QUFBQ0QsR0FuQmVGLHNCQUFvQjtBQUFBLEtBQXBCQTtBQUFvQixJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDaGVjayIsIkNvcHkiLCJ1c2VTdGF0ZSIsIkNvcHlXYWxsZXRDb2RlQnV0dG9uIiwiY29kZSIsIl9zIiwic3RhdGUiLCJzZXRTdGF0ZSIsImNvcHlDb2RlIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY29weS13YWxsZXQtY29kZS1idXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZWNrLCBDb3B5IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuLyoqIFNlw6dpbGVuIGtpxZ9pbmluIGPDvHpkYW4ga29kdW51IHBhbm95YSBrb3B5YWxhciB2ZSBzb251Y3UgYmlsZGlyaXIuICovXG5leHBvcnQgZnVuY3Rpb24gQ29weVdhbGxldENvZGVCdXR0b24oeyBjb2RlIH06IHsgY29kZTogc3RyaW5nIH0pIHtcbiAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZTwnaWRsZScgfCAnY29waWVkJyB8ICdlcnJvcic+KCdpZGxlJylcblxuICBjb25zdCBjb3B5Q29kZSA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoY29kZSlcbiAgICAgIHNldFN0YXRlKCdjb3BpZWQnKVxuICAgIH0gY2F0Y2gge1xuICAgICAgc2V0U3RhdGUoJ2Vycm9yJylcbiAgICB9XG4gIH1cblxuICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiY29weS1jb250YWN0LXdyYXBcIj5cbiAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNvcHktY29udGFjdC1idXR0b25cIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCBjb3B5Q29kZSgpfSBhcmlhLWxhYmVsPXtgJHtjb2RlfSBjw7x6ZGFuIGtvZHVudSBrb3B5YWxhYH0+XG4gICAgICB7c3RhdGUgPT09ICdjb3BpZWQnID8gPENoZWNrIHNpemU9ezE2fSAvPiA6IDxDb3B5IHNpemU9ezE2fSAvPn1cbiAgICAgIDxzcGFuPntzdGF0ZSA9PT0gJ2NvcGllZCcgPyAnS29weWFsYW5kxLEnIDogJ0tvcHlhbGEnfTwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgICB7c3RhdGUgPT09ICdlcnJvcicgJiYgPHNtYWxsIHJvbGU9XCJhbGVydFwiPktvcHlhbGFuYW1hZMSxPC9zbWFsbD59XG4gIDwvc3Bhbj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvY29udGFjdHMvY29tcG9uZW50cy9jb3B5LXdhbGxldC1jb2RlLWJ1dHRvbi50c3gifQ==