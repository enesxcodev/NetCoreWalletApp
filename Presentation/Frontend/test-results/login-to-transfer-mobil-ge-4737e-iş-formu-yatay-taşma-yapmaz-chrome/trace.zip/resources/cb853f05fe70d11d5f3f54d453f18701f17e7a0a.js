import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import { ApiError } from "/src/types/api.ts";
import { authToken } from "/src/lib/auth-token.ts";
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL ?? "http://localhost:5001").replace(/\/$/, "");
export async function apiRequest(path, options = {}) {
  const token = authToken.get();
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? "GET",
    headers: {
      ...options.body === void 0 ? {} : { "Content-Type": "application/json" },
      ...token ? { Authorization: `Bearer ${token}` } : {},
      ...options.headers
    },
    body: options.body === void 0 ? void 0 : JSON.stringify(options.body),
    signal: options.signal
  });
  const result = response.status === 204 ? null : await response.json().catch(() => null);
  if (response.status === 401) {
    authToken.clear();
    window.dispatchEvent(new Event("wallet:unauthorized"));
  }
  if (!response.ok || response.status !== 204 && (!result || result.isSuccess !== true)) {
    const message = result?.errors?.filter(Boolean).join(" ") || result?.error || "İşlem tamamlanamadı. Lütfen tekrar deneyin.";
    throw new ApiError(message, response.status);
  }
  return result?.data;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS1jbGllbnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBpRXJyb3IsIHR5cGUgQXBpUmVzdWx0IH0gZnJvbSAnLi4vdHlwZXMvYXBpJ1xuaW1wb3J0IHsgYXV0aFRva2VuIH0gZnJvbSAnLi9hdXRoLXRva2VuJ1xuXG5jb25zdCBBUElfQkFTRV9VUkwgPSAoaW1wb3J0Lm1ldGEuZW52LlZJVEVfQVBJX0JBU0VfVVJMID8/ICdodHRwOi8vbG9jYWxob3N0OjUwMDEnKS5yZXBsYWNlKC9cXC8kLywgJycpXG5cbi8qKiBBUEkgaXN0ZWtsZXJpbmkgb3J0YWsgYmFzZSBVUkwsIEpTT04gdmUgQmVhcmVyIGF5YXJsYXLEsXlsYSBnw7ZuZGVyaXIuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBpUmVxdWVzdDxUPihwYXRoOiBzdHJpbmcsIG9wdGlvbnM6IHsgbWV0aG9kPzogJ0dFVCcgfCAnUE9TVCc7IGJvZHk/OiB1bmtub3duOyBoZWFkZXJzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjsgc2lnbmFsPzogQWJvcnRTaWduYWwgfSA9IHt9KTogUHJvbWlzZTxUPiB7XG4gIGNvbnN0IHRva2VuID0gYXV0aFRva2VuLmdldCgpXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfSR7cGF0aH1gLCB7XG4gICAgbWV0aG9kOiBvcHRpb25zLm1ldGhvZCA/PyAnR0VUJyxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAuLi4ob3B0aW9ucy5ib2R5ID09PSB1bmRlZmluZWQgPyB7fSA6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9KSxcbiAgICAgIC4uLih0b2tlbiA/IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KSxcbiAgICAgIC4uLm9wdGlvbnMuaGVhZGVycyxcbiAgICB9LFxuICAgIGJvZHk6IG9wdGlvbnMuYm9keSA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogSlNPTi5zdHJpbmdpZnkob3B0aW9ucy5ib2R5KSxcbiAgICBzaWduYWw6IG9wdGlvbnMuc2lnbmFsLFxuICB9KVxuXG4gIGNvbnN0IHJlc3VsdCA9IHJlc3BvbnNlLnN0YXR1cyA9PT0gMjA0ID8gbnVsbCA6IChhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCkpIGFzIEFwaVJlc3VsdDxUPiB8IG51bGxcbiAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgYXV0aFRva2VuLmNsZWFyKClcbiAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoJ3dhbGxldDp1bmF1dGhvcml6ZWQnKSlcbiAgfVxuXG4gIGlmICghcmVzcG9uc2Uub2sgfHwgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMjA0ICYmICghcmVzdWx0IHx8IHJlc3VsdC5pc1N1Y2Nlc3MgIT09IHRydWUpKSkge1xuICAgIGNvbnN0IG1lc3NhZ2UgPSByZXN1bHQ/LmVycm9ycz8uZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyAnKSB8fCByZXN1bHQ/LmVycm9yIHx8ICfEsMWfbGVtIHRhbWFtbGFuYW1hZMSxLiBMw7x0ZmVuIHRla3JhciBkZW5leWluLidcbiAgICB0aHJvdyBuZXcgQXBpRXJyb3IobWVzc2FnZSwgcmVzcG9uc2Uuc3RhdHVzKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdD8uZGF0YSBhcyBUXG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsZ0JBQWdDO0FBQ3pDLFNBQVMsaUJBQWlCO0FBRTFCLE1BQU0sZ0JBQWdCLFlBQVksSUFBSSxxQkFBcUIseUJBQXlCLFFBQVEsT0FBTyxFQUFFO0FBR3JHLHNCQUFzQixXQUFjLE1BQWMsVUFBK0csQ0FBQyxHQUFlO0FBQy9LLFFBQU0sUUFBUSxVQUFVLElBQUk7QUFDNUIsUUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLFlBQVksR0FBRyxJQUFJLElBQUk7QUFBQSxJQUNyRCxRQUFRLFFBQVEsVUFBVTtBQUFBLElBQzFCLFNBQVM7QUFBQSxNQUNQLEdBQUksUUFBUSxTQUFTLFNBQVksQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLE1BQzNFLEdBQUksUUFBUSxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUcsSUFBSSxDQUFDO0FBQUEsTUFDcEQsR0FBRyxRQUFRO0FBQUEsSUFDYjtBQUFBLElBQ0EsTUFBTSxRQUFRLFNBQVMsU0FBWSxTQUFZLEtBQUssVUFBVSxRQUFRLElBQUk7QUFBQSxJQUMxRSxRQUFRLFFBQVE7QUFBQSxFQUNsQixDQUFDO0FBRUQsUUFBTSxTQUFTLFNBQVMsV0FBVyxNQUFNLE9BQVEsTUFBTSxTQUFTLEtBQUssRUFBRSxNQUFNLE1BQU0sSUFBSTtBQUN2RixNQUFJLFNBQVMsV0FBVyxLQUFLO0FBQzNCLGNBQVUsTUFBTTtBQUNoQixXQUFPLGNBQWMsSUFBSSxNQUFNLHFCQUFxQixDQUFDO0FBQUEsRUFDdkQ7QUFFQSxNQUFJLENBQUMsU0FBUyxNQUFPLFNBQVMsV0FBVyxRQUFRLENBQUMsVUFBVSxPQUFPLGNBQWMsT0FBUTtBQUN2RixVQUFNLFVBQVUsUUFBUSxRQUFRLE9BQU8sT0FBTyxFQUFFLEtBQUssR0FBRyxLQUFLLFFBQVEsU0FBUztBQUM5RSxVQUFNLElBQUksU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUFBLEVBQzdDO0FBRUEsU0FBTyxRQUFRO0FBQ2pCOyIsIm5hbWVzIjpbXX0=