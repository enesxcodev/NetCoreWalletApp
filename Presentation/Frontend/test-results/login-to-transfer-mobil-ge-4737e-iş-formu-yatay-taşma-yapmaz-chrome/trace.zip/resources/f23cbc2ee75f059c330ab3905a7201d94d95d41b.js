import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=88909849"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { AppProviders } from "/src/app/app-providers.tsx";
import { AppRouter } from "/src/app/app-router.tsx";
import { ErrorBoundary } from "/src/app/error-boundary.tsx";
import "/src/styles/global.css";
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ jsxDEV(AppProviders, { children: /* @__PURE__ */ jsxDEV(AppRouter, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/main.tsx",
    lineNumber: 11,
    columnNumber: 21
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/main.tsx",
    lineNumber: 11,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/main.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/main.tsx",
    lineNumber: 9,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVW9CO0FBVnBCLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHFCQUFxQjtBQUM5QixPQUFPO0FBRVBILFNBQVNJLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFFLEVBQUVDO0FBQUFBLEVBQ3BELHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLGlCQUNDLGlDQUFDLGdCQUFhLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFVLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQXBwUHJvdmlkZXJzIiwiQXBwUm91dGVyIiwiRXJyb3JCb3VuZGFyeSIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IHsgQXBwUHJvdmlkZXJzIH0gZnJvbSAnLi9hcHAvYXBwLXByb3ZpZGVycydcbmltcG9ydCB7IEFwcFJvdXRlciB9IGZyb20gJy4vYXBwL2FwcC1yb3V0ZXInXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAnLi9hcHAvZXJyb3ItYm91bmRhcnknXG5pbXBvcnQgJy4vc3R5bGVzL2dsb2JhbC5jc3MnXG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcbiAgPFJlYWN0LlN0cmljdE1vZGU+XG4gICAgPEVycm9yQm91bmRhcnk+XG4gICAgICA8QXBwUHJvdmlkZXJzPjxBcHBSb3V0ZXIgLz48L0FwcFByb3ZpZGVycz5cbiAgICA8L0Vycm9yQm91bmRhcnk+XG4gIDwvUmVhY3QuU3RyaWN0TW9kZT4sXG4pXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL21haW4udHN4In0=