import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/app-router.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { DashboardLayout } from "/src/layouts/dashboard-layout.tsx";
import { LoginPage } from "/src/features/auth/pages/login-page.tsx";
import { RegisterPage } from "/src/features/auth/pages/register-page.tsx";
import { DashboardPage } from "/src/features/wallet/pages/dashboard-page.tsx";
import { MoneyPage } from "/src/features/wallet/pages/money-page.tsx";
import { TransferPage } from "/src/features/transfer/transfer-page.tsx";
import { TransactionsPage } from "/src/features/transactions/transactions-page.tsx";
import { ContactsPage } from "/src/features/contacts/contacts-page.tsx";
import { ArchitecturePage } from "/src/features/architecture/architecture-page.tsx";
import { NotFoundPage } from "/src/features/not-found/not-found-page.tsx";
import { ProtectedRoute, PublicOnlyRoute } from "/src/routes/route-guards.tsx";
export function AppRouter() {
  return /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PublicOnlyRoute, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 18,
      columnNumber: 23
    }, this), children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 19,
        columnNumber: 39
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/register", element: /* @__PURE__ */ jsxDEV(RegisterPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 20,
        columnNumber: 42
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(ProtectedRoute, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 22,
      columnNumber: 23
    }, this), children: /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(DashboardLayout, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 23,
      columnNumber: 25
    }, this), children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/dashboard", element: /* @__PURE__ */ jsxDEV(DashboardPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 24,
        columnNumber: 45
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 24,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/deposit", element: /* @__PURE__ */ jsxDEV(MoneyPage, { action: "deposit" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 25,
        columnNumber: 43
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 25,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/withdraw", element: /* @__PURE__ */ jsxDEV(MoneyPage, { action: "withdraw" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 26,
        columnNumber: 44
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/transfer", element: /* @__PURE__ */ jsxDEV(TransferPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 27,
        columnNumber: 44
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/transactions", element: /* @__PURE__ */ jsxDEV(TransactionsPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 28,
        columnNumber: 48
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 28,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/contacts", element: /* @__PURE__ */ jsxDEV(ContactsPage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 29,
        columnNumber: 44
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 29,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/architecture", element: /* @__PURE__ */ jsxDEV(ArchitecturePage, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 30,
        columnNumber: 48
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard", replace: true }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 33,
      columnNumber: 32
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(NotFoundPage, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 34,
      columnNumber: 32
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_c = AppRouter;
var _c;
$RefreshReg$(_c, "AppRouter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-router.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJzQjtBQWpCdEIsU0FBU0EsVUFBVUMsT0FBT0MsY0FBYztBQUN4QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCQyx1QkFBdUI7QUFHekMsZ0JBQVNDLFlBQVk7QUFDMUIsU0FDRSx1QkFBQyxVQUNDO0FBQUEsMkJBQUMsU0FBTSxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsR0FDOUI7QUFBQSw2QkFBQyxTQUFNLE1BQUssVUFBUyxTQUFTLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxNQUM1Qyx1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYSxLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsU0FGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEdBQzdCLGlDQUFDLFNBQU0sU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCLEdBQzlCO0FBQUEsNkJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLE1BQ3BELHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsYUFBVSxRQUFPLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQy9ELHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsYUFBVSxRQUFPLGNBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEIsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2pFLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxNQUNsRCx1QkFBQyxTQUFNLE1BQUssaUJBQWdCLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFDMUQsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWEsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xELHVCQUFDLFNBQU0sTUFBSyxpQkFBZ0IsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxTQVA1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBUyxJQUFHLGNBQWEsU0FBTyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxJQUM5RCx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYSxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsT0FqQjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDQyxLQXRCZUQ7QUFBUyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsIlJvdXRlIiwiUm91dGVzIiwiRGFzaGJvYXJkTGF5b3V0IiwiTG9naW5QYWdlIiwiUmVnaXN0ZXJQYWdlIiwiRGFzaGJvYXJkUGFnZSIsIk1vbmV5UGFnZSIsIlRyYW5zZmVyUGFnZSIsIlRyYW5zYWN0aW9uc1BhZ2UiLCJDb250YWN0c1BhZ2UiLCJBcmNoaXRlY3R1cmVQYWdlIiwiTm90Rm91bmRQYWdlIiwiUHJvdGVjdGVkUm91dGUiLCJQdWJsaWNPbmx5Um91dGUiLCJBcHBSb3V0ZXIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhcHAtcm91dGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZpZ2F0ZSwgUm91dGUsIFJvdXRlcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBEYXNoYm9hcmRMYXlvdXQgfSBmcm9tICcuLi9sYXlvdXRzL2Rhc2hib2FyZC1sYXlvdXQnXG5pbXBvcnQgeyBMb2dpblBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hdXRoL3BhZ2VzL2xvZ2luLXBhZ2UnXG5pbXBvcnQgeyBSZWdpc3RlclBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hdXRoL3BhZ2VzL3JlZ2lzdGVyLXBhZ2UnXG5pbXBvcnQgeyBEYXNoYm9hcmRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvd2FsbGV0L3BhZ2VzL2Rhc2hib2FyZC1wYWdlJ1xuaW1wb3J0IHsgTW9uZXlQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvd2FsbGV0L3BhZ2VzL21vbmV5LXBhZ2UnXG5pbXBvcnQgeyBUcmFuc2ZlclBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy90cmFuc2Zlci90cmFuc2Zlci1wYWdlJ1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMtcGFnZSdcbmltcG9ydCB7IENvbnRhY3RzUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvbnRhY3RzL2NvbnRhY3RzLXBhZ2UnXG5pbXBvcnQgeyBBcmNoaXRlY3R1cmVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXJjaGl0ZWN0dXJlL2FyY2hpdGVjdHVyZS1wYWdlJ1xuaW1wb3J0IHsgTm90Rm91bmRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbm90LWZvdW5kL25vdC1mb3VuZC1wYWdlJ1xuaW1wb3J0IHsgUHJvdGVjdGVkUm91dGUsIFB1YmxpY09ubHlSb3V0ZSB9IGZyb20gJy4uL3JvdXRlcy9yb3V0ZS1ndWFyZHMnXG5cbi8qKiBVeWd1bGFtYW7EsW4gYcOnxLFrLCBrb3J1bWFsxLEgdmUgYnVsdW5hbWF5YW4gc2F5ZmFsYXLEsW7EsSBlxZ9sZXIuICovXG5leHBvcnQgZnVuY3Rpb24gQXBwUm91dGVyKCkge1xuICByZXR1cm4gKFxuICAgIDxSb3V0ZXM+XG4gICAgICA8Um91dGUgZWxlbWVudD17PFB1YmxpY09ubHlSb3V0ZSAvPn0+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PExvZ2luUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBlbGVtZW50PXs8UmVnaXN0ZXJQYWdlIC8+fSAvPlxuICAgICAgPC9Sb3V0ZT5cbiAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGUgLz59PlxuICAgICAgICA8Um91dGUgZWxlbWVudD17PERhc2hib2FyZExheW91dCAvPn0+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZGFzaGJvYXJkXCIgZWxlbWVudD17PERhc2hib2FyZFBhZ2UgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZGVwb3NpdFwiIGVsZW1lbnQ9ezxNb25leVBhZ2UgYWN0aW9uPVwiZGVwb3NpdFwiIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3dpdGhkcmF3XCIgZWxlbWVudD17PE1vbmV5UGFnZSBhY3Rpb249XCJ3aXRoZHJhd1wiIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3RyYW5zZmVyXCIgZWxlbWVudD17PFRyYW5zZmVyUGFnZSAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi90cmFuc2FjdGlvbnNcIiBlbGVtZW50PXs8VHJhbnNhY3Rpb25zUGFnZSAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jb250YWN0c1wiIGVsZW1lbnQ9ezxDb250YWN0c1BhZ2UgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvYXJjaGl0ZWN0dXJlXCIgZWxlbWVudD17PEFyY2hpdGVjdHVyZVBhZ2UgLz59IC8+XG4gICAgICAgIDwvUm91dGU+XG4gICAgICA8L1JvdXRlPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8Tm90Rm91bmRQYWdlIC8+fSAvPlxuICAgIDwvUm91dGVzPlxuICApXG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2FwcC9hcHAtcm91dGVyLnRzeCJ9