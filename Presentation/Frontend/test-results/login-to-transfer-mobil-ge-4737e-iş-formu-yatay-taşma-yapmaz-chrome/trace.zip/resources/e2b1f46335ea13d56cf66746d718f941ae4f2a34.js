import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/dashboard-layout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Activity, ArrowDownLeft, ArrowRightFromLine, ArrowUpRight, History, LayoutDashboard, Menu, Send, UsersRound, WalletCards } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { NavLink, Outlet, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { useAuth } from "/src/app/auth-context.tsx";
import { NetworkStatusBanner } from "/src/components/network-status-banner.tsx";
export function DashboardLayout() {
  _s();
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const logout = () => {
    signOut();
    navigate("/login", { replace: true });
  };
  const pageTitle = {
    "/dashboard": "Genel bakış",
    "/deposit": "Para yatır",
    "/withdraw": "Para çek",
    "/transfer": "Transfer",
    "/transactions": "İşlem geçmişi",
    "/contacts": "Transfer Kişileri",
    "/architecture": "Mimari akış"
  };
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);
  return /* @__PURE__ */ jsxDEV("div", { className: "dashboard-shell", children: [
    /* @__PURE__ */ jsxDEV("aside", { id: "dashboard-navigation", className: `dashboard-sidebar ${menuOpen ? "sidebar-open" : ""}`, "aria-label": "Ana menü", children: [
      /* @__PURE__ */ jsxDEV("a", { className: "brand dashboard-brand", href: "/dashboard", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "brand-mark", children: /* @__PURE__ */ jsxDEV(WalletCards, { size: 22 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 23,
          columnNumber: 93
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 23,
          columnNumber: 64
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Wallet" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 23,
            columnNumber: 131
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Dijital Cüzdan" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 23,
            columnNumber: 154
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 23,
          columnNumber: 125
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "nav-caption", children: "MENÜ" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/dashboard", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(LayoutDashboard, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 25,
          columnNumber: 148
        }, this),
        " Genel bakış"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/deposit", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(ArrowDownLeft, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 26,
          columnNumber: 146
        }, this),
        " Para yatır"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/withdraw", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 27,
          columnNumber: 147
        }, this),
        " Para çek"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 27,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/transfer", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(Send, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 28,
          columnNumber: 147
        }, this),
        " Transfer"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/transactions", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(History, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 29,
          columnNumber: 151
        }, this),
        " İşlem geçmişi"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/contacts", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(UsersRound, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 30,
          columnNumber: 147
        }, this),
        " Transfer Kişileri"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { className: ({ isActive }) => `dashboard-nav-link ${isActive ? "active" : ""}`, to: "/architecture", onClick: () => setMenuOpen(false), children: [
        /* @__PURE__ */ jsxDEV(Activity, { size: 18 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 31,
          columnNumber: 151
        }, this),
        " Mimari akış"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sidebar-bottom", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "logout-button", type: "button", onClick: logout, children: [
          /* @__PURE__ */ jsxDEV(ArrowRightFromLine, { size: 18 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 32,
            columnNumber: 106
          }, this),
          " Güvenli çıkış"
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 32,
          columnNumber: 41
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Wallet · Güvenli cüzdanınız" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 32,
          columnNumber: 161
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "dashboard-main", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "dashboard-topbar", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "menu-toggle", type: "button", "aria-controls": "dashboard-navigation", "aria-expanded": menuOpen, "aria-label": menuOpen ? "Menüyü kapat" : "Menüyü aç", onClick: () => setMenuOpen((open) => !open), children: /* @__PURE__ */ jsxDEV(Menu, { size: 21 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 35,
          columnNumber: 252
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 35,
          columnNumber: 46
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Wallet ",
          /* @__PURE__ */ jsxDEV("span", { className: "breadcrumb-separator", children: "/" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 35,
            columnNumber: 292
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("strong", { children: pageTitle[location.pathname] ?? "Sayfa" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 35,
            columnNumber: 340
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 35,
          columnNumber: 279
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "secure-badge", children: [
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
            lineNumber: 35,
            columnNumber: 436
          }, this),
          " Güvenli oturum"
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
          lineNumber: 35,
          columnNumber: 405
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NetworkStatusBanner, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "dashboard-content", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 37,
        columnNumber: 45
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_s(DashboardLayout, "4WViQre1t7N9Ia+5aMxLUCB6nmo=", false, function() {
  return [useAuth, useNavigate, useLocation];
});
_c = DashboardLayout;
var _c;
$RefreshReg$(_c, "DashboardLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/dashboard-layout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0I0Rjs7QUF0QjVGLFNBQVNBLFVBQVVDLGVBQWVDLG9CQUFvQkMsY0FBY0MsU0FBU0MsaUJBQWlCQyxNQUFNQyxNQUFNQyxZQUFZQyxtQkFBbUI7QUFDekksU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQ3BDLFNBQVNDLFNBQVNDLFFBQVFDLGFBQWFDLG1CQUFtQjtBQUMxRCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLDJCQUEyQjtBQUc3QixnQkFBU0Msa0JBQWtCO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxRQUFRLElBQUlKLFFBQVE7QUFDNUIsUUFBTUssV0FBV04sWUFBWTtBQUM3QixRQUFNTyxXQUFXUixZQUFZO0FBQzdCLFFBQU0sQ0FBQ1MsVUFBVUMsV0FBVyxJQUFJYixTQUFTLEtBQUs7QUFDOUMsUUFBTWMsU0FBU0EsTUFBTTtBQUFFTCxZQUFRO0FBQUdDLGFBQVMsVUFBVSxFQUFFSyxTQUFTLEtBQUssQ0FBQztBQUFBLEVBQUU7QUFDeEUsUUFBTUMsWUFBb0M7QUFBQSxJQUN4QyxjQUFjO0FBQUEsSUFBZSxZQUFZO0FBQUEsSUFBYyxhQUFhO0FBQUEsSUFDcEUsYUFBYTtBQUFBLElBQVksaUJBQWlCO0FBQUEsSUFBaUIsYUFBYTtBQUFBLElBQXFCLGlCQUFpQjtBQUFBLEVBQ2hIO0FBQ0FqQixZQUFVLE1BQU07QUFBRWMsZ0JBQVksS0FBSztBQUFBLEVBQUUsR0FBRyxDQUFDRixTQUFTTSxRQUFRLENBQUM7QUFFM0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQkFBQyxXQUFNLElBQUcsd0JBQXVCLFdBQVcscUJBQXFCTCxXQUFXLGlCQUFpQixFQUFFLElBQUksY0FBVyxZQUM1RztBQUFBLDZCQUFDLE9BQUUsV0FBVSx5QkFBd0IsTUFBSyxjQUFhO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGNBQWEsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0IsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQU8sdUJBQUMsVUFBSztBQUFBLGlDQUFDLFlBQU8sc0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLFVBQVMsdUJBQUMsV0FBTSw4QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQjtBQUFBLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxXQUE5SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFMO0FBQUEsTUFDckwsdUJBQUMsT0FBRSxXQUFVLGVBQWMsb0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUMvQix1QkFBQyxXQUFRLFdBQVcsQ0FBQyxFQUFFTSxTQUFTLE1BQU0sc0JBQXNCQSxXQUFXLFdBQVcsRUFBRSxJQUFJLElBQUcsY0FBYSxTQUFTLE1BQU1MLFlBQVksS0FBSyxHQUFHO0FBQUEsK0JBQUMsbUJBQWdCLE1BQU0sTUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQUc7QUFBQSxXQUF4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9MO0FBQUEsTUFDcEwsdUJBQUMsV0FBUSxXQUFXLENBQUMsRUFBRUssU0FBUyxNQUFNLHNCQUFzQkEsV0FBVyxXQUFXLEVBQUUsSUFBSSxJQUFHLFlBQVcsU0FBUyxNQUFNTCxZQUFZLEtBQUssR0FBRztBQUFBLCtCQUFDLGlCQUFjLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQUc7QUFBQSxXQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStLO0FBQUEsTUFDL0ssdUJBQUMsV0FBUSxXQUFXLENBQUMsRUFBRUssU0FBUyxNQUFNLHNCQUFzQkEsV0FBVyxXQUFXLEVBQUUsSUFBSSxJQUFHLGFBQVksU0FBUyxNQUFNTCxZQUFZLEtBQUssR0FBRztBQUFBLCtCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFFBQUc7QUFBQSxXQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZLO0FBQUEsTUFDN0ssdUJBQUMsV0FBUSxXQUFXLENBQUMsRUFBRUssU0FBUyxNQUFNLHNCQUFzQkEsV0FBVyxXQUFXLEVBQUUsSUFBSSxJQUFHLGFBQVksU0FBUyxNQUFNTCxZQUFZLEtBQUssR0FBRztBQUFBLCtCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBQUc7QUFBQSxXQUE1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFLO0FBQUEsTUFDckssdUJBQUMsV0FBUSxXQUFXLENBQUMsRUFBRUssU0FBUyxNQUFNLHNCQUFzQkEsV0FBVyxXQUFXLEVBQUUsSUFBSSxJQUFHLGlCQUFnQixTQUFTLE1BQU1MLFlBQVksS0FBSyxHQUFHO0FBQUEsK0JBQUMsV0FBUSxNQUFNLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQjtBQUFBLFFBQUc7QUFBQSxXQUFuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlMO0FBQUEsTUFDakwsdUJBQUMsV0FBUSxXQUFXLENBQUMsRUFBRUssU0FBUyxNQUFNLHNCQUFzQkEsV0FBVyxXQUFXLEVBQUUsSUFBSSxJQUFHLGFBQVksU0FBUyxNQUFNTCxZQUFZLEtBQUssR0FBRztBQUFBLCtCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFBRztBQUFBLFdBQWxLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0w7QUFBQSxNQUNwTCx1QkFBQyxXQUFRLFdBQVcsQ0FBQyxFQUFFSyxTQUFTLE1BQU0sc0JBQXNCQSxXQUFXLFdBQVcsRUFBRSxJQUFJLElBQUcsaUJBQWdCLFNBQVMsTUFBTUwsWUFBWSxLQUFLLEdBQUc7QUFBQSwrQkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQUc7QUFBQSxXQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdMO0FBQUEsTUFDaEwsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQjtBQUFBLCtCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsTUFBSyxVQUFTLFNBQVNDLFFBQVE7QUFBQSxpQ0FBQyxzQkFBbUIsTUFBTSxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQUc7QUFBQSxhQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStHO0FBQUEsUUFBUyx1QkFBQyxPQUFFLDJDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxXQUF0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBMO0FBQUEsU0FWNUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxZQUFPLFdBQVUsb0JBQW1CO0FBQUEsK0JBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUFTLGlCQUFjLHdCQUF1QixpQkFBZUYsVUFBVSxjQUFZQSxXQUFXLGlCQUFpQixhQUFhLFNBQVMsTUFBTUMsWUFBWSxDQUFDTSxTQUFTLENBQUNBLElBQUksR0FBRyxpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FBN047QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnTztBQUFBLFFBQVMsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBTyx1QkFBQyxVQUFLLFdBQVUsd0JBQXVCLGlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFlBQVFILG9CQUFVTCxTQUFTTSxRQUFRLEtBQUssV0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxhQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVIO0FBQUEsUUFBTyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUs7QUFBQSxVQUFHO0FBQUEsYUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFdBQWxjO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeWM7QUFBQSxNQUN6Yyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEIsdUJBQUMsVUFBSyxXQUFVLHFCQUFvQixpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTyxLQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsU0FIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVKO0FBQUNULEdBakNlRCxpQkFBZTtBQUFBLFVBQ1RGLFNBQ0hELGFBQ0FELFdBQVc7QUFBQTtBQUFBLEtBSGRJO0FBQWUsSUFBQWE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQWN0aXZpdHkiLCJBcnJvd0Rvd25MZWZ0IiwiQXJyb3dSaWdodEZyb21MaW5lIiwiQXJyb3dVcFJpZ2h0IiwiSGlzdG9yeSIsIkxheW91dERhc2hib2FyZCIsIk1lbnUiLCJTZW5kIiwiVXNlcnNSb3VuZCIsIldhbGxldENhcmRzIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJOYXZMaW5rIiwiT3V0bGV0IiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJOZXR3b3JrU3RhdHVzQmFubmVyIiwiRGFzaGJvYXJkTGF5b3V0IiwiX3MiLCJzaWduT3V0IiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsIm1lbnVPcGVuIiwic2V0TWVudU9wZW4iLCJsb2dvdXQiLCJyZXBsYWNlIiwicGFnZVRpdGxlIiwicGF0aG5hbWUiLCJpc0FjdGl2ZSIsIm9wZW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJkYXNoYm9hcmQtbGF5b3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpdml0eSwgQXJyb3dEb3duTGVmdCwgQXJyb3dSaWdodEZyb21MaW5lLCBBcnJvd1VwUmlnaHQsIEhpc3RvcnksIExheW91dERhc2hib2FyZCwgTWVudSwgU2VuZCwgVXNlcnNSb3VuZCwgV2FsbGV0Q2FyZHMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBOYXZMaW5rLCBPdXRsZXQsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vYXBwL2F1dGgtY29udGV4dCdcbmltcG9ydCB7IE5ldHdvcmtTdGF0dXNCYW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL25ldHdvcmstc3RhdHVzLWJhbm5lcidcblxuLyoqIEtvcnVtYWzEsSBzYXlmYWxhciBpw6dpbiByZXNwb25zaXZlIGdlemludGkgdmUgacOnZXJpayBhbGFuxLEgc2HEn2xhci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBEYXNoYm9hcmRMYXlvdXQoKSB7XG4gIGNvbnN0IHsgc2lnbk91dCB9ID0gdXNlQXV0aCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgbG9nb3V0ID0gKCkgPT4geyBzaWduT3V0KCk7IG5hdmlnYXRlKCcvbG9naW4nLCB7IHJlcGxhY2U6IHRydWUgfSkgfVxuICBjb25zdCBwYWdlVGl0bGU6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgJy9kYXNoYm9hcmQnOiAnR2VuZWwgYmFrxLHFnycsICcvZGVwb3NpdCc6ICdQYXJhIHlhdMSxcicsICcvd2l0aGRyYXcnOiAnUGFyYSDDp2VrJyxcbiAgICAnL3RyYW5zZmVyJzogJ1RyYW5zZmVyJywgJy90cmFuc2FjdGlvbnMnOiAnxLDFn2xlbSBnZcOnbWnFn2knLCAnL2NvbnRhY3RzJzogJ1RyYW5zZmVyIEtpxZ9pbGVyaScsICcvYXJjaGl0ZWN0dXJlJzogJ01pbWFyaSBha8SxxZ8nLFxuICB9XG4gIHVzZUVmZmVjdCgoKSA9PiB7IHNldE1lbnVPcGVuKGZhbHNlKSB9LCBbbG9jYXRpb24ucGF0aG5hbWVdKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2hlbGxcIj5cbiAgICAgIDxhc2lkZSBpZD1cImRhc2hib2FyZC1uYXZpZ2F0aW9uXCIgY2xhc3NOYW1lPXtgZGFzaGJvYXJkLXNpZGViYXIgJHttZW51T3BlbiA/ICdzaWRlYmFyLW9wZW4nIDogJyd9YH0gYXJpYS1sYWJlbD1cIkFuYSBtZW7DvFwiPlxuICAgICAgICA8YSBjbGFzc05hbWU9XCJicmFuZCBkYXNoYm9hcmQtYnJhbmRcIiBocmVmPVwiL2Rhc2hib2FyZFwiPjxzcGFuIGNsYXNzTmFtZT1cImJyYW5kLW1hcmtcIj48V2FsbGV0Q2FyZHMgc2l6ZT17MjJ9IC8+PC9zcGFuPjxzcGFuPjxzdHJvbmc+V2FsbGV0PC9zdHJvbmc+PHNtYWxsPkRpaml0YWwgQ8O8emRhbjwvc21hbGw+PC9zcGFuPjwvYT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibmF2LWNhcHRpb25cIj5NRU7DnDwvcD5cbiAgICAgICAgPE5hdkxpbmsgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PiBgZGFzaGJvYXJkLW5hdi1saW5rICR7aXNBY3RpdmUgPyAnYWN0aXZlJyA6ICcnfWB9IHRvPVwiL2Rhc2hib2FyZFwiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+PExheW91dERhc2hib2FyZCBzaXplPXsxOH0gLz4gR2VuZWwgYmFrxLHFnzwvTmF2TGluaz5cbiAgICAgICAgPE5hdkxpbmsgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PiBgZGFzaGJvYXJkLW5hdi1saW5rICR7aXNBY3RpdmUgPyAnYWN0aXZlJyA6ICcnfWB9IHRvPVwiL2RlcG9zaXRcIiBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbihmYWxzZSl9PjxBcnJvd0Rvd25MZWZ0IHNpemU9ezE4fSAvPiBQYXJhIHlhdMSxcjwvTmF2TGluaz5cbiAgICAgICAgPE5hdkxpbmsgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PiBgZGFzaGJvYXJkLW5hdi1saW5rICR7aXNBY3RpdmUgPyAnYWN0aXZlJyA6ICcnfWB9IHRvPVwiL3dpdGhkcmF3XCIgb25DbGljaz17KCkgPT4gc2V0TWVudU9wZW4oZmFsc2UpfT48QXJyb3dVcFJpZ2h0IHNpemU9ezE4fSAvPiBQYXJhIMOnZWs8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT4gYGRhc2hib2FyZC1uYXYtbGluayAke2lzQWN0aXZlID8gJ2FjdGl2ZScgOiAnJ31gfSB0bz1cIi90cmFuc2ZlclwiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+PFNlbmQgc2l6ZT17MTh9IC8+IFRyYW5zZmVyPC9OYXZMaW5rPlxuICAgICAgICA8TmF2TGluayBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+IGBkYXNoYm9hcmQtbmF2LWxpbmsgJHtpc0FjdGl2ZSA/ICdhY3RpdmUnIDogJyd9YH0gdG89XCIvdHJhbnNhY3Rpb25zXCIgb25DbGljaz17KCkgPT4gc2V0TWVudU9wZW4oZmFsc2UpfT48SGlzdG9yeSBzaXplPXsxOH0gLz4gxLDFn2xlbSBnZcOnbWnFn2k8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT4gYGRhc2hib2FyZC1uYXYtbGluayAke2lzQWN0aXZlID8gJ2FjdGl2ZScgOiAnJ31gfSB0bz1cIi9jb250YWN0c1wiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+PFVzZXJzUm91bmQgc2l6ZT17MTh9IC8+IFRyYW5zZmVyIEtpxZ9pbGVyaTwvTmF2TGluaz5cbiAgICAgICAgPE5hdkxpbmsgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PiBgZGFzaGJvYXJkLW5hdi1saW5rICR7aXNBY3RpdmUgPyAnYWN0aXZlJyA6ICcnfWB9IHRvPVwiL2FyY2hpdGVjdHVyZVwiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+PEFjdGl2aXR5IHNpemU9ezE4fSAvPiBNaW1hcmkgYWvEscWfPC9OYXZMaW5rPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItYm90dG9tXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJsb2dvdXQtYnV0dG9uXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2xvZ291dH0+PEFycm93UmlnaHRGcm9tTGluZSBzaXplPXsxOH0gLz4gR8O8dmVubGkgw6fEsWvEscWfPC9idXR0b24+PHA+V2FsbGV0IMK3IEfDvHZlbmxpIGPDvHpkYW7EsW7EsXo8L3A+PC9kaXY+XG4gICAgICA8L2FzaWRlPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtbWFpblwiPlxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImRhc2hib2FyZC10b3BiYXJcIj48YnV0dG9uIGNsYXNzTmFtZT1cIm1lbnUtdG9nZ2xlXCIgdHlwZT1cImJ1dHRvblwiIGFyaWEtY29udHJvbHM9XCJkYXNoYm9hcmQtbmF2aWdhdGlvblwiIGFyaWEtZXhwYW5kZWQ9e21lbnVPcGVufSBhcmlhLWxhYmVsPXttZW51T3BlbiA/ICdNZW7DvHnDvCBrYXBhdCcgOiAnTWVuw7x5w7wgYcOnJ30gb25DbGljaz17KCkgPT4gc2V0TWVudU9wZW4oKG9wZW4pID0+ICFvcGVuKX0+PE1lbnUgc2l6ZT17MjF9IC8+PC9idXR0b24+PHNwYW4+V2FsbGV0IDxzcGFuIGNsYXNzTmFtZT1cImJyZWFkY3J1bWItc2VwYXJhdG9yXCI+Lzwvc3Bhbj4gPHN0cm9uZz57cGFnZVRpdGxlW2xvY2F0aW9uLnBhdGhuYW1lXSA/PyAnU2F5ZmEnfTwvc3Ryb25nPjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJzZWN1cmUtYmFkZ2VcIj48c3BhbiAvPiBHw7x2ZW5saSBvdHVydW08L3NwYW4+PC9oZWFkZXI+XG4gICAgICAgIDxOZXR3b3JrU3RhdHVzQmFubmVyIC8+XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImRhc2hib2FyZC1jb250ZW50XCI+PE91dGxldCAvPjwvbWFpbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2xheW91dHMvZGFzaGJvYXJkLWxheW91dC50c3gifQ==