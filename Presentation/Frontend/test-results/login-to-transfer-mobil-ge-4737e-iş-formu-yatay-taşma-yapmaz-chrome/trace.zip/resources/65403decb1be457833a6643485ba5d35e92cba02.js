import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transactions/transactions-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ChevronLeft, ChevronRight, X } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"]; const useState = __vite__cjsImport2_react["useState"];
import { QueryError, QuerySkeleton } from "/src/components/query-state.tsx";
import { formatDate, formatMoney } from "/src/lib/format.ts";
import { TransactionList } from "/src/features/transactions/components/transaction-list.tsx";
import { useTransactions } from "/src/features/transactions/hooks.ts";
const PAGE_SIZE = 10;
export function TransactionsPage() {
  _s();
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);
  const closeButton = useRef(null);
  const history = useTransactions(page, PAGE_SIZE);
  useEffect(() => {
    if (!selected) return;
    closeButton.current?.focus();
    const onKeyDown = (event) => {
      if (event.key === "Escape") setSelected(null);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [selected]);
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "HESAP HAREKETLERİ" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 24,
        columnNumber: 74
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: "İşlem geçmişi" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 24,
        columnNumber: 128
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Gelen ve giden transferlerinizi görüntüleyin." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 24,
        columnNumber: 150
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
      lineNumber: 24,
      columnNumber: 41
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "content-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Tüm transferler" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 24,
          columnNumber: 286
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "En yeni işlemler önce gösterilir." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 24,
          columnNumber: 310
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 24,
        columnNumber: 281
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 24,
        columnNumber: 248
      }, this),
      history.isPending ? /* @__PURE__ */ jsxDEV(QuerySkeleton, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 25,
        columnNumber: 26
      }, this) : history.isError ? /* @__PURE__ */ jsxDEV(QueryError, { retry: () => void history.refetch() }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 25,
        columnNumber: 64
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(TransactionList, { items: history.data, onSelect: setSelected }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 25,
          columnNumber: 120
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pagination", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
            setPage(page - 1);
            setSelected(null);
          }, disabled: page === 1, children: [
            /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
              fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
              lineNumber: 25,
              columnNumber: 310
            }, this),
            " Önceki"
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 25,
            columnNumber: 211
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Sayfa ",
            page
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 25,
            columnNumber: 351
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
            setPage(page + 1);
            setSelected(null);
          }, disabled: history.data.length < PAGE_SIZE, children: [
            "Sonraki ",
            /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
              fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
              lineNumber: 25,
              columnNumber: 504
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 25,
            columnNumber: 376
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 25,
          columnNumber: 183
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 25,
        columnNumber: 118
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
      lineNumber: 24,
      columnNumber: 211
    }, this),
    selected && /* @__PURE__ */ jsxDEV("div", { className: "detail-backdrop", onClick: () => setSelected(null), children: /* @__PURE__ */ jsxDEV("section", { className: "detail-panel", role: "dialog", "aria-modal": "true", "aria-labelledby": "detail-title", onClick: (event) => event.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("button", { ref: closeButton, className: "detail-close", type: "button", onClick: () => setSelected(null), "aria-label": "Detayı kapat", children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 360
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 235
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "İŞLEM DETAYI" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 384
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { id: "detail-title", children: selected.type === "In" ? "Gelen transfer" : "Giden transfer" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 433
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { className: "detail-amount", children: [
        selected.type === "In" ? "+" : "−",
        formatMoney(selected.amount)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 522
      }, this),
      /* @__PURE__ */ jsxDEV("dl", { children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { children: "Karşı cüzdan" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 640
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { children: selected.walletCode }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 661
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 26,
          columnNumber: 635
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { children: "Açıklama" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 702
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { children: selected.description }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 719
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 26,
          columnNumber: 697
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { children: "Tarih" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 761
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { children: formatDate(selected.createdAt) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
            lineNumber: 26,
            columnNumber: 775
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
          lineNumber: 26,
          columnNumber: 756
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
        lineNumber: 26,
        columnNumber: 631
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
      lineNumber: 26,
      columnNumber: 93
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
      lineNumber: 26,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_s(TransactionsPage, "AtH+iRPbPpj0622Xm0OXCWCf3T0=", false, function() {
  return [useTransactions];
});
_c = TransactionsPage;
var _c;
$RefreshReg$(_c, "TransactionsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/transactions-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJ5RSxTQUM0QyxVQUQ1Qzs7QUF2QnpFLFNBQVNBLGFBQWFDLGNBQWNDLFNBQVM7QUFDN0MsU0FBU0MsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQzVDLFNBQVNDLFlBQVlDLHFCQUFxQjtBQUMxQyxTQUFTQyxZQUFZQyxtQkFBbUI7QUFDeEMsU0FBU0MsdUJBQXVCO0FBRWhDLFNBQVNDLHVCQUF1QjtBQUVoQyxNQUFNQyxZQUFZO0FBR1gsZ0JBQVNDLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJWCxTQUFTLENBQUM7QUFDbEMsUUFBTSxDQUFDWSxVQUFVQyxXQUFXLElBQUliLFNBQWlDLElBQUk7QUFDckUsUUFBTWMsY0FBY2YsT0FBMEIsSUFBSTtBQUNsRCxRQUFNZ0IsVUFBVVQsZ0JBQWdCSSxNQUFNSCxTQUFTO0FBQy9DVCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNjLFNBQVU7QUFDZkUsZ0JBQVlFLFNBQVNDLE1BQU07QUFDM0IsVUFBTUMsWUFBWUEsQ0FBQ0MsVUFBeUI7QUFBRSxVQUFJQSxNQUFNQyxRQUFRLFNBQVVQLGFBQVksSUFBSTtBQUFBLElBQUU7QUFDNUZRLFdBQU9DLGlCQUFpQixXQUFXSixTQUFTO0FBQzVDLFdBQU8sTUFBTUcsT0FBT0Usb0JBQW9CLFdBQVdMLFNBQVM7QUFBQSxFQUM5RCxHQUFHLENBQUNOLFFBQVEsQ0FBQztBQUNiLFNBQU8sdUJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBLDJCQUFDLFlBQU8sV0FBVSxnQkFBZTtBQUFBLDZCQUFDLFVBQUssV0FBVSxlQUFjLGlDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStDO0FBQUEsTUFBTyx1QkFBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUFLLHVCQUFDLE9BQUUsNkRBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLFNBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUs7QUFBQSxJQUFTLHVCQUFDLGFBQVEsV0FBVSxtQkFBa0I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQWtCLGlDQUFDLFNBQUk7QUFBQSwrQkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUFLLHVCQUFDLE9BQUUsaURBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFdBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUUsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RztBQUFBLE1BQzlWRyxRQUFRUyxZQUFZLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxJQUFNVCxRQUFRVSxVQUFVLHVCQUFDLGNBQVcsT0FBTyxNQUFNLEtBQUtWLFFBQVFXLFFBQVEsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRCxJQUFNLG1DQUFFO0FBQUEsK0JBQUMsbUJBQWdCLE9BQU9YLFFBQVFZLE1BQU0sVUFBVWQsZUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQUcsdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRUYsb0JBQVFELE9BQU8sQ0FBQztBQUFHRyx3QkFBWSxJQUFJO0FBQUEsVUFBRSxHQUFHLFVBQVVILFNBQVMsR0FBRztBQUFBLG1DQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLFlBQUc7QUFBQSxlQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxSTtBQUFBLFVBQVMsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBT0E7QUFBQUEsZUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQU8sdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNO0FBQUVDLG9CQUFRRCxPQUFPLENBQUM7QUFBR0csd0JBQVksSUFBSTtBQUFBLFVBQUUsR0FBRyxVQUFVRSxRQUFRWSxLQUFLQyxTQUFTckIsV0FBVztBQUFBO0FBQUEsWUFBUSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVCO0FBQUEsZUFBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEo7QUFBQSxhQUEvVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdXO0FBQUEsV0FBemE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErYTtBQUFBLFNBRGxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFaE47QUFBQSxJQUFXSyxZQUFZLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsU0FBUyxNQUFNQyxZQUFZLElBQUksR0FBRyxpQ0FBQyxhQUFRLFdBQVUsZ0JBQWUsTUFBSyxVQUFTLGNBQVcsUUFBTyxtQkFBZ0IsZ0JBQWUsU0FBUyxDQUFDTSxVQUFVQSxNQUFNVSxnQkFBZ0IsR0FBRztBQUFBLDZCQUFDLFlBQU8sS0FBS2YsYUFBYSxXQUFVLGdCQUFlLE1BQUssVUFBUyxTQUFTLE1BQU1ELFlBQVksSUFBSSxHQUFHLGNBQVcsZ0JBQWUsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEk7QUFBQSxNQUFTLHVCQUFDLFVBQUssV0FBVSxlQUFjLDRCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsTUFBTyx1QkFBQyxRQUFHLElBQUcsZ0JBQWdCRCxtQkFBU2tCLFNBQVMsT0FBTyxtQkFBbUIsb0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUFLLHVCQUFDLFlBQU8sV0FBVSxpQkFBaUJsQjtBQUFBQSxpQkFBU2tCLFNBQVMsT0FBTyxNQUFNO0FBQUEsUUFBSzFCLFlBQVlRLFNBQVNtQixNQUFNO0FBQUEsV0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRztBQUFBLE1BQVMsdUJBQUMsUUFBRztBQUFBLCtCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBSyx1QkFBQyxRQUFJbkIsbUJBQVNvQixjQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsYUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQU0sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQUssdUJBQUMsUUFBSXBCLG1CQUFTcUIsZUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLGFBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUFNLHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVM7QUFBQSxVQUFLLHVCQUFDLFFBQUk5QixxQkFBV1MsU0FBU3NCLFNBQVMsS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxhQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsV0FBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErTDtBQUFBLFNBQXp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTh0QixLQUFqeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyeUI7QUFBQSxPQUYzekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVrMEI7QUFDMzBCO0FBQUN6QixHQWZlRCxrQkFBZ0I7QUFBQSxVQUlkRixlQUFlO0FBQUE7QUFBQSxLQUpqQkU7QUFBZ0IsSUFBQTJCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkNoZXZyb25MZWZ0IiwiQ2hldnJvblJpZ2h0IiwiWCIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiUXVlcnlFcnJvciIsIlF1ZXJ5U2tlbGV0b24iLCJmb3JtYXREYXRlIiwiZm9ybWF0TW9uZXkiLCJUcmFuc2FjdGlvbkxpc3QiLCJ1c2VUcmFuc2FjdGlvbnMiLCJQQUdFX1NJWkUiLCJUcmFuc2FjdGlvbnNQYWdlIiwiX3MiLCJwYWdlIiwic2V0UGFnZSIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJjbG9zZUJ1dHRvbiIsImhpc3RvcnkiLCJjdXJyZW50IiwiZm9jdXMiLCJvbktleURvd24iLCJldmVudCIsImtleSIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaXNQZW5kaW5nIiwiaXNFcnJvciIsInJlZmV0Y2giLCJkYXRhIiwibGVuZ3RoIiwic3RvcFByb3BhZ2F0aW9uIiwidHlwZSIsImFtb3VudCIsIndhbGxldENvZGUiLCJkZXNjcmlwdGlvbiIsImNyZWF0ZWRBdCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInRyYW5zYWN0aW9ucy1wYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGV2cm9uTGVmdCwgQ2hldnJvblJpZ2h0LCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBRdWVyeUVycm9yLCBRdWVyeVNrZWxldG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9xdWVyeS1zdGF0ZSdcbmltcG9ydCB7IGZvcm1hdERhdGUsIGZvcm1hdE1vbmV5IH0gZnJvbSAnLi4vLi4vbGliL2Zvcm1hdCdcbmltcG9ydCB7IFRyYW5zYWN0aW9uTGlzdCB9IGZyb20gJy4vY29tcG9uZW50cy90cmFuc2FjdGlvbi1saXN0J1xuaW1wb3J0IHR5cGUgeyBUcmFuc2FjdGlvbkl0ZW0gfSBmcm9tICcuL2FwaSdcbmltcG9ydCB7IHVzZVRyYW5zYWN0aW9ucyB9IGZyb20gJy4vaG9va3MnXG5cbmNvbnN0IFBBR0VfU0laRSA9IDEwXG5cbi8qKiDEsMWfbGVtIGdlw6dtacWfaW5pIHNheWZhbGFyOyBzZcOnaWxlbiBpxZ9sZW1pIGF5csSxbnTEsSBwYW5lbGluZGUgZ8O2c3RlcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zYWN0aW9uc1BhZ2UoKSB7XG4gIGNvbnN0IFtwYWdlLCBzZXRQYWdlXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8VHJhbnNhY3Rpb25JdGVtIHwgbnVsbD4obnVsbClcbiAgY29uc3QgY2xvc2VCdXR0b24gPSB1c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpXG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VUcmFuc2FjdGlvbnMocGFnZSwgUEFHRV9TSVpFKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWQpIHJldHVyblxuICAgIGNsb3NlQnV0dG9uLmN1cnJlbnQ/LmZvY3VzKClcbiAgICBjb25zdCBvbktleURvd24gPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHsgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScpIHNldFNlbGVjdGVkKG51bGwpIH1cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93bilcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24pXG4gIH0sIFtzZWxlY3RlZF0pXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtc3RhY2tcIj48aGVhZGVyIGNsYXNzTmFtZT1cInBhZ2UtaGVhZGluZ1wiPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+SEVTQVAgSEFSRUtFVExFUsSwPC9zcGFuPjxoMT7EsMWfbGVtIGdlw6dtacWfaTwvaDE+PHA+R2VsZW4gdmUgZ2lkZW4gdHJhbnNmZXJsZXJpbml6aSBnw7Zyw7xudMO8bGV5aW4uPC9wPjwvaGVhZGVyPjxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnQtc2VjdGlvblwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGRpdj48aDI+VMO8bSB0cmFuc2ZlcmxlcjwvaDI+PHA+RW4geWVuaSBpxZ9sZW1sZXIgw7ZuY2UgZ8O2c3RlcmlsaXIuPC9wPjwvZGl2PjwvZGl2PlxuICAgIHtoaXN0b3J5LmlzUGVuZGluZyA/IDxRdWVyeVNrZWxldG9uIC8+IDogaGlzdG9yeS5pc0Vycm9yID8gPFF1ZXJ5RXJyb3IgcmV0cnk9eygpID0+IHZvaWQgaGlzdG9yeS5yZWZldGNoKCl9IC8+IDogPD48VHJhbnNhY3Rpb25MaXN0IGl0ZW1zPXtoaXN0b3J5LmRhdGF9IG9uU2VsZWN0PXtzZXRTZWxlY3RlZH0gLz48ZGl2IGNsYXNzTmFtZT1cInBhZ2luYXRpb25cIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldFBhZ2UocGFnZSAtIDEpOyBzZXRTZWxlY3RlZChudWxsKSB9fSBkaXNhYmxlZD17cGFnZSA9PT0gMX0+PENoZXZyb25MZWZ0IHNpemU9ezE2fSAvPiDDlm5jZWtpPC9idXR0b24+PHNwYW4+U2F5ZmEge3BhZ2V9PC9zcGFuPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0UGFnZShwYWdlICsgMSk7IHNldFNlbGVjdGVkKG51bGwpIH19IGRpc2FibGVkPXtoaXN0b3J5LmRhdGEubGVuZ3RoIDwgUEFHRV9TSVpFfT5Tb25yYWtpIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+PC8+fVxuICA8L3NlY3Rpb24+e3NlbGVjdGVkICYmIDxkaXYgY2xhc3NOYW1lPVwiZGV0YWlsLWJhY2tkcm9wXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9PjxzZWN0aW9uIGNsYXNzTmFtZT1cImRldGFpbC1wYW5lbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWxsZWRieT1cImRldGFpbC10aXRsZVwiIG9uQ2xpY2s9eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PjxidXR0b24gcmVmPXtjbG9zZUJ1dHRvbn0gY2xhc3NOYW1lPVwiZGV0YWlsLWNsb3NlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKG51bGwpfSBhcmlhLWxhYmVsPVwiRGV0YXnEsSBrYXBhdFwiPjxYIHNpemU9ezIwfSAvPjwvYnV0dG9uPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+xLDFnkxFTSBERVRBWUk8L3NwYW4+PGgyIGlkPVwiZGV0YWlsLXRpdGxlXCI+e3NlbGVjdGVkLnR5cGUgPT09ICdJbicgPyAnR2VsZW4gdHJhbnNmZXInIDogJ0dpZGVuIHRyYW5zZmVyJ308L2gyPjxzdHJvbmcgY2xhc3NOYW1lPVwiZGV0YWlsLWFtb3VudFwiPntzZWxlY3RlZC50eXBlID09PSAnSW4nID8gJysnIDogJ+KIkid9e2Zvcm1hdE1vbmV5KHNlbGVjdGVkLmFtb3VudCl9PC9zdHJvbmc+PGRsPjxkaXY+PGR0PkthcsWfxLEgY8O8emRhbjwvZHQ+PGRkPntzZWxlY3RlZC53YWxsZXRDb2RlfTwvZGQ+PC9kaXY+PGRpdj48ZHQ+QcOnxLFrbGFtYTwvZHQ+PGRkPntzZWxlY3RlZC5kZXNjcmlwdGlvbn08L2RkPjwvZGl2PjxkaXY+PGR0PlRhcmloPC9kdD48ZGQ+e2Zvcm1hdERhdGUoc2VsZWN0ZWQuY3JlYXRlZEF0KX08L2RkPjwvZGl2PjwvZGw+PC9zZWN0aW9uPjwvZGl2Pn08L2Rpdj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy1wYWdlLnRzeCJ9