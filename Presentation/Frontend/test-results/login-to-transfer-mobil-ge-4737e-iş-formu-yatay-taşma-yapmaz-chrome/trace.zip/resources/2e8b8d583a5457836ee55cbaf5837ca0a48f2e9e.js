import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/architecture/architecture-flow.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Activity, ArrowRight, Database, Radio, Server, Workflow } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
const stages = [
  { title: "MSSQL", label: "Asıl kayıt", icon: Database, description: "Bakiye, transfer ve olay kaydı aynı SQL transaction içinde yazılır." },
  { title: "Outbox", label: "Güvenli bekleme", icon: Workflow, description: "Mesaj SQL Outbox tablosunda tutulur; broker kapalı olsa da kaybolmaz." },
  { title: "RabbitMQ", label: "Mesaj taşıma", icon: Radio, description: "Outbox mesajı kuyruğa yayımlar; consumer arka planda alır." },
  { title: "MongoDB", label: "Okuma modeli", icon: Server, description: "Consumer işlem geçmişi belgesini ekler veya günceller." },
  { title: "Redis", label: "Önbellek", icon: Activity, description: "Consumer geçmiş önbelleğinin sürümünü artırır; sonraki okuma taze veriyi yükler." }
];
export function ArchitectureFlow() {
  return /* @__PURE__ */ jsxDEV("ol", { className: "architecture-flow", children: stages.map(({ title, label, icon: Icon, description }, index) => /* @__PURE__ */ jsxDEV("li", { className: "architecture-node", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "architecture-node-head", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "architecture-node-icon", children: /* @__PURE__ */ jsxDEV(Icon, { size: 19 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
        lineNumber: 13,
        columnNumber: 237
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
        lineNumber: 13,
        columnNumber: 196
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: title }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
          lineNumber: 13,
          columnNumber: 267
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: label }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
          lineNumber: 13,
          columnNumber: 291
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
        lineNumber: 13,
        columnNumber: 262
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
      lineNumber: 13,
      columnNumber: 156
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: description }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
      lineNumber: 13,
      columnNumber: 325
    }, this),
    index < stages.length - 1 && /* @__PURE__ */ jsxDEV(ArrowRight, { className: "architecture-arrow", size: 18, "aria-hidden": "true" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
      lineNumber: 13,
      columnNumber: 375
    }, this)
  ] }, title, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
    lineNumber: 13,
    columnNumber: 110
  }, this)) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_c = ArchitectureFlow;
var _c;
$RefreshReg$(_c, "ArchitectureFlow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-flow.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWTRPO0FBWjVPLFNBQVNBLFVBQVVDLFlBQVlDLFVBQVVDLE9BQU9DLFFBQVFDLGdCQUFnQjtBQUV4RSxNQUFNQyxTQUFTO0FBQUEsRUFDYixFQUFFQyxPQUFPLFNBQVNDLE9BQU8sY0FBY0MsTUFBTVAsVUFBVVEsYUFBYSxzRUFBc0U7QUFBQSxFQUMxSSxFQUFFSCxPQUFPLFVBQVVDLE9BQU8sbUJBQW1CQyxNQUFNSixVQUFVSyxhQUFhLHdFQUF3RTtBQUFBLEVBQ2xKLEVBQUVILE9BQU8sWUFBWUMsT0FBTyxnQkFBZ0JDLE1BQU1OLE9BQU9PLGFBQWEsNkRBQTZEO0FBQUEsRUFDbkksRUFBRUgsT0FBTyxXQUFXQyxPQUFPLGdCQUFnQkMsTUFBTUwsUUFBUU0sYUFBYSx5REFBeUQ7QUFBQSxFQUMvSCxFQUFFSCxPQUFPLFNBQVNDLE9BQU8sWUFBWUMsTUFBTVQsVUFBVVUsYUFBYSxtRkFBbUY7QUFBQztBQUlqSixnQkFBU0MsbUJBQW1CO0FBQ2pDLFNBQU8sdUJBQUMsUUFBRyxXQUFVLHFCQUFxQkwsaUJBQU9NLElBQUksQ0FBQyxFQUFFTCxPQUFPQyxPQUFPQyxNQUFNSSxNQUFNSCxZQUFZLEdBQUdJLFVBQVUsdUJBQUMsUUFBRyxXQUFVLHFCQUFnQztBQUFBLDJCQUFDLFNBQUksV0FBVSwwQkFBeUI7QUFBQSw2QkFBQyxVQUFLLFdBQVUsMEJBQXlCLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFBTyx1QkFBQyxTQUFJO0FBQUEsK0JBQUMsWUFBUVAsbUJBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFBUyx1QkFBQyxXQUFPQyxtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxXQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FBN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtSztBQUFBLElBQU0sdUJBQUMsT0FBR0UseUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQUtJLFFBQVFSLE9BQU9TLFNBQVMsS0FBSyx1QkFBQyxjQUFXLFdBQVUsc0JBQXFCLE1BQU0sSUFBSSxlQUFZLFVBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUU7QUFBQSxPQUF6U1IsT0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvVixDQUFLLEtBQTdiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK2I7QUFDeGM7QUFBQ1MsS0FGZUw7QUFBZ0IsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQWN0aXZpdHkiLCJBcnJvd1JpZ2h0IiwiRGF0YWJhc2UiLCJSYWRpbyIsIlNlcnZlciIsIldvcmtmbG93Iiwic3RhZ2VzIiwidGl0bGUiLCJsYWJlbCIsImljb24iLCJkZXNjcmlwdGlvbiIsIkFyY2hpdGVjdHVyZUZsb3ciLCJtYXAiLCJJY29uIiwiaW5kZXgiLCJsZW5ndGgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhcmNoaXRlY3R1cmUtZmxvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWN0aXZpdHksIEFycm93UmlnaHQsIERhdGFiYXNlLCBSYWRpbywgU2VydmVyLCBXb3JrZmxvdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuY29uc3Qgc3RhZ2VzID0gW1xuICB7IHRpdGxlOiAnTVNTUUwnLCBsYWJlbDogJ0FzxLFsIGthecSxdCcsIGljb246IERhdGFiYXNlLCBkZXNjcmlwdGlvbjogJ0Jha2l5ZSwgdHJhbnNmZXIgdmUgb2xheSBrYXlkxLEgYXluxLEgU1FMIHRyYW5zYWN0aW9uIGnDp2luZGUgeWF6xLFsxLFyLicgfSxcbiAgeyB0aXRsZTogJ091dGJveCcsIGxhYmVsOiAnR8O8dmVubGkgYmVrbGVtZScsIGljb246IFdvcmtmbG93LCBkZXNjcmlwdGlvbjogJ01lc2FqIFNRTCBPdXRib3ggdGFibG9zdW5kYSB0dXR1bHVyOyBicm9rZXIga2FwYWzEsSBvbHNhIGRhIGtheWJvbG1hei4nIH0sXG4gIHsgdGl0bGU6ICdSYWJiaXRNUScsIGxhYmVsOiAnTWVzYWogdGHFn8SxbWEnLCBpY29uOiBSYWRpbywgZGVzY3JpcHRpb246ICdPdXRib3ggbWVzYWrEsSBrdXlydcSfYSB5YXnEsW1sYXI7IGNvbnN1bWVyIGFya2EgcGxhbmRhIGFsxLFyLicgfSxcbiAgeyB0aXRsZTogJ01vbmdvREInLCBsYWJlbDogJ09rdW1hIG1vZGVsaScsIGljb246IFNlcnZlciwgZGVzY3JpcHRpb246ICdDb25zdW1lciBpxZ9sZW0gZ2XDp21pxZ9pIGJlbGdlc2luaSBla2xlciB2ZXlhIGfDvG5jZWxsZXIuJyB9LFxuICB7IHRpdGxlOiAnUmVkaXMnLCBsYWJlbDogJ8OWbmJlbGxlaycsIGljb246IEFjdGl2aXR5LCBkZXNjcmlwdGlvbjogJ0NvbnN1bWVyIGdlw6dtacWfIMO2bmJlbGxlxJ9pbmluIHPDvHLDvG3DvG7DvCBhcnTEsXLEsXI7IHNvbnJha2kgb2t1bWEgdGF6ZSB2ZXJpeWkgecO8a2xlci4nIH0sXG5dXG5cbi8qKiBHZXLDp2VrIHRyYW5zZmVyaW4gU1FMIE91dGJveCd0YW4gcmFwb3JsYW1hIHZlIMO2bmJlbGxlxJ9lIHV6YW5hbiB5b2x1bnUgYcOnxLFrbGFyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEFyY2hpdGVjdHVyZUZsb3coKSB7XG4gIHJldHVybiA8b2wgY2xhc3NOYW1lPVwiYXJjaGl0ZWN0dXJlLWZsb3dcIj57c3RhZ2VzLm1hcCgoeyB0aXRsZSwgbGFiZWwsIGljb246IEljb24sIGRlc2NyaXB0aW9uIH0sIGluZGV4KSA9PiA8bGkgY2xhc3NOYW1lPVwiYXJjaGl0ZWN0dXJlLW5vZGVcIiBrZXk9e3RpdGxlfT48ZGl2IGNsYXNzTmFtZT1cImFyY2hpdGVjdHVyZS1ub2RlLWhlYWRcIj48c3BhbiBjbGFzc05hbWU9XCJhcmNoaXRlY3R1cmUtbm9kZS1pY29uXCI+PEljb24gc2l6ZT17MTl9IC8+PC9zcGFuPjxkaXY+PHN0cm9uZz57dGl0bGV9PC9zdHJvbmc+PHNtYWxsPntsYWJlbH08L3NtYWxsPjwvZGl2PjwvZGl2PjxwPntkZXNjcmlwdGlvbn08L3A+e2luZGV4IDwgc3RhZ2VzLmxlbmd0aCAtIDEgJiYgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwiYXJjaGl0ZWN0dXJlLWFycm93XCIgc2l6ZT17MTh9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+fTwvbGk+KX08L29sPlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy9hcmNoaXRlY3R1cmUvYXJjaGl0ZWN0dXJlLWZsb3cudHN4In0=