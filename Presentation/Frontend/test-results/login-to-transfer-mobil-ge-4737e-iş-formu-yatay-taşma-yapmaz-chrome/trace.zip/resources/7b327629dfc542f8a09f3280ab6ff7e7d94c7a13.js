import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/pages/register-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { AuthLayout } from "/src/layouts/auth-layout.tsx";
import { RegisterForm } from "/src/features/auth/components/register-form.tsx";
export function RegisterPage() {
  return /* @__PURE__ */ jsxDEV(AuthLayout, { page: "register", children: /* @__PURE__ */ jsxDEV(RegisterForm, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/register-page.tsx",
    lineNumber: 6,
    columnNumber: 38
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/register-page.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
}
_c = RegisterPage;
var _c;
$RefreshReg$(_c, "RegisterPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/register-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/register-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/register-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS3FDO0FBTHJDLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFHdEIsZ0JBQVNDLGVBQWU7QUFDN0IsU0FBTyx1QkFBQyxjQUFXLE1BQUssWUFBVyxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWEsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUNyRDtBQUFDQyxLQUZlRDtBQUFZLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkF1dGhMYXlvdXQiLCJSZWdpc3RlckZvcm0iLCJSZWdpc3RlclBhZ2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJyZWdpc3Rlci1wYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBdXRoTGF5b3V0IH0gZnJvbSAnLi4vLi4vLi4vbGF5b3V0cy9hdXRoLWxheW91dCdcbmltcG9ydCB7IFJlZ2lzdGVyRm9ybSB9IGZyb20gJy4uL2NvbXBvbmVudHMvcmVnaXN0ZXItZm9ybSdcblxuLyoqIFllbmkga3VsbGFuxLFjxLEga2F5xLF0IGVrcmFuxLFuxLEgb3J0YWsgYXV0aCBnw7Zyw7xuw7xtw7x5bGUgZ8O2c3RlcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFJlZ2lzdGVyUGFnZSgpIHtcbiAgcmV0dXJuIDxBdXRoTGF5b3V0IHBhZ2U9XCJyZWdpc3RlclwiPjxSZWdpc3RlckZvcm0gLz48L0F1dGhMYXlvdXQ+XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2F1dGgvcGFnZXMvcmVnaXN0ZXItcGFnZS50c3gifQ==