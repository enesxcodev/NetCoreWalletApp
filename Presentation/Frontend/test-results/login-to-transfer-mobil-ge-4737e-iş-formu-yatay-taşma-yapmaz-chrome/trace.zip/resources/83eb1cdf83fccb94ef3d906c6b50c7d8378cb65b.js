import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/architecture/architecture-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Activity, Database, Radio, Server, Workflow } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import { ArchitectureFlow } from "/src/features/architecture/architecture-flow.tsx";
import { TransferTimeline } from "/src/features/architecture/transfer-timeline.tsx";
const services = [
  { title: "MSSQL + Outbox", description: "Transfer ve yayınlanacak olay aynı kalıcı transaction içinde.", icon: Database, kind: "durable" },
  { title: "RabbitMQ", description: "Olayları producer ile consumer arasında taşır.", icon: Radio, kind: "broker" },
  { title: "MongoDB", description: "İşlem geçmişi için okuma modelini saklar.", icon: Server, kind: "read" },
  { title: "Redis", description: "Geçmiş yanıtlarını önbelleğe alır; sürüm değişince eski cache atlanır.", icon: Activity, kind: "cache" }
];
export function ArchitecturePage() {
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack architecture-page", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "SİSTEM TASARIMI" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 14,
        columnNumber: 92
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: "Transferin arka plandaki yolculuğu" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 14,
        columnNumber: 144
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Kalıcı kayıt ile raporlama işlemlerinin nasıl güvenli biçimde ayrıldığını keşfedin." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 14,
        columnNumber: 187
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 14,
      columnNumber: 59
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "architecture-intro", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "architecture-intro-icon", children: /* @__PURE__ */ jsxDEV(Workflow, { size: 23 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 15,
        columnNumber: 86
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 15,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Önce güvenli kayıt, sonra arka plan işleri" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 15,
          columnNumber: 119
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "API önce bakiye ve transferi SQL’de kaydeder. Outbox, aynı transaction içindeki olayı saklar; mesajlaşma ve raporlama adımları ardından tamamlanır." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 15,
          columnNumber: 178
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 15,
        columnNumber: 114
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 15,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "content-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "VERİ AKIŞI" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 16,
          columnNumber: 80
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "MSSQL → Outbox → RabbitMQ → MongoDB → Redis" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 16,
          columnNumber: 127
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Her bileşenin sorumluluğu farklıdır." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 16,
          columnNumber: 179
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 16,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 16,
        columnNumber: 42
      }, this),
      /* @__PURE__ */ jsxDEV(ArchitectureFlow, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 16,
        columnNumber: 234
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 16,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "service-grid", "aria-label": "Servis görevleri ve gözlem durumu", children: services.map(({ title, description, icon: Icon, kind }) => /* @__PURE__ */ jsxDEV("article", { className: "service-card", children: [
      /* @__PURE__ */ jsxDEV("span", { className: `service-icon ${kind}`, children: /* @__PURE__ */ jsxDEV(Icon, { size: 18 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 17,
        columnNumber: 233
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 17,
        columnNumber: 192
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: title }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 17,
          columnNumber: 263
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: description }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 17,
          columnNumber: 287
        }, this),
        /* @__PURE__ */ jsxDEV("small", { className: "service-monitoring", children: "Canlı sağlık ölçümü yok" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
          lineNumber: 17,
          columnNumber: 307
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
        lineNumber: 17,
        columnNumber: 258
      }, this)
    ] }, title, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 17,
      columnNumber: 146
    }, this)) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 17,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(TransferTimeline, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 18,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "architecture-disclaimer", children: "Bu ekran canlı sağlık kontrolü değildir. Simülatör hiçbir API çağrısı yapmaz ve cüzdan bakiyesini değiştirmez." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
      lineNumber: 19,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_c = ArchitecturePage;
var _c;
$RefreshReg$(_c, "ArchitecturePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/architecture-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYTJGO0FBYjNGLFNBQVNBLFVBQVVDLFVBQVVDLE9BQU9DLFFBQVFDLGdCQUFnQjtBQUM1RCxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msd0JBQXdCO0FBRWpDLE1BQU1DLFdBQVc7QUFBQSxFQUNmLEVBQUVDLE9BQU8sa0JBQWtCQyxhQUFhLGlFQUFpRUMsTUFBTVQsVUFBVVUsTUFBTSxVQUFVO0FBQUEsRUFDekksRUFBRUgsT0FBTyxZQUFZQyxhQUFhLGtEQUFrREMsTUFBTVIsT0FBT1MsTUFBTSxTQUFTO0FBQUEsRUFDaEgsRUFBRUgsT0FBTyxXQUFXQyxhQUFhLDZDQUE2Q0MsTUFBTVAsUUFBUVEsTUFBTSxPQUFPO0FBQUEsRUFDekcsRUFBRUgsT0FBTyxTQUFTQyxhQUFhLDBFQUEwRUMsTUFBTVYsVUFBVVcsTUFBTSxRQUFRO0FBQUM7QUFJbkksZ0JBQVNDLG1CQUFtQjtBQUNqQyxTQUFPLHVCQUFDLFNBQUksV0FBVSxtQ0FBa0M7QUFBQSwyQkFBQyxZQUFPLFdBQVUsZ0JBQWU7QUFBQSw2QkFBQyxVQUFLLFdBQVUsZUFBYywrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QztBQUFBLE1BQU8sdUJBQUMsUUFBRyxrREFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNDO0FBQUEsTUFBSyx1QkFBQyxPQUFFLG1HQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxTQUF0TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBOO0FBQUEsSUFDaFIsdUJBQUMsYUFBUSxXQUFVLHNCQUFxQjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFBMEIsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQU0sdUJBQUMsU0FBSTtBQUFBLCtCQUFDLFlBQU8sMERBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQVMsdUJBQUMsT0FBRSxtS0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNKO0FBQUEsV0FBdE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwTjtBQUFBLFNBQXZVO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNlU7QUFBQSxJQUM3VSx1QkFBQyxhQUFRLFdBQVUsbUJBQWtCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1CQUFrQixpQ0FBQyxTQUFJO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWMsMEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUFPLHVCQUFDLFFBQUcsMkRBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQUssdUJBQUMsT0FBRSxvREFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsV0FBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSixLQUFwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBMO0FBQUEsTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsU0FBdFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5UDtBQUFBLElBQ3pQLHVCQUFDLGFBQVEsV0FBVSxnQkFBZSxjQUFXLHFDQUFxQ0wsbUJBQVNNLElBQUksQ0FBQyxFQUFFTCxPQUFPQyxhQUFhQyxNQUFNSSxNQUFNSCxLQUFLLE1BQU0sdUJBQUMsYUFBUSxXQUFVLGdCQUEyQjtBQUFBLDZCQUFDLFVBQUssV0FBVyxnQkFBZ0JBLElBQUksSUFBSSxpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLE1BQU8sdUJBQUMsU0FBSTtBQUFBLCtCQUFDLFlBQVFILG1CQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBQVMsdUJBQUMsT0FBR0MseUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQUksdUJBQUMsV0FBTSxXQUFVLHNCQUFxQix1Q0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxTQUEvTEQsT0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0TyxDQUFVLEtBQW5ZO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcVk7QUFBQSxJQUNyWSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsSUFDakIsdUJBQUMsT0FBRSxXQUFVLDJCQUEwQiw4SEFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSjtBQUFBLE9BTGhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNUDtBQUNGO0FBQUNPLEtBUmVIO0FBQWdCLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFjdGl2aXR5IiwiRGF0YWJhc2UiLCJSYWRpbyIsIlNlcnZlciIsIldvcmtmbG93IiwiQXJjaGl0ZWN0dXJlRmxvdyIsIlRyYW5zZmVyVGltZWxpbmUiLCJzZXJ2aWNlcyIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwia2luZCIsIkFyY2hpdGVjdHVyZVBhZ2UiLCJtYXAiLCJJY29uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXJjaGl0ZWN0dXJlLXBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFjdGl2aXR5LCBEYXRhYmFzZSwgUmFkaW8sIFNlcnZlciwgV29ya2Zsb3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBBcmNoaXRlY3R1cmVGbG93IH0gZnJvbSAnLi9hcmNoaXRlY3R1cmUtZmxvdydcbmltcG9ydCB7IFRyYW5zZmVyVGltZWxpbmUgfSBmcm9tICcuL3RyYW5zZmVyLXRpbWVsaW5lJ1xuXG5jb25zdCBzZXJ2aWNlcyA9IFtcbiAgeyB0aXRsZTogJ01TU1FMICsgT3V0Ym94JywgZGVzY3JpcHRpb246ICdUcmFuc2ZlciB2ZSB5YXnEsW5sYW5hY2FrIG9sYXkgYXluxLEga2FsxLFjxLEgdHJhbnNhY3Rpb24gacOnaW5kZS4nLCBpY29uOiBEYXRhYmFzZSwga2luZDogJ2R1cmFibGUnIH0sXG4gIHsgdGl0bGU6ICdSYWJiaXRNUScsIGRlc2NyaXB0aW9uOiAnT2xheWxhcsSxIHByb2R1Y2VyIGlsZSBjb25zdW1lciBhcmFzxLFuZGEgdGHFn8Sxci4nLCBpY29uOiBSYWRpbywga2luZDogJ2Jyb2tlcicgfSxcbiAgeyB0aXRsZTogJ01vbmdvREInLCBkZXNjcmlwdGlvbjogJ8SwxZ9sZW0gZ2XDp21pxZ9pIGnDp2luIG9rdW1hIG1vZGVsaW5pIHNha2xhci4nLCBpY29uOiBTZXJ2ZXIsIGtpbmQ6ICdyZWFkJyB9LFxuICB7IHRpdGxlOiAnUmVkaXMnLCBkZXNjcmlwdGlvbjogJ0dlw6dtacWfIHlhbsSxdGxhcsSxbsSxIMO2bmJlbGxlxJ9lIGFsxLFyOyBzw7xyw7xtIGRlxJ9pxZ9pbmNlIGVza2kgY2FjaGUgYXRsYW7EsXIuJywgaWNvbjogQWN0aXZpdHksIGtpbmQ6ICdjYWNoZScgfSxcbl1cblxuLyoqIEV2ZW50LWRyaXZlbiBiYWNrZW5kIGFrxLHFn8SxbsSxLCBzZXJ2aXMgcm9sbGVyaW5pIHZlIGtlc2ludGkgc2VuYXJ5b3N1bnUgw7bEn3JldGlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEFyY2hpdGVjdHVyZVBhZ2UoKSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtc3RhY2sgYXJjaGl0ZWN0dXJlLXBhZ2VcIj48aGVhZGVyIGNsYXNzTmFtZT1cInBhZ2UtaGVhZGluZ1wiPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+U8SwU1RFTSBUQVNBUklNSTwvc3Bhbj48aDE+VHJhbnNmZXJpbiBhcmthIHBsYW5kYWtpIHlvbGN1bHXEn3U8L2gxPjxwPkthbMSxY8SxIGthecSxdCBpbGUgcmFwb3JsYW1hIGnFn2xlbWxlcmluaW4gbmFzxLFsIGfDvHZlbmxpIGJpw6dpbWRlIGF5csSxbGTEscSfxLFuxLEga2XFn2ZlZGluLjwvcD48L2hlYWRlcj5cbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJhcmNoaXRlY3R1cmUtaW50cm9cIj48ZGl2IGNsYXNzTmFtZT1cImFyY2hpdGVjdHVyZS1pbnRyby1pY29uXCI+PFdvcmtmbG93IHNpemU9ezIzfSAvPjwvZGl2PjxkaXY+PHN0cm9uZz7Dlm5jZSBnw7x2ZW5saSBrYXnEsXQsIHNvbnJhIGFya2EgcGxhbiBpxZ9sZXJpPC9zdHJvbmc+PHA+QVBJIMO2bmNlIGJha2l5ZSB2ZSB0cmFuc2ZlcmkgU1FM4oCZZGUga2F5ZGVkZXIuIE91dGJveCwgYXluxLEgdHJhbnNhY3Rpb24gacOnaW5kZWtpIG9sYXnEsSBzYWtsYXI7IG1lc2FqbGHFn21hIHZlIHJhcG9ybGFtYSBhZMSxbWxhcsSxIGFyZMSxbmRhbiB0YW1hbWxhbsSxci48L3A+PC9kaXY+PC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnQtc2VjdGlvblwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJjYXJkLWtpY2tlclwiPlZFUsSwIEFLScWeSTwvc3Bhbj48aDI+TVNTUUwg4oaSIE91dGJveCDihpIgUmFiYml0TVEg4oaSIE1vbmdvREIg4oaSIFJlZGlzPC9oMj48cD5IZXIgYmlsZcWfZW5pbiBzb3J1bWx1bHXEn3UgZmFya2zEsWTEsXIuPC9wPjwvZGl2PjwvZGl2PjxBcmNoaXRlY3R1cmVGbG93IC8+PC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNlcnZpY2UtZ3JpZFwiIGFyaWEtbGFiZWw9XCJTZXJ2aXMgZ8O2cmV2bGVyaSB2ZSBnw7Z6bGVtIGR1cnVtdVwiPntzZXJ2aWNlcy5tYXAoKHsgdGl0bGUsIGRlc2NyaXB0aW9uLCBpY29uOiBJY29uLCBraW5kIH0pID0+IDxhcnRpY2xlIGNsYXNzTmFtZT1cInNlcnZpY2UtY2FyZFwiIGtleT17dGl0bGV9PjxzcGFuIGNsYXNzTmFtZT17YHNlcnZpY2UtaWNvbiAke2tpbmR9YH0+PEljb24gc2l6ZT17MTh9IC8+PC9zcGFuPjxkaXY+PHN0cm9uZz57dGl0bGV9PC9zdHJvbmc+PHA+e2Rlc2NyaXB0aW9ufTwvcD48c21hbGwgY2xhc3NOYW1lPVwic2VydmljZS1tb25pdG9yaW5nXCI+Q2FubMSxIHNhxJ9sxLFrIMO2bMOnw7xtw7wgeW9rPC9zbWFsbD48L2Rpdj48L2FydGljbGU+KX08L3NlY3Rpb24+XG4gICAgPFRyYW5zZmVyVGltZWxpbmUgLz5cbiAgICA8cCBjbGFzc05hbWU9XCJhcmNoaXRlY3R1cmUtZGlzY2xhaW1lclwiPkJ1IGVrcmFuIGNhbmzEsSBzYcSfbMSxayBrb250cm9sw7wgZGXEn2lsZGlyLiBTaW3DvGxhdMO2ciBoacOnYmlyIEFQSSDDp2HEn3LEsXPEsSB5YXBtYXogdmUgY8O8emRhbiBiYWtpeWVzaW5pIGRlxJ9pxZ90aXJtZXouPC9wPlxuICA8L2Rpdj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvYXJjaGl0ZWN0dXJlL2FyY2hpdGVjdHVyZS1wYWdlLnRzeCJ9