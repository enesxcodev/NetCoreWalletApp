import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/app-providers.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { HeroUIProvider } from "/node_modules/.vite/deps/@heroui_react.js?v=88909849";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=88909849";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport3_react["useState"];
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { AuthProvider } from "/src/app/auth-context.tsx";
import { ToastProvider } from "/src/components/toast-provider.tsx";
export function AppProviders({ children }) {
  _s();
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false }, mutations: { retry: false } }
  }));
  return /* @__PURE__ */ jsxDEV(HeroUIProvider, { children: /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(ToastProvider, { children }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx",
    lineNumber: 14,
    columnNumber: 97
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx",
    lineNumber: 14,
    columnNumber: 82
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx",
    lineNumber: 14,
    columnNumber: 68
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx",
    lineNumber: 14,
    columnNumber: 26
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_s(AppProviders, "My4dYad7+PUc7/MXFaSV1yj926w=");
_c = AppProviders;
var _c;
$RefreshReg$(_c, "AppProviders");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/app-providers.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYWdHOztBQWJoRyxTQUFTQSxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYUMsMkJBQTJCO0FBQ2pELFNBQVNDLGdCQUF3QztBQUNqRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUd2QixnQkFBU0MsYUFBYSxFQUFFQyxTQUE0QixHQUFHO0FBQUFDLEtBQUE7QUFDNUQsUUFBTSxDQUFDQyxXQUFXLElBQUlQLFNBQVMsTUFBTSxJQUFJRixZQUFZO0FBQUEsSUFDbkRVLGdCQUFnQixFQUFFQyxTQUFTLEVBQUVDLE9BQU8sR0FBR0Msc0JBQXNCLE1BQU0sR0FBR0MsV0FBVyxFQUFFRixPQUFPLE1BQU0sRUFBRTtBQUFBLEVBQ3BHLENBQUMsQ0FBQztBQUVGLFNBQU8sdUJBQUMsa0JBQWUsaUNBQUMsdUJBQW9CLFFBQVFILGFBQWEsaUNBQUMsZ0JBQWEsaUNBQUMsaUJBQWMsaUNBQUMsaUJBQWVGLFlBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUIsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3RCxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNGLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0ksS0FBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxTDtBQUM5TDtBQUFDQyxHQU5lRixjQUFZO0FBQUEsS0FBWkE7QUFBWSxJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJIZXJvVUlQcm92aWRlciIsIlF1ZXJ5Q2xpZW50IiwiUXVlcnlDbGllbnRQcm92aWRlciIsInVzZVN0YXRlIiwiQnJvd3NlclJvdXRlciIsIkF1dGhQcm92aWRlciIsIlRvYXN0UHJvdmlkZXIiLCJBcHBQcm92aWRlcnMiLCJjaGlsZHJlbiIsIl9zIiwicXVlcnlDbGllbnQiLCJkZWZhdWx0T3B0aW9ucyIsInF1ZXJpZXMiLCJyZXRyeSIsInJlZmV0Y2hPbldpbmRvd0ZvY3VzIiwibXV0YXRpb25zIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXBwLXByb3ZpZGVycy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSGVyb1VJUHJvdmlkZXIgfSBmcm9tICdAaGVyb3VpL3JlYWN0J1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBQcm9wc1dpdGhDaGlsZHJlbiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQnJvd3NlclJvdXRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tICcuL2F1dGgtY29udGV4dCdcbmltcG9ydCB7IFRvYXN0UHJvdmlkZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL3RvYXN0LXByb3ZpZGVyJ1xuXG4vKiogVUksIHN1bnVjdSBzdGF0ZSdpLCBvdHVydW0gdmUgecO2bmxlbmRpcm1lIHNhxJ9sYXnEsWPEsWxhcsSxbsSxIGJpciBhcmF5YSBnZXRpcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEFwcFByb3ZpZGVycyh7IGNoaWxkcmVuIH06IFByb3BzV2l0aENoaWxkcmVuKSB7XG4gIGNvbnN0IFtxdWVyeUNsaWVudF0gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgUXVlcnlDbGllbnQoe1xuICAgIGRlZmF1bHRPcHRpb25zOiB7IHF1ZXJpZXM6IHsgcmV0cnk6IDEsIHJlZmV0Y2hPbldpbmRvd0ZvY3VzOiBmYWxzZSB9LCBtdXRhdGlvbnM6IHsgcmV0cnk6IGZhbHNlIH0gfSxcbiAgfSkpXG5cbiAgcmV0dXJuIDxIZXJvVUlQcm92aWRlcj48UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT48QXV0aFByb3ZpZGVyPjxCcm93c2VyUm91dGVyPjxUb2FzdFByb3ZpZGVyPntjaGlsZHJlbn08L1RvYXN0UHJvdmlkZXI+PC9Ccm93c2VyUm91dGVyPjwvQXV0aFByb3ZpZGVyPjwvUXVlcnlDbGllbnRQcm92aWRlcj48L0hlcm9VSVByb3ZpZGVyPlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9hcHAvYXBwLXByb3ZpZGVycy50c3gifQ==