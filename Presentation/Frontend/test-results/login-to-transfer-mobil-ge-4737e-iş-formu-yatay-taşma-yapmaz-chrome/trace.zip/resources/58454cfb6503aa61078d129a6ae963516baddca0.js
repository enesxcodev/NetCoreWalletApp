import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/contacts/components/contacts-table.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { UsersRound } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import { CopyWalletCodeButton } from "/src/features/contacts/components/copy-wallet-code-button.tsx";
export function ContactsTable({ contacts, searched }) {
  if (!contacts.length) return /* @__PURE__ */ jsxDEV("div", { className: "contacts-empty", children: [
    /* @__PURE__ */ jsxDEV(UsersRound, { size: 27 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 7,
      columnNumber: 64
    }, this),
    /* @__PURE__ */ jsxDEV("strong", { children: searched ? "Aramanızla eşleşen kişi bulunamadı" : "Henüz transfer kişisi bulunmuyor" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 7,
      columnNumber: 88
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: searched ? "Farklı bir ad, kullanıcı adı veya e-posta deneyin." : "Cüzdanı olan kullanıcılar burada görünecek." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 7,
      columnNumber: 191
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
    lineNumber: 7,
    columnNumber: 32
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "contacts-table-wrap", children: /* @__PURE__ */ jsxDEV("table", { className: "contacts-table", children: [
    /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
      /* @__PURE__ */ jsxDEV("th", { children: "Ad soyad" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 10,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("th", { children: "Kullanıcı adı" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 10,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV("th", { children: "Cüzdan kodu" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 10,
        columnNumber: 55
      }, this),
      /* @__PURE__ */ jsxDEV("th", { children: /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "İşlem" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 10,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 10,
        columnNumber: 75
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 10,
      columnNumber: 12
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 10,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("tbody", { children: contacts.map((contact) => /* @__PURE__ */ jsxDEV("tr", { children: [
      /* @__PURE__ */ jsxDEV("td", { "data-label": "Ad soyad", children: /* @__PURE__ */ jsxDEV("span", { className: "contact-person", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "contact-avatar", "aria-hidden": "true", children: [
          contact.firstName[0],
          contact.lastName[0]
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
          lineNumber: 12,
          columnNumber: 66
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: [
          contact.firstName,
          " ",
          contact.lastName
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
          lineNumber: 12,
          columnNumber: 168
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 12,
        columnNumber: 33
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 12,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("td", { "data-label": "Kullanıcı adı", children: /* @__PURE__ */ jsxDEV("span", { className: "contact-username", children: [
        "@",
        contact.userName
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 13,
        columnNumber: 38
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 13,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("td", { "data-label": "Cüzdan kodu", children: /* @__PURE__ */ jsxDEV("code", { className: "contact-wallet-code", children: contact.walletCode }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 14,
        columnNumber: 36
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 14,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("td", { "data-label": "Kopyala", children: /* @__PURE__ */ jsxDEV(CopyWalletCodeButton, { code: contact.walletCode }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 15,
        columnNumber: 32
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
        lineNumber: 15,
        columnNumber: 7
      }, this)
    ] }, contact.walletCode, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 11,
      columnNumber: 39
    }, this)) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
      lineNumber: 11,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
    lineNumber: 9,
    columnNumber: 47
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_c = ContactsTable;
var _c;
$RefreshReg$(_c, "ContactsTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contacts-table.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTStEO0FBTi9ELFNBQVNBLGtCQUFrQjtBQUUzQixTQUFTQyw0QkFBNEI7QUFHOUIsZ0JBQVNDLGNBQWMsRUFBRUMsVUFBVUMsU0FBNkQsR0FBRztBQUN4RyxNQUFJLENBQUNELFNBQVNFLE9BQVEsUUFBTyx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsMkJBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUI7QUFBQSxJQUFHLHVCQUFDLFlBQVFELHFCQUFXLHVDQUF1QyxzQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RjtBQUFBLElBQVMsdUJBQUMsT0FBR0EscUJBQVcsdURBQXVELGlEQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9IO0FBQUEsT0FBblI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1UjtBQUVwVCxTQUFPLHVCQUFDLFNBQUksV0FBVSx1QkFBc0IsaUNBQUMsV0FBTSxXQUFVLGtCQUMzRDtBQUFBLDJCQUFDLFdBQU0saUNBQUMsUUFBRztBQUFBLDZCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZO0FBQUEsTUFBSyx1QkFBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUFLLHVCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFBSyx1QkFBQyxRQUFHLGlDQUFDLFVBQUssV0FBVSxXQUFVLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCLEtBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxTQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThHLEtBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEg7QUFBQSxJQUMxSCx1QkFBQyxXQUFPRCxtQkFBU0csSUFBSSxDQUFDQyxZQUFZLHVCQUFDLFFBQ2pDO0FBQUEsNkJBQUMsUUFBRyxjQUFXLFlBQVcsaUNBQUMsVUFBSyxXQUFVLGtCQUFpQjtBQUFBLCtCQUFDLFVBQUssV0FBVSxrQkFBaUIsZUFBWSxRQUFRQTtBQUFBQSxrQkFBUUMsVUFBVSxDQUFDO0FBQUEsVUFBR0QsUUFBUUUsU0FBUyxDQUFDO0FBQUEsYUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQU8sdUJBQUMsWUFBUUY7QUFBQUEsa0JBQVFDO0FBQUFBLFVBQVU7QUFBQSxVQUFFRCxRQUFRRTtBQUFBQSxhQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4TCxLQUF4TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStOO0FBQUEsTUFDL04sdUJBQUMsUUFBRyxjQUFXLGlCQUFnQixpQ0FBQyxVQUFLLFdBQVUsb0JBQW1CO0FBQUE7QUFBQSxRQUFFRixRQUFRRztBQUFBQSxXQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNELEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxNQUM1Rix1QkFBQyxRQUFHLGNBQVcsZUFBYyxpQ0FBQyxVQUFLLFdBQVUsdUJBQXVCSCxrQkFBUUksY0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRCxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThGO0FBQUEsTUFDOUYsdUJBQUMsUUFBRyxjQUFXLFdBQVUsaUNBQUMsd0JBQXFCLE1BQU1KLFFBQVFJLGNBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0MsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLFNBSmxDSixRQUFRSSxZQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2xDLENBQUssS0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS087QUFBQSxPQVBtQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUTVDLEtBUk87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFDO0FBQ1Y7QUFBQ0MsS0FaZVY7QUFBYSxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJVc2Vyc1JvdW5kIiwiQ29weVdhbGxldENvZGVCdXR0b24iLCJDb250YWN0c1RhYmxlIiwiY29udGFjdHMiLCJzZWFyY2hlZCIsImxlbmd0aCIsIm1hcCIsImNvbnRhY3QiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsInVzZXJOYW1lIiwid2FsbGV0Q29kZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNvbnRhY3RzLXRhYmxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBVc2Vyc1JvdW5kIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHR5cGUgeyBUcmFuc2ZlckNvbnRhY3QgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBDb3B5V2FsbGV0Q29kZUJ1dHRvbiB9IGZyb20gJy4vY29weS13YWxsZXQtY29kZS1idXR0b24nXG5cbi8qKiBUcmFuc2ZlciBracWfaWxlcmluaSBtYXNhw7xzdMO8bmRlIHRhYmxvLCBtb2JpbGRlIGthcnQgb2xhcmFrIGxpc3RlbGVyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENvbnRhY3RzVGFibGUoeyBjb250YWN0cywgc2VhcmNoZWQgfTogeyBjb250YWN0czogVHJhbnNmZXJDb250YWN0W107IHNlYXJjaGVkOiBib29sZWFuIH0pIHtcbiAgaWYgKCFjb250YWN0cy5sZW5ndGgpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3RzLWVtcHR5XCI+PFVzZXJzUm91bmQgc2l6ZT17Mjd9IC8+PHN0cm9uZz57c2VhcmNoZWQgPyAnQXJhbWFuxLF6bGEgZcWfbGXFn2VuIGtpxZ9pIGJ1bHVuYW1hZMSxJyA6ICdIZW7DvHogdHJhbnNmZXIga2nFn2lzaSBidWx1bm11eW9yJ308L3N0cm9uZz48cD57c2VhcmNoZWQgPyAnRmFya2zEsSBiaXIgYWQsIGt1bGxhbsSxY8SxIGFkxLEgdmV5YSBlLXBvc3RhIGRlbmV5aW4uJyA6ICdDw7x6ZGFuxLEgb2xhbiBrdWxsYW7EsWPEsWxhciBidXJhZGEgZ8O2csO8bmVjZWsuJ308L3A+PC9kaXY+XG5cbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdHMtdGFibGUtd3JhcFwiPjx0YWJsZSBjbGFzc05hbWU9XCJjb250YWN0cy10YWJsZVwiPlxuICAgIDx0aGVhZD48dHI+PHRoPkFkIHNveWFkPC90aD48dGg+S3VsbGFuxLFjxLEgYWTEsTwvdGg+PHRoPkPDvHpkYW4ga29kdTwvdGg+PHRoPjxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj7EsMWfbGVtPC9zcGFuPjwvdGg+PC90cj48L3RoZWFkPlxuICAgIDx0Ym9keT57Y29udGFjdHMubWFwKChjb250YWN0KSA9PiA8dHIga2V5PXtjb250YWN0LndhbGxldENvZGV9PlxuICAgICAgPHRkIGRhdGEtbGFiZWw9XCJBZCBzb3lhZFwiPjxzcGFuIGNsYXNzTmFtZT1cImNvbnRhY3QtcGVyc29uXCI+PHNwYW4gY2xhc3NOYW1lPVwiY29udGFjdC1hdmF0YXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIj57Y29udGFjdC5maXJzdE5hbWVbMF19e2NvbnRhY3QubGFzdE5hbWVbMF19PC9zcGFuPjxzdHJvbmc+e2NvbnRhY3QuZmlyc3ROYW1lfSB7Y29udGFjdC5sYXN0TmFtZX08L3N0cm9uZz48L3NwYW4+PC90ZD5cbiAgICAgIDx0ZCBkYXRhLWxhYmVsPVwiS3VsbGFuxLFjxLEgYWTEsVwiPjxzcGFuIGNsYXNzTmFtZT1cImNvbnRhY3QtdXNlcm5hbWVcIj5Ae2NvbnRhY3QudXNlck5hbWV9PC9zcGFuPjwvdGQ+XG4gICAgICA8dGQgZGF0YS1sYWJlbD1cIkPDvHpkYW4ga29kdVwiPjxjb2RlIGNsYXNzTmFtZT1cImNvbnRhY3Qtd2FsbGV0LWNvZGVcIj57Y29udGFjdC53YWxsZXRDb2RlfTwvY29kZT48L3RkPlxuICAgICAgPHRkIGRhdGEtbGFiZWw9XCJLb3B5YWxhXCI+PENvcHlXYWxsZXRDb2RlQnV0dG9uIGNvZGU9e2NvbnRhY3Qud2FsbGV0Q29kZX0gLz48L3RkPlxuICAgIDwvdHI+KX08L3Rib2R5PlxuICA8L3RhYmxlPjwvZGl2PlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy9jb250YWN0cy9jb21wb25lbnRzL2NvbnRhY3RzLXRhYmxlLnRzeCJ9