import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/wallet/pages/dashboard-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ArrowDownLeft, ArrowUpRight, Copy, Eye, EyeOff, History, WalletCards } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport2_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { QueryError, QuerySkeleton } from "/src/components/query-state.tsx";
import { formatMoney } from "/src/lib/format.ts";
import { TransactionList } from "/src/features/transactions/components/transaction-list.tsx";
import { useTransactions } from "/src/features/transactions/hooks.ts";
import { useWallet } from "/src/features/wallet/hooks.ts";
export function DashboardPage() {
  _s();
  const wallet = useWallet();
  const recent = useTransactions(1, 5);
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [copied, setCopied] = useState(false);
  const copyCode = async () => {
    if (!wallet.data) return;
    await navigator.clipboard.writeText(wallet.data.code);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2e3);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "GENEL BAKIŞ" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 23,
        columnNumber: 38
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: "Cüzdanınız, tek ekranda." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 23,
        columnNumber: 86
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Bakiyenizi ve son hareketlerinizi buradan takip edin." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 23,
        columnNumber: 119
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 23,
      columnNumber: 5
    }, this),
    wallet.isPending ? /* @__PURE__ */ jsxDEV(QuerySkeleton, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 24,
      columnNumber: 25
    }, this) : wallet.isError ? /* @__PURE__ */ jsxDEV(QueryError, { retry: () => void wallet.refetch() }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 24,
      columnNumber: 62
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overview-grid", children: [
      /* @__PURE__ */ jsxDEV("section", { className: "balance-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "balance-top", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "TOPLAM BAKİYE" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 25,
            columnNumber: 70
          }, this),
          /* @__PURE__ */ jsxDEV(WalletCards, { size: 24 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 25,
            columnNumber: 96
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 25,
          columnNumber: 41
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "balance-number", children: [
          balanceVisible ? formatMoney(wallet.data.balance) : "••••••••",
          " ",
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setBalanceVisible(!balanceVisible), "aria-label": balanceVisible ? "Bakiyeyi gizle" : "Bakiyeyi göster", children: balanceVisible ? /* @__PURE__ */ jsxDEV(EyeOff, { size: 20 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 25,
            columnNumber: 382
          }, this) : /* @__PURE__ */ jsxDEV(Eye, { size: 20 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 25,
            columnNumber: 405
          }, this) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 25,
            columnNumber: 224
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 25,
          columnNumber: 127
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Güncel kullanılabilir bakiyeniz" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 25,
          columnNumber: 438
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "balance-decor" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 25,
          columnNumber: 476
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 25,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "wallet-code-card", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "CÜZDAN KODUNUZ" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 26,
          columnNumber: 45
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "Ödeme almak artık kolay." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 26,
          columnNumber: 96
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Kodunuzu paylaşarak transfer alabilirsiniz." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 26,
          columnNumber: 129
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "wallet-code-line", children: [
          /* @__PURE__ */ jsxDEV("code", { children: wallet.data.code }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 26,
            columnNumber: 213
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => void copyCode(), "aria-label": "Cüzdan kodunu kopyala", children: /* @__PURE__ */ jsxDEV(Copy, { size: 18 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 26,
            columnNumber: 333
          }, this) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 26,
            columnNumber: 244
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 26,
          columnNumber: 179
        }, this),
        /* @__PURE__ */ jsxDEV("small", { role: "status", children: copied ? "Kod kopyalandı" : "Kodu güvenle paylaşabilirsiniz" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 26,
          columnNumber: 366
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 26,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 24,
      columnNumber: 115
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "content-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "HIZLI ERİŞİM" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 28,
          columnNumber: 80
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "Ne yapmak istersiniz?" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 28,
          columnNumber: 129
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 28,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 28,
        columnNumber: 42
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "quick-actions", children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/deposit", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "action-icon mint", children: /* @__PURE__ */ jsxDEV(ArrowDownLeft, {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 257
          }, this) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 222
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: "Para yatır" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 281
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Bakiyenizi artırın" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 308
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 28,
          columnNumber: 202
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/withdraw", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "action-icon coral", children: /* @__PURE__ */ jsxDEV(ArrowUpRight, {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 405
          }, this) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 369
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: "Para çek" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 428
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Bakiyenizi kullanın" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 453
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 28,
          columnNumber: 348
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/transfer", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "action-icon lilac", children: /* @__PURE__ */ jsxDEV(ArrowUpRight, {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 551
          }, this) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 515
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: "Transfer yap" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 574
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Kolayca para gönderin" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 28,
            columnNumber: 603
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 28,
          columnNumber: 494
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 28,
        columnNumber: 171
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 28,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "content-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "HESAP HAREKETLERİ" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 29,
            columnNumber: 80
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: "Son transferler" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 29,
            columnNumber: 134
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 29,
          columnNumber: 75
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/transactions", children: [
          "Tümünü gör ",
          /* @__PURE__ */ jsxDEV(History, { size: 15 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
            lineNumber: 29,
            columnNumber: 200
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
          lineNumber: 29,
          columnNumber: 164
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 29,
        columnNumber: 42
      }, this),
      recent.isPending ? /* @__PURE__ */ jsxDEV(QuerySkeleton, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 29,
        columnNumber: 254
      }, this) : recent.isError ? /* @__PURE__ */ jsxDEV(QueryError, { retry: () => void recent.refetch() }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 29,
        columnNumber: 291
      }, this) : /* @__PURE__ */ jsxDEV(TransactionList, { items: recent.data }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
        lineNumber: 29,
        columnNumber: 344
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
      lineNumber: 29,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_s(DashboardPage, "ECLibDUxFPpV/HiM2Pm/2dY6Z9Y=", false, function() {
  return [useWallet, useTransactions];
});
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/dashboard-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JxQzs7QUF0QnJDLFNBQVNBLGVBQWVDLGNBQWNDLE1BQU1DLEtBQUtDLFFBQVFDLFNBQVNDLG1CQUFtQjtBQUNyRixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxZQUFZQyxxQkFBcUI7QUFDMUMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsaUJBQWlCO0FBR25CLGdCQUFTQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUM5QixRQUFNQyxTQUFTSCxVQUFVO0FBQ3pCLFFBQU1JLFNBQVNMLGdCQUFnQixHQUFHLENBQUM7QUFDbkMsUUFBTSxDQUFDTSxnQkFBZ0JDLGlCQUFpQixJQUFJYixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDYyxRQUFRQyxTQUFTLElBQUlmLFNBQVMsS0FBSztBQUMxQyxRQUFNZ0IsV0FBVyxZQUFZO0FBQzNCLFFBQUksQ0FBQ04sT0FBT08sS0FBTTtBQUNsQixVQUFNQyxVQUFVQyxVQUFVQyxVQUFVVixPQUFPTyxLQUFLSSxJQUFJO0FBQ3BETixjQUFVLElBQUk7QUFDZE8sV0FBT0MsV0FBVyxNQUFNUixVQUFVLEtBQUssR0FBRyxHQUFJO0FBQUEsRUFDaEQ7QUFDQSxTQUFPLHVCQUFDLFNBQUksV0FBVSxpQkFDcEI7QUFBQSwyQkFBQyxZQUFPLFdBQVUsZ0JBQWU7QUFBQSw2QkFBQyxVQUFLLFdBQVUsZUFBYywyQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLE1BQU8sdUJBQUMsUUFBRyx3Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRCO0FBQUEsTUFBSyx1QkFBQyxPQUFFLHFFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxTQUExSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThLO0FBQUEsSUFDN0tMLE9BQU9jLFlBQVksdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLElBQU1kLE9BQU9lLFVBQVUsdUJBQUMsY0FBVyxPQUFPLE1BQU0sS0FBS2YsT0FBT2dCLFFBQVEsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQyxJQUFNLHVCQUFDLFNBQUksV0FBVSxpQkFDM0g7QUFBQSw2QkFBQyxhQUFRLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUFPLHVCQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBLGFBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUFNLHVCQUFDLFNBQUksV0FBVSxrQkFBa0JkO0FBQUFBLDJCQUFpQlIsWUFBWU0sT0FBT08sS0FBS1UsT0FBTyxJQUFJO0FBQUEsVUFBVztBQUFBLFVBQUMsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNZCxrQkFBa0IsQ0FBQ0QsY0FBYyxHQUFHLGNBQVlBLGlCQUFpQixtQkFBbUIsbUJBQW9CQSwyQkFBaUIsdUJBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUIsSUFBTSx1QkFBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjLEtBQW5NO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVNO0FBQUEsYUFBeFM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpVDtBQUFBLFFBQU0sdUJBQUMsT0FBRSwrQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFBSSx1QkFBQyxTQUFJLFdBQVUsbUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBQW5mO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc2Y7QUFBQSxNQUN0Zix1QkFBQyxhQUFRLFdBQVUsb0JBQW1CO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWMsOEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUFPLHVCQUFDLFFBQUcsd0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQUssdUJBQUMsT0FBRSwyREFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFBSSx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CO0FBQUEsaUNBQUMsVUFBTUYsaUJBQU9PLEtBQUtJLFFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFBTyx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU0sS0FBS0wsU0FBUyxHQUFHLGNBQVcseUJBQXdCLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkc7QUFBQSxhQUE1SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFMO0FBQUEsUUFBTSx1QkFBQyxXQUFNLE1BQUssVUFBVUYsbUJBQVMsbUJBQW1CLG9DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FBMWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrYztBQUFBLFNBRnRWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHOUc7QUFBQSxJQUNBLHVCQUFDLGFBQVEsV0FBVSxtQkFBa0I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQWtCLGlDQUFDLFNBQUk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZUFBYyw0QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQU8sdUJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsV0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRixLQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJIO0FBQUEsTUFBTSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsK0JBQUMsUUFBSyxJQUFHLFlBQVc7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsb0JBQW1CLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWMsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUFPLHVCQUFDLFlBQU8sMEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQSxVQUFTLHVCQUFDLFdBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxhQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFBTyx1QkFBQyxRQUFLLElBQUcsYUFBWTtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQkFBb0IsaUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQU8sdUJBQUMsWUFBTyx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQVMsdUJBQUMsV0FBTSxtQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLGFBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkk7QUFBQSxRQUFPLHVCQUFDLFFBQUssSUFBRyxhQUFZO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFCQUFvQixpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFBTyx1QkFBQyxZQUFPLDRCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFBUyx1QkFBQyxXQUFNLHFDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsYUFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSjtBQUFBLFdBQXBkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMmQ7QUFBQSxTQUFqb0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1b0I7QUFBQSxJQUN2b0IsdUJBQUMsYUFBUSxXQUFVLG1CQUFrQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtQkFBa0I7QUFBQSwrQkFBQyxTQUFJO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGVBQWMsaUNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFBTyx1QkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsYUFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFFBQU0sdUJBQUMsUUFBSyxJQUFHLGlCQUFnQjtBQUFBO0FBQUEsVUFBVyx1QkFBQyxXQUFRLE1BQU0sTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLGFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxXQUFuTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBMO0FBQUEsTUFBT0gsT0FBT2EsWUFBWSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsSUFBTWIsT0FBT2MsVUFBVSx1QkFBQyxjQUFXLE9BQU8sTUFBTSxLQUFLZCxPQUFPZSxRQUFRLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0MsSUFBTSx1QkFBQyxtQkFBZ0IsT0FBT2YsT0FBT00sUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLFNBQXZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMlg7QUFBQSxPQVB0WDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUVA7QUFDRjtBQUFDUixHQXBCZUQsZUFBYTtBQUFBLFVBQ1pELFdBQ0FELGVBQWU7QUFBQTtBQUFBLEtBRmhCRTtBQUFhLElBQUFvQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJBcnJvd0Rvd25MZWZ0IiwiQXJyb3dVcFJpZ2h0IiwiQ29weSIsIkV5ZSIsIkV5ZU9mZiIsIkhpc3RvcnkiLCJXYWxsZXRDYXJkcyIsInVzZVN0YXRlIiwiTGluayIsIlF1ZXJ5RXJyb3IiLCJRdWVyeVNrZWxldG9uIiwiZm9ybWF0TW9uZXkiLCJUcmFuc2FjdGlvbkxpc3QiLCJ1c2VUcmFuc2FjdGlvbnMiLCJ1c2VXYWxsZXQiLCJEYXNoYm9hcmRQYWdlIiwiX3MiLCJ3YWxsZXQiLCJyZWNlbnQiLCJiYWxhbmNlVmlzaWJsZSIsInNldEJhbGFuY2VWaXNpYmxlIiwiY29waWVkIiwic2V0Q29waWVkIiwiY29weUNvZGUiLCJkYXRhIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwiY29kZSIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJpc1BlbmRpbmciLCJpc0Vycm9yIiwicmVmZXRjaCIsImJhbGFuY2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJkYXNoYm9hcmQtcGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJyb3dEb3duTGVmdCwgQXJyb3dVcFJpZ2h0LCBDb3B5LCBFeWUsIEV5ZU9mZiwgSGlzdG9yeSwgV2FsbGV0Q2FyZHMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBRdWVyeUVycm9yLCBRdWVyeVNrZWxldG9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9xdWVyeS1zdGF0ZSdcbmltcG9ydCB7IGZvcm1hdE1vbmV5IH0gZnJvbSAnLi4vLi4vLi4vbGliL2Zvcm1hdCdcbmltcG9ydCB7IFRyYW5zYWN0aW9uTGlzdCB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy9jb21wb25lbnRzL3RyYW5zYWN0aW9uLWxpc3QnXG5pbXBvcnQgeyB1c2VUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvaG9va3MnXG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICcuLi9ob29rcydcblxuLyoqIEfDvG5jZWwgYmFraXllLCBjw7x6ZGFuIGtvZHUsIGjEsXpsxLEgacWfbGVtbGVyIHZlIHNvbiB0cmFuc2ZlcmxlcmkgZ8O2c3RlcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIERhc2hib2FyZFBhZ2UoKSB7XG4gIGNvbnN0IHdhbGxldCA9IHVzZVdhbGxldCgpXG4gIGNvbnN0IHJlY2VudCA9IHVzZVRyYW5zYWN0aW9ucygxLCA1KVxuICBjb25zdCBbYmFsYW5jZVZpc2libGUsIHNldEJhbGFuY2VWaXNpYmxlXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgY29weUNvZGUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCF3YWxsZXQuZGF0YSkgcmV0dXJuXG4gICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQod2FsbGV0LmRhdGEuY29kZSlcbiAgICBzZXRDb3BpZWQodHJ1ZSlcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCAyMDAwKVxuICB9XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtc3RhY2tcIj5cbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInBhZ2UtaGVhZGluZ1wiPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+R0VORUwgQkFLScWePC9zcGFuPjxoMT5Dw7x6ZGFuxLFuxLF6LCB0ZWsgZWtyYW5kYS48L2gxPjxwPkJha2l5ZW5pemkgdmUgc29uIGhhcmVrZXRsZXJpbml6aSBidXJhZGFuIHRha2lwIGVkaW4uPC9wPjwvaGVhZGVyPlxuICAgIHt3YWxsZXQuaXNQZW5kaW5nID8gPFF1ZXJ5U2tlbGV0b24gLz4gOiB3YWxsZXQuaXNFcnJvciA/IDxRdWVyeUVycm9yIHJldHJ5PXsoKSA9PiB2b2lkIHdhbGxldC5yZWZldGNoKCl9IC8+IDogPGRpdiBjbGFzc05hbWU9XCJvdmVydmlldy1ncmlkXCI+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiYWxhbmNlLWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cImJhbGFuY2UtdG9wXCI+PHNwYW4+VE9QTEFNIEJBS8SwWUU8L3NwYW4+PFdhbGxldENhcmRzIHNpemU9ezI0fSAvPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYmFsYW5jZS1udW1iZXJcIj57YmFsYW5jZVZpc2libGUgPyBmb3JtYXRNb25leSh3YWxsZXQuZGF0YS5iYWxhbmNlKSA6ICfigKLigKLigKLigKLigKLigKLigKLigKInfSA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRCYWxhbmNlVmlzaWJsZSghYmFsYW5jZVZpc2libGUpfSBhcmlhLWxhYmVsPXtiYWxhbmNlVmlzaWJsZSA/ICdCYWtpeWV5aSBnaXpsZScgOiAnQmFraXlleWkgZ8O2c3Rlcid9PntiYWxhbmNlVmlzaWJsZSA/IDxFeWVPZmYgc2l6ZT17MjB9IC8+IDogPEV5ZSBzaXplPXsyMH0gLz59PC9idXR0b24+PC9kaXY+PHA+R8O8bmNlbCBrdWxsYW7EsWxhYmlsaXIgYmFraXllbml6PC9wPjxkaXYgY2xhc3NOYW1lPVwiYmFsYW5jZS1kZWNvclwiIC8+PC9zZWN0aW9uPlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwid2FsbGV0LWNvZGUtY2FyZFwiPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+Q8OcWkRBTiBLT0RVTlVaPC9zcGFuPjxoMj7DlmRlbWUgYWxtYWsgYXJ0xLFrIGtvbGF5LjwvaDI+PHA+S29kdW51enUgcGF5bGHFn2FyYWsgdHJhbnNmZXIgYWxhYmlsaXJzaW5pei48L3A+PGRpdiBjbGFzc05hbWU9XCJ3YWxsZXQtY29kZS1saW5lXCI+PGNvZGU+e3dhbGxldC5kYXRhLmNvZGV9PC9jb2RlPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHZvaWQgY29weUNvZGUoKX0gYXJpYS1sYWJlbD1cIkPDvHpkYW4ga29kdW51IGtvcHlhbGFcIj48Q29weSBzaXplPXsxOH0gLz48L2J1dHRvbj48L2Rpdj48c21hbGwgcm9sZT1cInN0YXR1c1wiPntjb3BpZWQgPyAnS29kIGtvcHlhbGFuZMSxJyA6ICdLb2R1IGfDvHZlbmxlIHBheWxhxZ9hYmlsaXJzaW5peid9PC9zbWFsbD48L3NlY3Rpb24+XG4gICAgPC9kaXY+fVxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnQtc2VjdGlvblwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJjYXJkLWtpY2tlclwiPkhJWkxJIEVSxLDFnsSwTTwvc3Bhbj48aDI+TmUgeWFwbWFrIGlzdGVyc2luaXo/PC9oMj48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInF1aWNrLWFjdGlvbnNcIj48TGluayB0bz1cIi9kZXBvc2l0XCI+PHNwYW4gY2xhc3NOYW1lPVwiYWN0aW9uLWljb24gbWludFwiPjxBcnJvd0Rvd25MZWZ0IC8+PC9zcGFuPjxzdHJvbmc+UGFyYSB5YXTEsXI8L3N0cm9uZz48c21hbGw+QmFraXllbml6aSBhcnTEsXLEsW48L3NtYWxsPjwvTGluaz48TGluayB0bz1cIi93aXRoZHJhd1wiPjxzcGFuIGNsYXNzTmFtZT1cImFjdGlvbi1pY29uIGNvcmFsXCI+PEFycm93VXBSaWdodCAvPjwvc3Bhbj48c3Ryb25nPlBhcmEgw6dlazwvc3Ryb25nPjxzbWFsbD5CYWtpeWVuaXppIGt1bGxhbsSxbjwvc21hbGw+PC9MaW5rPjxMaW5rIHRvPVwiL3RyYW5zZmVyXCI+PHNwYW4gY2xhc3NOYW1lPVwiYWN0aW9uLWljb24gbGlsYWNcIj48QXJyb3dVcFJpZ2h0IC8+PC9zcGFuPjxzdHJvbmc+VHJhbnNmZXIgeWFwPC9zdHJvbmc+PHNtYWxsPktvbGF5Y2EgcGFyYSBnw7ZuZGVyaW48L3NtYWxsPjwvTGluaz48L2Rpdj48L3NlY3Rpb24+XG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udGVudC1zZWN0aW9uXCI+PGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRpbmdcIj48ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+SEVTQVAgSEFSRUtFVExFUsSwPC9zcGFuPjxoMj5Tb24gdHJhbnNmZXJsZXI8L2gyPjwvZGl2PjxMaW5rIHRvPVwiL3RyYW5zYWN0aW9uc1wiPlTDvG3DvG7DvCBnw7ZyIDxIaXN0b3J5IHNpemU9ezE1fSAvPjwvTGluaz48L2Rpdj57cmVjZW50LmlzUGVuZGluZyA/IDxRdWVyeVNrZWxldG9uIC8+IDogcmVjZW50LmlzRXJyb3IgPyA8UXVlcnlFcnJvciByZXRyeT17KCkgPT4gdm9pZCByZWNlbnQucmVmZXRjaCgpfSAvPiA6IDxUcmFuc2FjdGlvbkxpc3QgaXRlbXM9e3JlY2VudC5kYXRhfSAvPn08L3NlY3Rpb24+XG4gIDwvZGl2PlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWxsZXQvcGFnZXMvZGFzaGJvYXJkLXBhZ2UudHN4In0=