import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transactions/components/transaction-list.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArrowDownLeft, ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import { formatDate, formatMoney } from "/src/lib/format.ts";
export function TransactionList({ items, onSelect }) {
  if (!items.length) return /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: "Henüz işlem yok. İlk transferiniz burada görünecek." }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
    lineNumber: 7,
    columnNumber: 29
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "transaction-list", children: items.map((item, index) => {
    const incoming = item.type === "In";
    return /* @__PURE__ */ jsxDEV("button", { className: "transaction-row", type: "button", onClick: () => onSelect?.(item), children: [
      /* @__PURE__ */ jsxDEV("span", { className: `transaction-symbol ${incoming ? "incoming" : "outgoing"}`, children: incoming ? /* @__PURE__ */ jsxDEV(ArrowDownLeft, { size: 19 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
        lineNumber: 11,
        columnNumber: 96
      }, this) : /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 19 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
        lineNumber: 11,
        columnNumber: 126
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
        lineNumber: 11,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "transaction-main", children: [
        /* @__PURE__ */ jsxDEV("strong", { children: incoming ? "Gelen transfer" : "Giden transfer" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
          lineNumber: 12,
          columnNumber: 42
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: [
          item.walletCode,
          " · ",
          item.description
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
          lineNumber: 12,
          columnNumber: 107
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
        lineNumber: 12,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "transaction-side", children: [
        /* @__PURE__ */ jsxDEV("strong", { className: incoming ? "positive" : "", children: [
          incoming ? "+" : "−",
          formatMoney(item.amount)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
          lineNumber: 13,
          columnNumber: 42
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: formatDate(item.createdAt) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
          lineNumber: 13,
          columnNumber: 146
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
        lineNumber: 13,
        columnNumber: 7
      }, this)
    ] }, `${item.createdAt}-${item.walletCode}-${index}`, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
      lineNumber: 10,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = TransactionList;
var _c;
$RefreshReg$(_c, "TransactionList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transactions/components/transaction-list.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTTRCO0FBTjVCLFNBQVNBLGVBQWVDLG9CQUFvQjtBQUM1QyxTQUFTQyxZQUFZQyxtQkFBbUI7QUFJakMsZ0JBQVNDLGdCQUFnQixFQUFFQyxPQUFPQyxTQUFtRixHQUFHO0FBQzdILE1BQUksQ0FBQ0QsTUFBTUUsT0FBUSxRQUFPLHVCQUFDLFNBQUksV0FBVSxlQUFjLG1FQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWdGO0FBQzFHLFNBQU8sdUJBQUMsU0FBSSxXQUFVLG9CQUFvQkYsZ0JBQU1HLElBQUksQ0FBQ0MsTUFBTUMsVUFBVTtBQUNuRSxVQUFNQyxXQUFXRixLQUFLRyxTQUFTO0FBQy9CLFdBQU8sdUJBQUMsWUFBTyxXQUFVLG1CQUFrQixNQUFLLFVBQStELFNBQVMsTUFBTU4sV0FBV0csSUFBSSxHQUMzSTtBQUFBLDZCQUFDLFVBQUssV0FBVyxzQkFBc0JFLFdBQVcsYUFBYSxVQUFVLElBQUtBLHFCQUFXLHVCQUFDLGlCQUFjLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QixJQUFNLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QixLQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtKO0FBQUEsTUFDbEosdUJBQUMsVUFBSyxXQUFVLG9CQUFtQjtBQUFBLCtCQUFDLFlBQVFBLHFCQUFXLG1CQUFtQixvQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQVMsdUJBQUMsV0FBT0Y7QUFBQUEsZUFBS0k7QUFBQUEsVUFBVztBQUFBLFVBQUlKLEtBQUtLO0FBQUFBLGFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlKO0FBQUEsTUFDekosdUJBQUMsVUFBSyxXQUFVLG9CQUFtQjtBQUFBLCtCQUFDLFlBQU8sV0FBV0gsV0FBVyxhQUFhLElBQUtBO0FBQUFBLHFCQUFXLE1BQU07QUFBQSxVQUFLUixZQUFZTSxLQUFLTSxNQUFNO0FBQUEsYUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQVMsdUJBQUMsV0FBT2IscUJBQVdPLEtBQUtPLFNBQVMsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFdBQTlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0w7QUFBQSxTQUgxSCxHQUFHUCxLQUFLTyxTQUFTLElBQUlQLEtBQUtJLFVBQVUsSUFBSUgsS0FBSyxJQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSVA7QUFBQSxFQUNGLENBQUMsS0FQTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0o7QUFDTDtBQUFDTyxLQVZlYjtBQUFlLElBQUFhO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFycm93RG93bkxlZnQiLCJBcnJvd1VwUmlnaHQiLCJmb3JtYXREYXRlIiwiZm9ybWF0TW9uZXkiLCJUcmFuc2FjdGlvbkxpc3QiLCJpdGVtcyIsIm9uU2VsZWN0IiwibGVuZ3RoIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaW5jb21pbmciLCJ0eXBlIiwid2FsbGV0Q29kZSIsImRlc2NyaXB0aW9uIiwiYW1vdW50IiwiY3JlYXRlZEF0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidHJhbnNhY3Rpb24tbGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJyb3dEb3duTGVmdCwgQXJyb3dVcFJpZ2h0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgZm9ybWF0RGF0ZSwgZm9ybWF0TW9uZXkgfSBmcm9tICcuLi8uLi8uLi9saWIvZm9ybWF0J1xuaW1wb3J0IHR5cGUgeyBUcmFuc2FjdGlvbkl0ZW0gfSBmcm9tICcuLi9hcGknXG5cbi8qKiBHZWxlbiB2ZSBnaWRlbiBpxZ9sZW1sZXJpIG1ldGluLCBpa29uIHZlIHR1dGFybGEgYcOnxLFrIGJpw6dpbWRlIGxpc3RlbGVyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zYWN0aW9uTGlzdCh7IGl0ZW1zLCBvblNlbGVjdCB9OiB7IGl0ZW1zOiBUcmFuc2FjdGlvbkl0ZW1bXTsgb25TZWxlY3Q/OiAoaXRlbTogVHJhbnNhY3Rpb25JdGVtKSA9PiB2b2lkIH0pIHtcbiAgaWYgKCFpdGVtcy5sZW5ndGgpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+SGVuw7x6IGnFn2xlbSB5b2suIMSwbGsgdHJhbnNmZXJpbml6IGJ1cmFkYSBnw7Zyw7xuZWNlay48L2Rpdj5cbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidHJhbnNhY3Rpb24tbGlzdFwiPntpdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgY29uc3QgaW5jb21pbmcgPSBpdGVtLnR5cGUgPT09ICdJbidcbiAgICByZXR1cm4gPGJ1dHRvbiBjbGFzc05hbWU9XCJ0cmFuc2FjdGlvbi1yb3dcIiB0eXBlPVwiYnV0dG9uXCIga2V5PXtgJHtpdGVtLmNyZWF0ZWRBdH0tJHtpdGVtLndhbGxldENvZGV9LSR7aW5kZXh9YH0gb25DbGljaz17KCkgPT4gb25TZWxlY3Q/LihpdGVtKX0+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2B0cmFuc2FjdGlvbi1zeW1ib2wgJHtpbmNvbWluZyA/ICdpbmNvbWluZycgOiAnb3V0Z29pbmcnfWB9PntpbmNvbWluZyA/IDxBcnJvd0Rvd25MZWZ0IHNpemU9ezE5fSAvPiA6IDxBcnJvd1VwUmlnaHQgc2l6ZT17MTl9IC8+fTwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRyYW5zYWN0aW9uLW1haW5cIj48c3Ryb25nPntpbmNvbWluZyA/ICdHZWxlbiB0cmFuc2ZlcicgOiAnR2lkZW4gdHJhbnNmZXInfTwvc3Ryb25nPjxzbWFsbD57aXRlbS53YWxsZXRDb2RlfSDCtyB7aXRlbS5kZXNjcmlwdGlvbn08L3NtYWxsPjwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRyYW5zYWN0aW9uLXNpZGVcIj48c3Ryb25nIGNsYXNzTmFtZT17aW5jb21pbmcgPyAncG9zaXRpdmUnIDogJyd9PntpbmNvbWluZyA/ICcrJyA6ICfiiJInfXtmb3JtYXRNb25leShpdGVtLmFtb3VudCl9PC9zdHJvbmc+PHNtYWxsPntmb3JtYXREYXRlKGl0ZW0uY3JlYXRlZEF0KX08L3NtYWxsPjwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgfSl9PC9kaXY+XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3RyYW5zYWN0aW9ucy9jb21wb25lbnRzL3RyYW5zYWN0aW9uLWxpc3QudHN4In0=