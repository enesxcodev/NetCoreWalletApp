import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/contacts/contacts-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ChevronLeft, ChevronRight, UsersRound } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { QueryError, QuerySkeleton } from "/src/components/query-state.tsx";
import { ContactSearch } from "/src/features/contacts/components/contact-search.tsx";
import { ContactsTable } from "/src/features/contacts/components/contacts-table.tsx";
import { useTransferContacts } from "/src/features/contacts/hooks.ts";
export function ContactsPage() {
  _s();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const timeout = window.setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => window.clearTimeout(timeout);
  }, [search]);
  const contacts = useTransferContacts(debouncedSearch, page);
  const isTyping = search.trim() !== debouncedSearch;
  const changeSearch = (value) => {
    setSearch(value);
    setPage(1);
  };
  const totalPages = contacts.data ? Math.max(1, Math.ceil(contacts.data.totalCount / contacts.data.pageSize)) : 1;
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "TRANSFER REHBERİ" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 25,
        columnNumber: 38
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: "Transfer Kişileri" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 25,
        columnNumber: 91
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Alıcıyı bulun, cüzdan kodunu kopyalayın ve transferinizde kullanın." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 25,
        columnNumber: 117
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
      lineNumber: 25,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "content-section contacts-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "contacts-section-top", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "contacts-section-icon", children: /* @__PURE__ */ jsxDEV(UsersRound, { size: 21 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 26,
          columnNumber: 137
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 26,
          columnNumber: 97
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Kişiler" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
            lineNumber: 26,
            columnNumber: 173
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Cüzdanı olan kullanıcılar listelenir." }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
            lineNumber: 26,
            columnNumber: 189
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 26,
          columnNumber: 168
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 26,
        columnNumber: 59
      }, this),
      /* @__PURE__ */ jsxDEV(ContactSearch, { value: search, onChange: changeSearch }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 27,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "contacts-results-heading", children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Sonuçlar" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 28,
          columnNumber: 49
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: contacts.data && !isTyping ? `${contacts.data.totalCount} kişi` : "Aranıyor..." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 28,
          columnNumber: 74
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 28,
        columnNumber: 7
      }, this),
      isTyping || contacts.isPending ? /* @__PURE__ */ jsxDEV(QuerySkeleton, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 29,
        columnNumber: 41
      }, this) : contacts.isError ? /* @__PURE__ */ jsxDEV(QueryError, { retry: () => void contacts.refetch() }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 29,
        columnNumber: 80
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(ContactsTable, { contacts: contacts.data.items, searched: Boolean(debouncedSearch) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 29,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pagination", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setPage((current) => current - 1), disabled: page === 1, children: [
            /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
              fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
              lineNumber: 29,
              columnNumber: 343
            }, this),
            " Önceki"
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
            lineNumber: 29,
            columnNumber: 249
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Sayfa ",
            page,
            " / ",
            totalPages
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
            lineNumber: 29,
            columnNumber: 384
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setPage((current) => current + 1), disabled: page >= totalPages, children: [
            "Sonraki ",
            /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
              fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
              lineNumber: 29,
              columnNumber: 534
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
            lineNumber: 29,
            columnNumber: 424
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
          lineNumber: 29,
          columnNumber: 221
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
        lineNumber: 29,
        columnNumber: 135
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
      lineNumber: 26,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_s(ContactsPage, "cZPfYV2HoOTvIrBqu7R7izPKmNQ=", false, function() {
  return [useTransferContacts];
});
_c = ContactsPage;
var _c;
$RefreshReg$(_c, "ContactsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/contacts-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JxQyxTQUlpRyxVQUpqRzs7QUF4QnJDLFNBQVNBLGFBQWFDLGNBQWNDLGtCQUFrQjtBQUN0RCxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsWUFBWUMscUJBQXFCO0FBQzFDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsMkJBQTJCO0FBRzdCLGdCQUFTQyxlQUFlO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlULFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNVLGlCQUFpQkMsa0JBQWtCLElBQUlYLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNZLE1BQU1DLE9BQU8sSUFBSWIsU0FBUyxDQUFDO0FBRWxDRCxZQUFVLE1BQU07QUFDZCxVQUFNZSxVQUFVQyxPQUFPQyxXQUFXLE1BQU1MLG1CQUFtQkgsT0FBT1MsS0FBSyxDQUFDLEdBQUcsR0FBRztBQUM5RSxXQUFPLE1BQU1GLE9BQU9HLGFBQWFKLE9BQU87QUFBQSxFQUMxQyxHQUFHLENBQUNOLE1BQU0sQ0FBQztBQUVYLFFBQU1XLFdBQVdkLG9CQUFvQkssaUJBQWlCRSxJQUFJO0FBQzFELFFBQU1RLFdBQVdaLE9BQU9TLEtBQUssTUFBTVA7QUFDbkMsUUFBTVcsZUFBZUEsQ0FBQ0MsVUFBa0I7QUFBRWIsY0FBVWEsS0FBSztBQUFHVCxZQUFRLENBQUM7QUFBQSxFQUFFO0FBQ3ZFLFFBQU1VLGFBQWFKLFNBQVNLLE9BQU9DLEtBQUtDLElBQUksR0FBR0QsS0FBS0UsS0FBS1IsU0FBU0ssS0FBS0ksYUFBYVQsU0FBU0ssS0FBS0ssUUFBUSxDQUFDLElBQUk7QUFFL0csU0FBTyx1QkFBQyxTQUFJLFdBQVUsaUJBQ3BCO0FBQUEsMkJBQUMsWUFBTyxXQUFVLGdCQUFlO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGVBQWMsZ0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUFPLHVCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQjtBQUFBLE1BQUssdUJBQUMsT0FBRSxtRkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsU0FBdEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwTDtBQUFBLElBQzFMLHVCQUFDLGFBQVEsV0FBVSxvQ0FBbUM7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0JBQXVCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHlCQUF3QixpQ0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFBTyx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsUUFBRyx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFBSyx1QkFBQyxPQUFFLHFEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFdBQTlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0w7QUFBQSxNQUN4Tyx1QkFBQyxpQkFBYyxPQUFPckIsUUFBUSxVQUFVYSxnQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQ3JELHVCQUFDLFNBQUksV0FBVSw0QkFBMkI7QUFBQSwrQkFBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUFTLHVCQUFDLFVBQU1GLG1CQUFTSyxRQUFRLENBQUNKLFdBQVcsR0FBR0QsU0FBU0ssS0FBS0ksVUFBVSxVQUFVLGlCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSztBQUFBLE1BQ2hLUixZQUFZRCxTQUFTVyxZQUFZLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxJQUFNWCxTQUFTWSxVQUFVLHVCQUFDLGNBQVcsT0FBTyxNQUFNLEtBQUtaLFNBQVNhLFFBQVEsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRCxJQUFNLG1DQUFFO0FBQUEsK0JBQUMsaUJBQWMsVUFBVWIsU0FBU0ssS0FBS1MsT0FBTyxVQUFVQyxRQUFReEIsZUFBZSxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFBRyx1QkFBQyxTQUFJLFdBQVUsY0FBYTtBQUFBLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUcsUUFBUSxDQUFDc0IsWUFBWUEsVUFBVSxDQUFDLEdBQUcsVUFBVXZCLFNBQVMsR0FBRztBQUFBLG1DQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLFlBQUc7QUFBQSxlQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SDtBQUFBLFVBQVMsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBT0E7QUFBQUEsWUFBSztBQUFBLFlBQUlXO0FBQUFBLGVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFBTyx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1WLFFBQVEsQ0FBQ3NCLFlBQVlBLFVBQVUsQ0FBQyxHQUFHLFVBQVV2QixRQUFRVyxZQUFZO0FBQUE7QUFBQSxZQUFRLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxlQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3STtBQUFBLGFBQW5WO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNFY7QUFBQSxXQUFsYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdiO0FBQUEsU0FIMWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLE9BTks7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9QO0FBQ0Y7QUFBQ2hCLEdBdkJlRCxjQUFZO0FBQUEsVUFVVEQsbUJBQW1CO0FBQUE7QUFBQSxLQVZ0QkM7QUFBWSxJQUFBOEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJVc2Vyc1JvdW5kIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJRdWVyeUVycm9yIiwiUXVlcnlTa2VsZXRvbiIsIkNvbnRhY3RTZWFyY2giLCJDb250YWN0c1RhYmxlIiwidXNlVHJhbnNmZXJDb250YWN0cyIsIkNvbnRhY3RzUGFnZSIsIl9zIiwic2VhcmNoIiwic2V0U2VhcmNoIiwiZGVib3VuY2VkU2VhcmNoIiwic2V0RGVib3VuY2VkU2VhcmNoIiwicGFnZSIsInNldFBhZ2UiLCJ0aW1lb3V0Iiwid2luZG93Iiwic2V0VGltZW91dCIsInRyaW0iLCJjbGVhclRpbWVvdXQiLCJjb250YWN0cyIsImlzVHlwaW5nIiwiY2hhbmdlU2VhcmNoIiwidmFsdWUiLCJ0b3RhbFBhZ2VzIiwiZGF0YSIsIk1hdGgiLCJtYXgiLCJjZWlsIiwidG90YWxDb3VudCIsInBhZ2VTaXplIiwiaXNQZW5kaW5nIiwiaXNFcnJvciIsInJlZmV0Y2giLCJpdGVtcyIsIkJvb2xlYW4iLCJjdXJyZW50IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY29udGFjdHMtcGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2hldnJvbkxlZnQsIENoZXZyb25SaWdodCwgVXNlcnNSb3VuZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFF1ZXJ5RXJyb3IsIFF1ZXJ5U2tlbGV0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3F1ZXJ5LXN0YXRlJ1xuaW1wb3J0IHsgQ29udGFjdFNlYXJjaCB9IGZyb20gJy4vY29tcG9uZW50cy9jb250YWN0LXNlYXJjaCdcbmltcG9ydCB7IENvbnRhY3RzVGFibGUgfSBmcm9tICcuL2NvbXBvbmVudHMvY29udGFjdHMtdGFibGUnXG5pbXBvcnQgeyB1c2VUcmFuc2ZlckNvbnRhY3RzIH0gZnJvbSAnLi9ob29rcydcblxuLyoqIEFyYW1hecSxIGdlY2lrdGlyZXJlayBBUEkneWUgZ8O2bmRlcmlyOyBzb251w6cgdGFibG9zdSB2ZSBzYXlmYWxhbWF5xLEgecO2bmV0aXIuICovXG5leHBvcnQgZnVuY3Rpb24gQ29udGFjdHNQYWdlKCkge1xuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtkZWJvdW5jZWRTZWFyY2gsIHNldERlYm91bmNlZFNlYXJjaF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHRpbWVvdXQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXREZWJvdW5jZWRTZWFyY2goc2VhcmNoLnRyaW0oKSksIDMwMClcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0KVxuICB9LCBbc2VhcmNoXSlcblxuICBjb25zdCBjb250YWN0cyA9IHVzZVRyYW5zZmVyQ29udGFjdHMoZGVib3VuY2VkU2VhcmNoLCBwYWdlKVxuICBjb25zdCBpc1R5cGluZyA9IHNlYXJjaC50cmltKCkgIT09IGRlYm91bmNlZFNlYXJjaFxuICBjb25zdCBjaGFuZ2VTZWFyY2ggPSAodmFsdWU6IHN0cmluZykgPT4geyBzZXRTZWFyY2godmFsdWUpOyBzZXRQYWdlKDEpIH1cbiAgY29uc3QgdG90YWxQYWdlcyA9IGNvbnRhY3RzLmRhdGEgPyBNYXRoLm1heCgxLCBNYXRoLmNlaWwoY29udGFjdHMuZGF0YS50b3RhbENvdW50IC8gY29udGFjdHMuZGF0YS5wYWdlU2l6ZSkpIDogMVxuXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtc3RhY2tcIj5cbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInBhZ2UtaGVhZGluZ1wiPjxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+VFJBTlNGRVIgUkVIQkVSxLA8L3NwYW4+PGgxPlRyYW5zZmVyIEtpxZ9pbGVyaTwvaDE+PHA+QWzEsWPEsXnEsSBidWx1biwgY8O8emRhbiBrb2R1bnUga29weWFsYXnEsW4gdmUgdHJhbnNmZXJpbml6ZGUga3VsbGFuxLFuLjwvcD48L2hlYWRlcj5cbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjb250ZW50LXNlY3Rpb24gY29udGFjdHMtc2VjdGlvblwiPjxkaXYgY2xhc3NOYW1lPVwiY29udGFjdHMtc2VjdGlvbi10b3BcIj48c3BhbiBjbGFzc05hbWU9XCJjb250YWN0cy1zZWN0aW9uLWljb25cIj48VXNlcnNSb3VuZCBzaXplPXsyMX0gLz48L3NwYW4+PGRpdj48aDI+S2nFn2lsZXI8L2gyPjxwPkPDvHpkYW7EsSBvbGFuIGt1bGxhbsSxY8SxbGFyIGxpc3RlbGVuaXIuPC9wPjwvZGl2PjwvZGl2PlxuICAgICAgPENvbnRhY3RTZWFyY2ggdmFsdWU9e3NlYXJjaH0gb25DaGFuZ2U9e2NoYW5nZVNlYXJjaH0gLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdHMtcmVzdWx0cy1oZWFkaW5nXCI+PHN0cm9uZz5Tb251w6dsYXI8L3N0cm9uZz48c3Bhbj57Y29udGFjdHMuZGF0YSAmJiAhaXNUeXBpbmcgPyBgJHtjb250YWN0cy5kYXRhLnRvdGFsQ291bnR9IGtpxZ9pYCA6ICdBcmFuxLF5b3IuLi4nfTwvc3Bhbj48L2Rpdj5cbiAgICAgIHtpc1R5cGluZyB8fCBjb250YWN0cy5pc1BlbmRpbmcgPyA8UXVlcnlTa2VsZXRvbiAvPiA6IGNvbnRhY3RzLmlzRXJyb3IgPyA8UXVlcnlFcnJvciByZXRyeT17KCkgPT4gdm9pZCBjb250YWN0cy5yZWZldGNoKCl9IC8+IDogPD48Q29udGFjdHNUYWJsZSBjb250YWN0cz17Y29udGFjdHMuZGF0YS5pdGVtc30gc2VhcmNoZWQ9e0Jvb2xlYW4oZGVib3VuY2VkU2VhcmNoKX0gLz48ZGl2IGNsYXNzTmFtZT1cInBhZ2luYXRpb25cIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKChjdXJyZW50KSA9PiBjdXJyZW50IC0gMSl9IGRpc2FibGVkPXtwYWdlID09PSAxfT48Q2hldnJvbkxlZnQgc2l6ZT17MTZ9IC8+IMOWbmNla2k8L2J1dHRvbj48c3Bhbj5TYXlmYSB7cGFnZX0gLyB7dG90YWxQYWdlc308L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0UGFnZSgoY3VycmVudCkgPT4gY3VycmVudCArIDEpfSBkaXNhYmxlZD17cGFnZSA+PSB0b3RhbFBhZ2VzfT5Tb25yYWtpIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+PC8+fVxuICAgIDwvc2VjdGlvbj5cbiAgPC9kaXY+XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2NvbnRhY3RzL2NvbnRhY3RzLXBhZ2UudHN4In0=