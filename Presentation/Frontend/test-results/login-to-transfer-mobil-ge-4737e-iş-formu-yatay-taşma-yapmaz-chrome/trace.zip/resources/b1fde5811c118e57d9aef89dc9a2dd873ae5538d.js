import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/query-state.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
export function QueryError({ retry }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "query-error", role: "alert", children: [
    /* @__PURE__ */ jsxDEV("strong", { children: "Bilgiler yüklenemedi" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 5,
      columnNumber: 52
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Bağlantıyı kontrol edip yeniden deneyin." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 5,
      columnNumber: 89
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: retry, children: [
      /* @__PURE__ */ jsxDEV(RefreshCw, { size: 15 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
        lineNumber: 5,
        columnNumber: 174
      }, this),
      " Tekrar dene"
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 5,
      columnNumber: 136
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = QueryError;
export function QuerySkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { className: "query-skeleton", "aria-label": "Bilgiler yükleniyor", "aria-busy": "true", children: [
    /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 10,
      columnNumber: 92
    }, this),
    /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 10,
      columnNumber: 100
    }, this),
    /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
      lineNumber: 10,
      columnNumber: 108
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_c2 = QuerySkeleton;
var _c, _c2;
$RefreshReg$(_c, "QueryError");
$RefreshReg$(_c2, "QuerySkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/query-state.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSW1EO0FBSm5ELFNBQVNBLGlCQUFpQjtBQUduQixnQkFBU0MsV0FBVyxFQUFFQyxNQUE2QixHQUFHO0FBQzNELFNBQU8sdUJBQUMsU0FBSSxXQUFVLGVBQWMsTUFBSyxTQUFRO0FBQUEsMkJBQUMsWUFBTyxvQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFBUyx1QkFBQyxPQUFFLHdEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkM7QUFBQSxJQUFJLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNBLE9BQU87QUFBQSw2QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLE1BQUc7QUFBQSxTQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlFO0FBQUEsT0FBdk07QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnTjtBQUN6TjtBQUVBQyxLQUpnQkY7QUFLVCxnQkFBU0csZ0JBQWdCO0FBQzlCLFNBQU8sdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixjQUFXLHVCQUFzQixhQUFVLFFBQU87QUFBQSwyQkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLElBQUcsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUs7QUFBQSxJQUFHLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsT0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwRztBQUNuSDtBQUFDQyxNQUZlRDtBQUFhLElBQUFELElBQUFFO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJSZWZyZXNoQ3ciLCJRdWVyeUVycm9yIiwicmV0cnkiLCJfYyIsIlF1ZXJ5U2tlbGV0b24iLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsicXVlcnktc3RhdGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJlZnJlc2hDdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuLyoqIFNvcmd1IGhhdGFzxLFuxLEgdGVrbmlrIGF5csSxbnTEsSBnw7ZzdGVybWVkZW4gdGVrcmFyIGRlbmVtZSBha3NpeW9udXlsYSBzdW5hci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBRdWVyeUVycm9yKHsgcmV0cnkgfTogeyByZXRyeTogKCkgPT4gdm9pZCB9KSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInF1ZXJ5LWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+PHN0cm9uZz5CaWxnaWxlciB5w7xrbGVuZW1lZGk8L3N0cm9uZz48cD5CYcSfbGFudMSxecSxIGtvbnRyb2wgZWRpcCB5ZW5pZGVuIGRlbmV5aW4uPC9wPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e3JldHJ5fT48UmVmcmVzaEN3IHNpemU9ezE1fSAvPiBUZWtyYXIgZGVuZTwvYnV0dG9uPjwvZGl2PlxufVxuXG4vKiogVmVyaW5pbiBiZWtsZW5tZXNpIHPEsXJhc8SxbmRhIGJvxZ8gZWtyYW4geWVyaW5lIGlza2VsZXQgZ8O2c3RlcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFF1ZXJ5U2tlbGV0b24oKSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInF1ZXJ5LXNrZWxldG9uXCIgYXJpYS1sYWJlbD1cIkJpbGdpbGVyIHnDvGtsZW5peW9yXCIgYXJpYS1idXN5PVwidHJ1ZVwiPjxzcGFuIC8+PHNwYW4gLz48c3BhbiAvPjwvZGl2PlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3F1ZXJ5LXN0YXRlLnRzeCJ9