import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/brand.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { WalletCards } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
export function Brand() {
  return /* @__PURE__ */ jsxDEV("a", { className: "brand", href: "/login", "aria-label": "Wallet ana sayfa", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "brand-mark", children: /* @__PURE__ */ jsxDEV(WalletCards, { size: 23, strokeWidth: 2.4 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
      lineNumber: 7,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Wallet" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
        lineNumber: 8,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("small", { children: "Dijital Cüzdan" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
        lineNumber: 8,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
_c = Brand;
var _c;
$RefreshReg$(_c, "Brand");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/brand.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTW1DO0FBTm5DLFNBQVNBLG1CQUFtQjtBQUdyQixnQkFBU0MsUUFBUTtBQUN0QixTQUNFLHVCQUFDLE9BQUUsV0FBVSxTQUFRLE1BQUssVUFBUyxjQUFXLG9CQUM1QztBQUFBLDJCQUFDLFVBQUssV0FBVSxjQUFhLGlDQUFDLGVBQVksTUFBTSxJQUFJLGFBQWEsT0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QyxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFO0FBQUEsSUFDeEUsdUJBQUMsVUFBSztBQUFBLDZCQUFDLFlBQU8sc0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFBUyx1QkFBQyxXQUFNLDhCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxTQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsT0FGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ0MsS0FQZUQ7QUFBSyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJXYWxsZXRDYXJkcyIsIkJyYW5kIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYnJhbmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFdhbGxldENhcmRzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG4vKiogV2FsbGV0IGFkxLFuxLEgZ2lyacWfIHZlIGthecSxdCBla3JhbmxhcsSxbmRhIG9ydGFrIGnFn2FyZXRsZSBnw7ZzdGVyaXIuICovXG5leHBvcnQgZnVuY3Rpb24gQnJhbmQoKSB7XG4gIHJldHVybiAoXG4gICAgPGEgY2xhc3NOYW1lPVwiYnJhbmRcIiBocmVmPVwiL2xvZ2luXCIgYXJpYS1sYWJlbD1cIldhbGxldCBhbmEgc2F5ZmFcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJyYW5kLW1hcmtcIj48V2FsbGV0Q2FyZHMgc2l6ZT17MjN9IHN0cm9rZVdpZHRoPXsyLjR9IC8+PC9zcGFuPlxuICAgICAgPHNwYW4+PHN0cm9uZz5XYWxsZXQ8L3N0cm9uZz48c21hbGw+RGlqaXRhbCBDw7x6ZGFuPC9zbWFsbD48L3NwYW4+XG4gICAgPC9hPlxuICApXG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvYnJhbmQudHN4In0=