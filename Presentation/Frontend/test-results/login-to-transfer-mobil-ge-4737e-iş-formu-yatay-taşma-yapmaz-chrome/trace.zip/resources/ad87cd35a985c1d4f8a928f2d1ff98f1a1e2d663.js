import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/auth-context.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { authToken } from "/src/lib/auth-token.ts";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=88909849";
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  _s();
  const queryClient = useQueryClient();
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    setToken(authToken.get());
    setIsLoading(false);
    const onUnauthorized = () => {
      queryClient.clear();
      setToken(null);
    };
    window.addEventListener("wallet:unauthorized", onUnauthorized);
    return () => window.removeEventListener("wallet:unauthorized", onUnauthorized);
  }, [queryClient]);
  const value = useMemo(
    () => ({
      token,
      isLoading,
      signIn: (nextToken) => {
        queryClient.clear();
        authToken.set(nextToken);
        setToken(nextToken);
      },
      signOut: () => {
        queryClient.clear();
        authToken.clear();
        setToken(null);
      }
    }),
    [token, isLoading, queryClient]
  );
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value, children }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/auth-context.tsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
}
_s(AuthProvider, "BSZhlB/IbWXaeGmgF+VNXZQWBoA=", false, function() {
  return [useQueryClient];
});
_c = AuthProvider;
export function useAuth() {
  _s2();
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth, AuthProvider içinde kullanılmalıdır.");
  return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/auth-context.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/auth-context.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/auth-context.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNTOztBQTdDVCxTQUFTQSxlQUFlQyxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBd0M7QUFDaEcsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHNCQUFzQjtBQVMvQixNQUFNQyxjQUFjUCxjQUF1QyxJQUFJO0FBR3hELGdCQUFTUSxhQUFhLEVBQUVDLFNBQTRCLEdBQUc7QUFBQUMsS0FBQTtBQUM1RCxRQUFNQyxjQUFjTCxlQUFlO0FBQ25DLFFBQU0sQ0FBQ00sT0FBT0MsUUFBUSxJQUFJVCxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ1UsV0FBV0MsWUFBWSxJQUFJWCxTQUFTLElBQUk7QUFFL0NGLFlBQVUsTUFBTTtBQUNkVyxhQUFTUixVQUFVVyxJQUFJLENBQUM7QUFDeEJELGlCQUFhLEtBQUs7QUFDbEIsVUFBTUUsaUJBQWlCQSxNQUFNO0FBQUVOLGtCQUFZTyxNQUFNO0FBQUdMLGVBQVMsSUFBSTtBQUFBLElBQUU7QUFDbkVNLFdBQU9DLGlCQUFpQix1QkFBdUJILGNBQWM7QUFDN0QsV0FBTyxNQUFNRSxPQUFPRSxvQkFBb0IsdUJBQXVCSixjQUFjO0FBQUEsRUFDL0UsR0FBRyxDQUFDTixXQUFXLENBQUM7QUFFaEIsUUFBTVcsUUFBUW5CO0FBQUFBLElBQ1osT0FBTztBQUFBLE1BQ0xTO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FTLFFBQVFBLENBQUNDLGNBQWM7QUFDckJiLG9CQUFZTyxNQUFNO0FBQ2xCYixrQkFBVW9CLElBQUlELFNBQVM7QUFDdkJYLGlCQUFTVyxTQUFTO0FBQUEsTUFDcEI7QUFBQSxNQUNBRSxTQUFTQSxNQUFNO0FBQ2JmLG9CQUFZTyxNQUFNO0FBQ2xCYixrQkFBVWEsTUFBTTtBQUNoQkwsaUJBQVMsSUFBSTtBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxDQUFDRCxPQUFPRSxXQUFXSCxXQUFXO0FBQUEsRUFDaEM7QUFFQSxTQUFPLHVCQUFDLFlBQVksVUFBWixFQUFxQixPQUFlRixZQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThDO0FBQ3ZEO0FBR0FDLEdBbkNnQkYsY0FBWTtBQUFBLFVBQ05GLGNBQWM7QUFBQTtBQUFBLEtBRHBCRTtBQW9DVCxnQkFBU21CLFVBQTRCO0FBQUFDLE1BQUE7QUFDMUMsUUFBTUMsVUFBVTVCLFdBQVdNLFdBQVc7QUFDdEMsTUFBSSxDQUFDc0IsUUFBUyxPQUFNLElBQUlDLE1BQU0sK0NBQStDO0FBQzdFLFNBQU9EO0FBQ1Q7QUFBQ0QsSUFKZUQsU0FBTztBQUFBLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiYXV0aFRva2VuIiwidXNlUXVlcnlDbGllbnQiLCJBdXRoQ29udGV4dCIsIkF1dGhQcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJxdWVyeUNsaWVudCIsInRva2VuIiwic2V0VG9rZW4iLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJnZXQiLCJvblVuYXV0aG9yaXplZCIsImNsZWFyIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJ2YWx1ZSIsInNpZ25JbiIsIm5leHRUb2tlbiIsInNldCIsInNpZ25PdXQiLCJ1c2VBdXRoIiwiX3MyIiwiY29udGV4dCIsIkVycm9yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXV0aC1jb250ZXh0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlLCB0eXBlIFByb3BzV2l0aENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBhdXRoVG9rZW4gfSBmcm9tICcuLi9saWIvYXV0aC10b2tlbidcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuXG5pbnRlcmZhY2UgQXV0aENvbnRleHRWYWx1ZSB7XG4gIHRva2VuOiBzdHJpbmcgfCBudWxsXG4gIGlzTG9hZGluZzogYm9vbGVhblxuICBzaWduSW46ICh0b2tlbjogc3RyaW5nKSA9PiB2b2lkXG4gIHNpZ25PdXQ6ICgpID0+IHZvaWRcbn1cblxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VmFsdWUgfCBudWxsPihudWxsKVxuXG4vKiogT3R1cnVtIGJpbGdpc2luaSByb3V0ZSBndWFyZCdsYXLEsSB2ZSBhdXRoIHNheWZhbGFyxLEgYXJhc8SxbmRhIHBheWxhxZ/EsXIuICovXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogUHJvcHNXaXRoQ2hpbGRyZW4pIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IFt0b2tlbiwgc2V0VG9rZW5dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRUb2tlbihhdXRoVG9rZW4uZ2V0KCkpXG4gICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxuICAgIGNvbnN0IG9uVW5hdXRob3JpemVkID0gKCkgPT4geyBxdWVyeUNsaWVudC5jbGVhcigpOyBzZXRUb2tlbihudWxsKSB9XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3dhbGxldDp1bmF1dGhvcml6ZWQnLCBvblVuYXV0aG9yaXplZClcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3dhbGxldDp1bmF1dGhvcml6ZWQnLCBvblVuYXV0aG9yaXplZClcbiAgfSwgW3F1ZXJ5Q2xpZW50XSlcblxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW88QXV0aENvbnRleHRWYWx1ZT4oXG4gICAgKCkgPT4gKHtcbiAgICAgIHRva2VuLFxuICAgICAgaXNMb2FkaW5nLFxuICAgICAgc2lnbkluOiAobmV4dFRva2VuKSA9PiB7XG4gICAgICAgIHF1ZXJ5Q2xpZW50LmNsZWFyKClcbiAgICAgICAgYXV0aFRva2VuLnNldChuZXh0VG9rZW4pXG4gICAgICAgIHNldFRva2VuKG5leHRUb2tlbilcbiAgICAgIH0sXG4gICAgICBzaWduT3V0OiAoKSA9PiB7XG4gICAgICAgIHF1ZXJ5Q2xpZW50LmNsZWFyKClcbiAgICAgICAgYXV0aFRva2VuLmNsZWFyKClcbiAgICAgICAgc2V0VG9rZW4obnVsbClcbiAgICAgIH0sXG4gICAgfSksXG4gICAgW3Rva2VuLCBpc0xvYWRpbmcsIHF1ZXJ5Q2xpZW50XSxcbiAgKVxuXG4gIHJldHVybiA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cbn1cblxuLyoqIFNhxJ9sYXnEsWPEsSBkxLHFn8SxbmRha2kga3VsbGFuxLFtIGhhdGFsYXLEsW7EsSBlcmtlbiBiaWxkaXJlcmVrIG90dXJ1bSBlcmnFn2ltaSBzYcSfbGFyLiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LXJlZnJlc2gvb25seS1leHBvcnQtY29tcG9uZW50c1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKTogQXV0aENvbnRleHRWYWx1ZSB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KEF1dGhDb250ZXh0KVxuICBpZiAoIWNvbnRleHQpIHRocm93IG5ldyBFcnJvcigndXNlQXV0aCwgQXV0aFByb3ZpZGVyIGnDp2luZGUga3VsbGFuxLFsbWFsxLFkxLFyLicpXG4gIHJldHVybiBjb250ZXh0XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2FwcC9hdXRoLWNvbnRleHQudHN4In0=