import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/route-guards.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { useAuth } from "/src/app/auth-context.tsx";
function RouteLoading() {
  return /* @__PURE__ */ jsxDEV("main", { className: "route-loading", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
      lineNumber: 6,
      columnNumber: 42
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Oturum kontrol ediliyor" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
      lineNumber: 6,
      columnNumber: 70
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
}
_c = RouteLoading;
export function ProtectedRoute() {
  _s();
  const { token, isLoading } = useAuth();
  const location = useLocation();
  if (isLoading) return /* @__PURE__ */ jsxDEV(RouteLoading, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 13,
    columnNumber: 25
  }, this);
  return token ? /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 14,
    columnNumber: 18
  }, this) : /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true, state: { from: location.pathname } }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 14,
    columnNumber: 31
  }, this);
}
_s(ProtectedRoute, "FHRDuXRhRiYMy3OvaAA70+9mPgE=", false, function() {
  return [useAuth, useLocation];
});
_c2 = ProtectedRoute;
export function PublicOnlyRoute() {
  _s2();
  const { token, isLoading } = useAuth();
  if (isLoading) return /* @__PURE__ */ jsxDEV(RouteLoading, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 20,
    columnNumber: 25
  }, this);
  return token ? /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard", replace: true }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 21,
    columnNumber: 18
  }, this) : /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx",
    lineNumber: 21,
    columnNumber: 57
  }, this);
}
_s2(PublicOnlyRoute, "zgSfpCMl3yV5JoA8eKsePgIoWw8=", false, function() {
  return [useAuth];
});
_c3 = PublicOnlyRoute;
var _c, _c2, _c3;
$RefreshReg$(_c, "RouteLoading");
$RefreshReg$(_c2, "ProtectedRoute");
$RefreshReg$(_c3, "PublicOnlyRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/routes/route-guards.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS3lDOztBQUx6QyxTQUFTQSxVQUFVQyxRQUFRQyxtQkFBbUI7QUFDOUMsU0FBU0MsZUFBZTtBQUd4QixTQUFTQyxlQUFlO0FBQ3RCLFNBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQjtBQUFBLDJCQUFDLFVBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFBRyx1QkFBQyxPQUFFLHVDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxPQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBGO0FBQ25HO0FBRUFDLEtBSlNEO0FBS0YsZ0JBQVNFLGlCQUFpQjtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sRUFBRUMsT0FBT0MsVUFBVSxJQUFJTixRQUFRO0FBQ3JDLFFBQU1PLFdBQVdSLFlBQVk7QUFDN0IsTUFBSU8sVUFBVyxRQUFPLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYTtBQUNuQyxTQUFPRCxRQUFRLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPLElBQU0sdUJBQUMsWUFBUyxJQUFHLFVBQVMsU0FBTyxNQUFDLE9BQU8sRUFBRUcsTUFBTUQsU0FBU0UsU0FBUyxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlFO0FBQy9GO0FBRUFMLEdBUGdCRCxnQkFBYztBQUFBLFVBQ0NILFNBQ1pELFdBQVc7QUFBQTtBQUFBLE1BRmRJO0FBUVQsZ0JBQVNPLGtCQUFrQjtBQUFBQyxNQUFBO0FBQ2hDLFFBQU0sRUFBRU4sT0FBT0MsVUFBVSxJQUFJTixRQUFRO0FBQ3JDLE1BQUlNLFVBQVcsUUFBTyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWE7QUFDbkMsU0FBT0QsUUFBUSx1QkFBQyxZQUFTLElBQUcsY0FBYSxTQUFPLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUMsSUFBTSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBTztBQUMvRDtBQUFDTSxJQUplRCxpQkFBZTtBQUFBLFVBQ0FWLE9BQU87QUFBQTtBQUFBLE1BRHRCVTtBQUFlLElBQUFSLElBQUFVLEtBQUFDO0FBQUEsYUFBQVgsSUFBQTtBQUFBLGFBQUFVLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJPdXRsZXQiLCJ1c2VMb2NhdGlvbiIsInVzZUF1dGgiLCJSb3V0ZUxvYWRpbmciLCJfYyIsIlByb3RlY3RlZFJvdXRlIiwiX3MiLCJ0b2tlbiIsImlzTG9hZGluZyIsImxvY2F0aW9uIiwiZnJvbSIsInBhdGhuYW1lIiwiUHVibGljT25seVJvdXRlIiwiX3MyIiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInJvdXRlLWd1YXJkcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUsIE91dGxldCwgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2FwcC9hdXRoLWNvbnRleHQnXG5cbi8qKiBPdHVydW0gZHVydW11bmEgZ8O2cmUgYmVrbGVyIHZleWEgw6dvY3VrIHJvdXRlJ2EgecO2bmxlbmRpcmlyLiAqL1xuZnVuY3Rpb24gUm91dGVMb2FkaW5nKCkge1xuICByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwicm91dGUtbG9hZGluZ1wiPjxzcGFuIGNsYXNzTmFtZT1cInNwaW5uZXJcIiAvPjxwPk90dXJ1bSBrb250cm9sIGVkaWxpeW9yPC9wPjwvbWFpbj5cbn1cblxuLyoqIEdpcmnFnyB5YXDEsWxtYW3EscWfIGt1bGxhbsSxY8SxecSxIGtvcnVtYWzEsSBpw6dlcmlrdGVuIHV6YWsgdHV0YXIuICovXG5leHBvcnQgZnVuY3Rpb24gUHJvdGVjdGVkUm91dGUoKSB7XG4gIGNvbnN0IHsgdG9rZW4sIGlzTG9hZGluZyB9ID0gdXNlQXV0aCgpXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxuICBpZiAoaXNMb2FkaW5nKSByZXR1cm4gPFJvdXRlTG9hZGluZyAvPlxuICByZXR1cm4gdG9rZW4gPyA8T3V0bGV0IC8+IDogPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSBzdGF0ZT17eyBmcm9tOiBsb2NhdGlvbi5wYXRobmFtZSB9fSAvPlxufVxuXG4vKiogQcOnxLFrIGF1dGggZWtyYW5sYXLEsW7EsSBvdHVydW0gYcOnbcSxxZ8ga3VsbGFuxLFjxLFkYW4gZ2l6bGVyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFB1YmxpY09ubHlSb3V0ZSgpIHtcbiAgY29uc3QgeyB0b2tlbiwgaXNMb2FkaW5nIH0gPSB1c2VBdXRoKClcbiAgaWYgKGlzTG9hZGluZykgcmV0dXJuIDxSb3V0ZUxvYWRpbmcgLz5cbiAgcmV0dXJuIHRva2VuID8gPE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz4gOiA8T3V0bGV0IC8+XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL3JvdXRlcy9yb3V0ZS1ndWFyZHMudHN4In0=