import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/architecture/transfer-timeline.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport1_react["useState"];
import { Activity, Check, Circle, Pause, Play, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
const steps = [
  { key: "sql", title: "SQL transaction tamamlandı", detail: "Bakiye, transfer ve Outbox olayı birlikte commit edildi." },
  { key: "outbox", title: "Outbox mesajı hazır", detail: "Broker bağlantısı gelene kadar olay SQL’de dayanıklı biçimde bekler." },
  { key: "rabbit", title: "RabbitMQ mesajı aldı", detail: "Mesaj kuyruğa yayımlandı; consumer teslim alabilir." },
  { key: "mongo", title: "MongoDB geçmişi güncellendi", detail: "Transfer okuma modeli idempotent biçimde yazıldı." },
  { key: "redis", title: "Redis önbelleği yenilemeye hazır", detail: "Geçmiş önbelleği sürümü artırıldı; sonraki okuma güncel veriyi getirir." }
];
export function TransferTimeline() {
  _s();
  const [started, setStarted] = useState(false);
  const [brokerAvailable, setBrokerAvailable] = useState(true);
  const blocked = started && !brokerAvailable;
  const completed = started && brokerAvailable;
  const status = (index) => !started ? "pending" : blocked ? index < 2 ? "complete" : index === 2 ? "blocked" : "pending" : "complete";
  return /* @__PURE__ */ jsxDEV("section", { className: "content-section timeline-card", "aria-labelledby": "timeline-title", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "ETKİLEŞİMLİ ÖRNEK" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 20,
        columnNumber: 43
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { id: "timeline-title", children: "Transfer olayı adım adım" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 20,
        columnNumber: 97
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Bu senaryo eğitim simülasyonudur; gerçek transfer veya canlı servis kontrolü yapmaz." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 20,
        columnNumber: 150
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
      lineNumber: 20,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
      lineNumber: 20,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `simulation-notice ${blocked ? "is-blocked" : ""}`, role: "status", children: !started ? "Akış henüz başlatılmadı." : blocked ? "RabbitMQ simülasyonda kapalı. Olay Outbox’ta bekliyor; SQL transferi tamamlandı." : "Simülasyonda mesaj MongoDB’ye ulaştı ve Redis geçmiş sürümü artırıldı." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
      lineNumber: 21,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("ol", { className: "event-timeline", children: steps.map((step, index) => {
      const state = status(index);
      const Icon = state === "complete" ? Check : state === "blocked" ? Pause : Circle;
      return /* @__PURE__ */ jsxDEV("li", { className: `event-step ${state}`, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "event-step-icon", children: /* @__PURE__ */ jsxDEV(Icon, { size: 16 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 22,
          columnNumber: 268
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 22,
          columnNumber: 234
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: step.title }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
            lineNumber: 22,
            columnNumber: 298
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: step.detail }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
            lineNumber: 22,
            columnNumber: 327
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 22,
          columnNumber: 293
        }, this)
      ] }, step.key, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 22,
        columnNumber: 181
      }, this);
    }) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
      lineNumber: 22,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "simulation-actions", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "primary-button", onClick: () => setStarted(true), disabled: completed, children: [
        /* @__PURE__ */ jsxDEV(Play, { size: 15 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 23,
          columnNumber: 144
        }, this),
        " Akışı başlat"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 23,
        columnNumber: 41
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "secondary-button", onClick: () => {
        setStarted(true);
        setBrokerAvailable(false);
      }, disabled: blocked, children: [
        /* @__PURE__ */ jsxDEV(Pause, { size: 15 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 23,
          columnNumber: 316
        }, this),
        " RabbitMQ kesintisini simüle et"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 23,
        columnNumber: 184
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "secondary-button", onClick: () => setBrokerAvailable(true), disabled: !started || brokerAvailable, children: [
        /* @__PURE__ */ jsxDEV(Activity, { size: 15, "aria-hidden": "true" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 23,
          columnNumber: 506
        }, this),
        " Bağlantıyı geri getir"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 23,
        columnNumber: 375
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "text-button", onClick: () => {
        setStarted(false);
        setBrokerAvailable(true);
      }, children: [
        /* @__PURE__ */ jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
          lineNumber: 23,
          columnNumber: 686
        }, this),
        " Sıfırla"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
        lineNumber: 23,
        columnNumber: 578
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
      lineNumber: 23,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
}
_s(TransferTimeline, "+Ov5rOXXgWgbekqvxY95DwYDn/c=");
_c = TransferTimeline;
var _c;
$RefreshReg$(_c, "TransferTimeline");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/architecture/transfer-timeline.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUIwQzs7QUFuQjFDLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxVQUFVQyxPQUFPQyxRQUFRQyxPQUFPQyxNQUFNQyxpQkFBaUI7QUFFaEUsTUFBTUMsUUFBUTtBQUFBLEVBQ1osRUFBRUMsS0FBSyxPQUFPQyxPQUFPLDhCQUE4QkMsUUFBUSwyREFBMkQ7QUFBQSxFQUN0SCxFQUFFRixLQUFLLFVBQVVDLE9BQU8sdUJBQXVCQyxRQUFRLHVFQUF1RTtBQUFBLEVBQzlILEVBQUVGLEtBQUssVUFBVUMsT0FBTyx3QkFBd0JDLFFBQVEsc0RBQXNEO0FBQUEsRUFDOUcsRUFBRUYsS0FBSyxTQUFTQyxPQUFPLCtCQUErQkMsUUFBUSxvREFBb0Q7QUFBQSxFQUNsSCxFQUFFRixLQUFLLFNBQVNDLE9BQU8sb0NBQW9DQyxRQUFRLDBFQUEwRTtBQUFDO0FBSXpJLGdCQUFTQyxtQkFBbUI7QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWhCLFNBQVMsSUFBSTtBQUMzRCxRQUFNaUIsVUFBVUosV0FBVyxDQUFDRTtBQUM1QixRQUFNRyxZQUFZTCxXQUFXRTtBQUM3QixRQUFNSSxTQUFTQSxDQUFDQyxVQUFrQixDQUFDUCxVQUFVLFlBQVlJLFVBQVdHLFFBQVEsSUFBSSxhQUFhQSxVQUFVLElBQUksWUFBWSxZQUFhO0FBQ3BJLFNBQU8sdUJBQUMsYUFBUSxXQUFVLGlDQUFnQyxtQkFBZ0Isa0JBQ3hFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1CQUFrQixpQ0FBQyxTQUFJO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGVBQWMsaUNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxNQUFPLHVCQUFDLFFBQUcsSUFBRyxrQkFBaUIsd0NBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxNQUFLLHVCQUFDLE9BQUUsb0dBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLFNBQXZNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMk0sS0FBNU87QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrUDtBQUFBLElBQ2xQLHVCQUFDLFNBQUksV0FBVyxxQkFBcUJILFVBQVUsZUFBZSxFQUFFLElBQUksTUFBSyxVQUFVLFdBQUNKLFVBQVUsNkJBQTZCSSxVQUFVLHFGQUFxRiw0RUFBMU47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtUztBQUFBLElBQ25TLHVCQUFDLFFBQUcsV0FBVSxrQkFBa0JWLGdCQUFNYyxJQUFJLENBQUNDLE1BQU1GLFVBQVU7QUFBRSxZQUFNRyxRQUFRSixPQUFPQyxLQUFLO0FBQUcsWUFBTUksT0FBT0QsVUFBVSxhQUFhckIsUUFBUXFCLFVBQVUsWUFBWW5CLFFBQVFEO0FBQVEsYUFBTyx1QkFBQyxRQUFHLFdBQVcsY0FBY29CLEtBQUssSUFBbUI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsbUJBQWtCLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFBTyx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsWUFBUUQsZUFBS2IsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQVMsdUJBQUMsT0FBR2EsZUFBS1osVUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxXQUEzSFksS0FBS2QsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SztBQUFBLElBQU0sQ0FBQyxLQUF0VztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdXO0FBQUEsSUFDeFcsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQjtBQUFBLDZCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsa0JBQWlCLFNBQVMsTUFBTU0sV0FBVyxJQUFJLEdBQUcsVUFBVUksV0FBVztBQUFBLCtCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBQUc7QUFBQSxXQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNJO0FBQUEsTUFBUyx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLG9CQUFtQixTQUFTLE1BQU07QUFBRUosbUJBQVcsSUFBSTtBQUFHRSwyQkFBbUIsS0FBSztBQUFBLE1BQUUsR0FBRyxVQUFVQyxTQUFTO0FBQUEsK0JBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQUc7QUFBQSxXQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdMO0FBQUEsTUFBUyx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLG9CQUFtQixTQUFTLE1BQU1ELG1CQUFtQixJQUFJLEdBQUcsVUFBVSxDQUFDSCxXQUFXRSxpQkFBaUI7QUFBQSwrQkFBQyxZQUFTLE1BQU0sSUFBSSxlQUFZLFVBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUFHO0FBQUEsV0FBNUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrTTtBQUFBLE1BQVMsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxlQUFjLFNBQVMsTUFBTTtBQUFFRCxtQkFBVyxLQUFLO0FBQUdFLDJCQUFtQixJQUFJO0FBQUEsTUFBRSxHQUFHO0FBQUEsK0JBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUFHO0FBQUEsV0FBckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2STtBQUFBLFNBQTVzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXF0QjtBQUFBLE9BSmh0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS1A7QUFDRjtBQUFDSixHQVplRCxrQkFBZ0I7QUFBQSxLQUFoQkE7QUFBZ0IsSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJBY3Rpdml0eSIsIkNoZWNrIiwiQ2lyY2xlIiwiUGF1c2UiLCJQbGF5IiwiUm90YXRlQ2N3Iiwic3RlcHMiLCJrZXkiLCJ0aXRsZSIsImRldGFpbCIsIlRyYW5zZmVyVGltZWxpbmUiLCJfcyIsInN0YXJ0ZWQiLCJzZXRTdGFydGVkIiwiYnJva2VyQXZhaWxhYmxlIiwic2V0QnJva2VyQXZhaWxhYmxlIiwiYmxvY2tlZCIsImNvbXBsZXRlZCIsInN0YXR1cyIsImluZGV4IiwibWFwIiwic3RlcCIsInN0YXRlIiwiSWNvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInRyYW5zZmVyLXRpbWVsaW5lLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQWN0aXZpdHksIENoZWNrLCBDaXJjbGUsIFBhdXNlLCBQbGF5LCBSb3RhdGVDY3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmNvbnN0IHN0ZXBzID0gW1xuICB7IGtleTogJ3NxbCcsIHRpdGxlOiAnU1FMIHRyYW5zYWN0aW9uIHRhbWFtbGFuZMSxJywgZGV0YWlsOiAnQmFraXllLCB0cmFuc2ZlciB2ZSBPdXRib3ggb2xhecSxIGJpcmxpa3RlIGNvbW1pdCBlZGlsZGkuJyB9LFxuICB7IGtleTogJ291dGJveCcsIHRpdGxlOiAnT3V0Ym94IG1lc2FqxLEgaGF6xLFyJywgZGV0YWlsOiAnQnJva2VyIGJhxJ9sYW50xLFzxLEgZ2VsZW5lIGthZGFyIG9sYXkgU1FM4oCZZGUgZGF5YW7EsWtsxLEgYmnDp2ltZGUgYmVrbGVyLicgfSxcbiAgeyBrZXk6ICdyYWJiaXQnLCB0aXRsZTogJ1JhYmJpdE1RIG1lc2FqxLEgYWxkxLEnLCBkZXRhaWw6ICdNZXNhaiBrdXlydcSfYSB5YXnEsW1sYW5kxLE7IGNvbnN1bWVyIHRlc2xpbSBhbGFiaWxpci4nIH0sXG4gIHsga2V5OiAnbW9uZ28nLCB0aXRsZTogJ01vbmdvREIgZ2XDp21pxZ9pIGfDvG5jZWxsZW5kaScsIGRldGFpbDogJ1RyYW5zZmVyIG9rdW1hIG1vZGVsaSBpZGVtcG90ZW50IGJpw6dpbWRlIHlhesSxbGTEsS4nIH0sXG4gIHsga2V5OiAncmVkaXMnLCB0aXRsZTogJ1JlZGlzIMO2bmJlbGxlxJ9pIHllbmlsZW1leWUgaGF6xLFyJywgZGV0YWlsOiAnR2XDp21pxZ8gw7ZuYmVsbGXEn2kgc8O8csO8bcO8IGFydMSxcsSxbGTEsTsgc29ucmFraSBva3VtYSBnw7xuY2VsIHZlcml5aSBnZXRpcmlyLicgfSxcbl1cblxuLyoqIFBhcmEgZ8O2bmRlcm1lZGVuLCBPdXRib3ggdmUgYnJva2VyIGtlc2ludGlzaSBzZW5hcnlvc3VudSBlxJ9pdGltIGnDp2luIGNhbmxhbmTEsXLEsXIuICovXG5leHBvcnQgZnVuY3Rpb24gVHJhbnNmZXJUaW1lbGluZSgpIHtcbiAgY29uc3QgW3N0YXJ0ZWQsIHNldFN0YXJ0ZWRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFticm9rZXJBdmFpbGFibGUsIHNldEJyb2tlckF2YWlsYWJsZV0gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBibG9ja2VkID0gc3RhcnRlZCAmJiAhYnJva2VyQXZhaWxhYmxlXG4gIGNvbnN0IGNvbXBsZXRlZCA9IHN0YXJ0ZWQgJiYgYnJva2VyQXZhaWxhYmxlXG4gIGNvbnN0IHN0YXR1cyA9IChpbmRleDogbnVtYmVyKSA9PiAhc3RhcnRlZCA/ICdwZW5kaW5nJyA6IGJsb2NrZWQgPyAoaW5kZXggPCAyID8gJ2NvbXBsZXRlJyA6IGluZGV4ID09PSAyID8gJ2Jsb2NrZWQnIDogJ3BlbmRpbmcnKSA6ICdjb21wbGV0ZSdcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnQtc2VjdGlvbiB0aW1lbGluZS1jYXJkXCIgYXJpYS1sYWJlbGxlZGJ5PVwidGltZWxpbmUtdGl0bGVcIj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGluZ1wiPjxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiY2FyZC1raWNrZXJcIj5FVEvEsExFxZ7EsE1MxLAgw5ZSTkVLPC9zcGFuPjxoMiBpZD1cInRpbWVsaW5lLXRpdGxlXCI+VHJhbnNmZXIgb2xhecSxIGFkxLFtIGFkxLFtPC9oMj48cD5CdSBzZW5hcnlvIGXEn2l0aW0gc2ltw7xsYXN5b251ZHVyOyBnZXLDp2VrIHRyYW5zZmVyIHZleWEgY2FubMSxIHNlcnZpcyBrb250cm9sw7wgeWFwbWF6LjwvcD48L2Rpdj48L2Rpdj5cbiAgICA8ZGl2IGNsYXNzTmFtZT17YHNpbXVsYXRpb24tbm90aWNlICR7YmxvY2tlZCA/ICdpcy1ibG9ja2VkJyA6ICcnfWB9IHJvbGU9XCJzdGF0dXNcIj57IXN0YXJ0ZWQgPyAnQWvEscWfIGhlbsO8eiBiYcWfbGF0xLFsbWFkxLEuJyA6IGJsb2NrZWQgPyAnUmFiYml0TVEgc2ltw7xsYXN5b25kYSBrYXBhbMSxLiBPbGF5IE91dGJveOKAmXRhIGJla2xpeW9yOyBTUUwgdHJhbnNmZXJpIHRhbWFtbGFuZMSxLicgOiAnU2ltw7xsYXN5b25kYSBtZXNhaiBNb25nb0RC4oCZeWUgdWxhxZ90xLEgdmUgUmVkaXMgZ2XDp21pxZ8gc8O8csO8bcO8IGFydMSxcsSxbGTEsS4nfTwvZGl2PlxuICAgIDxvbCBjbGFzc05hbWU9XCJldmVudC10aW1lbGluZVwiPntzdGVwcy5tYXAoKHN0ZXAsIGluZGV4KSA9PiB7IGNvbnN0IHN0YXRlID0gc3RhdHVzKGluZGV4KTsgY29uc3QgSWNvbiA9IHN0YXRlID09PSAnY29tcGxldGUnID8gQ2hlY2sgOiBzdGF0ZSA9PT0gJ2Jsb2NrZWQnID8gUGF1c2UgOiBDaXJjbGU7IHJldHVybiA8bGkgY2xhc3NOYW1lPXtgZXZlbnQtc3RlcCAke3N0YXRlfWB9IGtleT17c3RlcC5rZXl9PjxzcGFuIGNsYXNzTmFtZT1cImV2ZW50LXN0ZXAtaWNvblwiPjxJY29uIHNpemU9ezE2fSAvPjwvc3Bhbj48ZGl2PjxzdHJvbmc+e3N0ZXAudGl0bGV9PC9zdHJvbmc+PHA+e3N0ZXAuZGV0YWlsfTwvcD48L2Rpdj48L2xpPiB9KX08L29sPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2ltdWxhdGlvbi1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRTdGFydGVkKHRydWUpfSBkaXNhYmxlZD17Y29tcGxldGVkfT48UGxheSBzaXplPXsxNX0gLz4gQWvEscWfxLEgYmHFn2xhdDwvYnV0dG9uPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNlY29uZGFyeS1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldFN0YXJ0ZWQodHJ1ZSk7IHNldEJyb2tlckF2YWlsYWJsZShmYWxzZSkgfX0gZGlzYWJsZWQ9e2Jsb2NrZWR9PjxQYXVzZSBzaXplPXsxNX0gLz4gUmFiYml0TVEga2VzaW50aXNpbmkgc2ltw7xsZSBldDwvYnV0dG9uPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNlY29uZGFyeS1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRCcm9rZXJBdmFpbGFibGUodHJ1ZSl9IGRpc2FibGVkPXshc3RhcnRlZCB8fCBicm9rZXJBdmFpbGFibGV9PjxBY3Rpdml0eSBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4gQmHEn2xhbnTEsXnEsSBnZXJpIGdldGlyPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwidGV4dC1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldFN0YXJ0ZWQoZmFsc2UpOyBzZXRCcm9rZXJBdmFpbGFibGUodHJ1ZSkgfX0+PFJvdGF0ZUNjdyBzaXplPXsxNH0gLz4gU8SxZsSxcmxhPC9idXR0b24+PC9kaXY+XG4gIDwvc2VjdGlvbj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvYXJjaGl0ZWN0dXJlL3RyYW5zZmVyLXRpbWVsaW5lLnRzeCJ9