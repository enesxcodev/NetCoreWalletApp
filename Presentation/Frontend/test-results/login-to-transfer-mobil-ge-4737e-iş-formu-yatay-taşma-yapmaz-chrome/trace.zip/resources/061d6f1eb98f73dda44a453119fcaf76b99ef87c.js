import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/contacts/components/contact-search.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
export function ContactSearch({ value, onChange }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "contact-search", children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: "contact-search", children: "Transfer kişisi ara" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
      lineNumber: 11,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "contact-search-input", children: [
      /* @__PURE__ */ jsxDEV(Search, { size: 19, "aria-hidden": "true" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
        lineNumber: 13,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "contact-search", type: "search", value, maxLength: 100, onChange: (event) => onChange(event.target.value), placeholder: "Ad soyad, kullanıcı adı veya e-posta", autoComplete: "off" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
        lineNumber: 14,
        columnNumber: 7
      }, this),
      value && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onChange(""), "aria-label": "Aramayı temizle", children: /* @__PURE__ */ jsxDEV(X, { size: 17 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
        lineNumber: 15,
        columnNumber: 97
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
        lineNumber: 15,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
      lineNumber: 12,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Bir kişiyi bulmak için adı, kullanıcı adı veya e-posta adresini yazın." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
      lineNumber: 17,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_c = ContactSearch;
var _c;
$RefreshReg$(_c, "ContactSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/contacts/components/contact-search.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSixTQUFTQSxRQUFRQyxTQUFTO0FBUW5CLGdCQUFTQyxjQUFjLEVBQUVDLE9BQU9DLFNBQTZCLEdBQUc7QUFDckUsU0FBTyx1QkFBQyxTQUFJLFdBQVUsa0JBQ3BCO0FBQUEsMkJBQUMsV0FBTSxTQUFRLGtCQUFpQixtQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRDtBQUFBLElBQ25ELHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDZCQUFDLFVBQU8sTUFBTSxJQUFJLGVBQVksVUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQ3BDLHVCQUFDLFdBQU0sSUFBRyxrQkFBaUIsTUFBSyxVQUFTLE9BQWMsV0FBVyxLQUFLLFVBQVUsQ0FBQ0MsVUFBVUQsU0FBU0MsTUFBTUMsT0FBT0gsS0FBSyxHQUFHLGFBQVksd0NBQXVDLGNBQWEsU0FBMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErTDtBQUFBLE1BQzlMQSxTQUFTLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUMsU0FBUyxFQUFFLEdBQUcsY0FBVyxtQkFBa0IsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxTQUgzRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLE9BQUUsc0ZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RTtBQUFBLE9BUHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRUDtBQUNGO0FBQUNHLEtBVmVMO0FBQWEsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiU2VhcmNoIiwiWCIsIkNvbnRhY3RTZWFyY2giLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZXZlbnQiLCJ0YXJnZXQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjb250YWN0LXNlYXJjaC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2VhcmNoLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbnRlcmZhY2UgQ29udGFjdFNlYXJjaFByb3BzIHtcbiAgdmFsdWU6IHN0cmluZ1xuICBvbkNoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWRcbn1cblxuLyoqIEFkIHNveWFkLCBrdWxsYW7EsWPEsSBhZMSxIHZleWEgZS1wb3N0YXlsYSBhbMSxY8SxIGFyYW1hIGFsYW7EsW7EsSBzdW5hci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBDb250YWN0U2VhcmNoKHsgdmFsdWUsIG9uQ2hhbmdlIH06IENvbnRhY3RTZWFyY2hQcm9wcykge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LXNlYXJjaFwiPlxuICAgIDxsYWJlbCBodG1sRm9yPVwiY29udGFjdC1zZWFyY2hcIj5UcmFuc2ZlciBracWfaXNpIGFyYTwvbGFiZWw+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LXNlYXJjaC1pbnB1dFwiPlxuICAgICAgPFNlYXJjaCBzaXplPXsxOX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgIDxpbnB1dCBpZD1cImNvbnRhY3Qtc2VhcmNoXCIgdHlwZT1cInNlYXJjaFwiIHZhbHVlPXt2YWx1ZX0gbWF4TGVuZ3RoPXsxMDB9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiQWQgc295YWQsIGt1bGxhbsSxY8SxIGFkxLEgdmV5YSBlLXBvc3RhXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgIHt2YWx1ZSAmJiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSgnJyl9IGFyaWEtbGFiZWw9XCJBcmFtYXnEsSB0ZW1pemxlXCI+PFggc2l6ZT17MTd9IC8+PC9idXR0b24+fVxuICAgIDwvZGl2PlxuICAgIDxwPkJpciBracWfaXlpIGJ1bG1hayBpw6dpbiBhZMSxLCBrdWxsYW7EsWPEsSBhZMSxIHZleWEgZS1wb3N0YSBhZHJlc2luaSB5YXrEsW4uPC9wPlxuICA8L2Rpdj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvY29udGFjdHMvY29tcG9uZW50cy9jb250YWN0LXNlYXJjaC50c3gifQ==