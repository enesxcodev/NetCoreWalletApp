import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/not-found/not-found-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
export function NotFoundPage() {
  return /* @__PURE__ */ jsxDEV("main", { className: "not-found-page", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "not-found-code", children: "404" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
      lineNumber: 5,
      columnNumber: 43
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { children: "Bu sayfayı bulamadık" }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
      lineNumber: 5,
      columnNumber: 86
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Bağlantı değişmiş olabilir veya adresi yanlış yazmış olabilirsiniz." }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
      lineNumber: 5,
      columnNumber: 115
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { className: "primary-button not-found-button", to: "/login", children: [
      "Giriş sayfasına dön ",
      /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
        lineNumber: 5,
        columnNumber: 271
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
      lineNumber: 5,
      columnNumber: 189
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = NotFoundPage;
var _c;
$RefreshReg$(_c, "NotFoundPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/not-found/not-found-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSTBDO0FBSjFDLFNBQVNBLFlBQVk7QUFHZCxnQkFBU0MsZUFBZTtBQUM3QixTQUFPLHVCQUFDLFVBQUssV0FBVSxrQkFBaUI7QUFBQSwyQkFBQyxVQUFLLFdBQVUsa0JBQWlCLG1CQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9DO0FBQUEsSUFBTyx1QkFBQyxRQUFHLG9DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUFLLHVCQUFDLE9BQUUsbUZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLElBQUksdUJBQUMsUUFBSyxXQUFVLG1DQUFrQyxJQUFHLFVBQVM7QUFBQTtBQUFBLE1BQW9CLHVCQUFDLFVBQUssZUFBWSxRQUFPLGlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsU0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtSDtBQUFBLE9BQXRTO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNlM7QUFDdFQ7QUFBQ0MsS0FGZUQ7QUFBWSxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiTm90Rm91bmRQYWdlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibm90LWZvdW5kLXBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG4vKiogRcWfbGXFn21leWVuIGFkcmVzbGVyIGnDp2luIGFuYSBzYXlmYXlhIGTDtm7DvMWfIGJhxJ9sYW50xLFzxLEgdmVyaXIuICovXG5leHBvcnQgZnVuY3Rpb24gTm90Rm91bmRQYWdlKCkge1xuICByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwibm90LWZvdW5kLXBhZ2VcIj48c3BhbiBjbGFzc05hbWU9XCJub3QtZm91bmQtY29kZVwiPjQwNDwvc3Bhbj48aDE+QnUgc2F5ZmF5xLEgYnVsYW1hZMSxazwvaDE+PHA+QmHEn2xhbnTEsSBkZcSfacWfbWnFnyBvbGFiaWxpciB2ZXlhIGFkcmVzaSB5YW5sxLHFnyB5YXptxLHFnyBvbGFiaWxpcnNpbml6LjwvcD48TGluayBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBub3QtZm91bmQtYnV0dG9uXCIgdG89XCIvbG9naW5cIj5HaXJpxZ8gc2F5ZmFzxLFuYSBkw7ZuIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj48L0xpbms+PC9tYWluPlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy9ub3QtZm91bmQvbm90LWZvdW5kLXBhZ2UudHN4In0=