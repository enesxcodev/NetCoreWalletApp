import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/auth-layout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArrowDownLeft, ArrowUpRight, ChartNoAxesCombined, ShieldCheck, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import phoneHero from "/src/assets/phone-hero.svg?import";
import walletHero from "/src/assets/wallet-hero.svg?import";
import { Brand } from "/src/components/brand.tsx";
export function AuthLayout({ page, children }) {
  const isLogin = page === "login";
  const items = isLogin ? [
    { icon: /* @__PURE__ */ jsxDEV(Zap, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 16,
      columnNumber: 11
    }, this), title: "Hızlı işlemler", text: "Günlük işlemlerinizi kolayca yönetin." },
    { icon: /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 17,
      columnNumber: 11
    }, this), title: "Güvenli altyapı", text: "Hesabınız koruma altında." },
    { icon: /* @__PURE__ */ jsxDEV(ChartNoAxesCombined, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 18,
      columnNumber: 11
    }, this), title: "Finansal kontrol", text: "Hareketlerinizi tek yerde görün." }
  ] : [
    { icon: /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 21,
      columnNumber: 11
    }, this), title: "Kolay başlangıç", text: "Birkaç adımda hesabınız hazır." },
    { icon: /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 22,
      columnNumber: 11
    }, this), title: "Güvenli hesap", text: "Bilgileriniz güvenle korunur." },
    { icon: /* @__PURE__ */ jsxDEV(ArrowDownLeft, { size: 19 }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 23,
      columnNumber: 11
    }, this), title: "Modern deneyim", text: "Cüzdanınızı dilediğiniz yerden yönetin." }
  ];
  return /* @__PURE__ */ jsxDEV("main", { className: `auth-page ${isLogin ? "auth-login" : "auth-register"}`, children: [
    /* @__PURE__ */ jsxDEV("section", { className: "auth-visual", "aria-label": "Wallet özellikleri", children: [
      /* @__PURE__ */ jsxDEV(Brand, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "visual-copy", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "PARANIZ, KONTROLÜNÜZDE" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 31,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: isLogin ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          "Finansınızı",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
            lineNumber: 32,
            columnNumber: 39
          }, this),
          "tek yerden yönetin."
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 32,
          columnNumber: 26
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          "Cüzdanınızı",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
            lineNumber: 32,
            columnNumber: 83
          }, this),
          "kolayca oluşturun."
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 32,
          columnNumber: 70
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 32,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "visual-description", children: "Güvenli, hızlı ve modern bir dijital cüzdan deneyimiyle tanışın." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 33,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("img", { className: "hero-illustration", src: isLogin ? walletHero : phoneHero, alt: isLogin ? "Kartlarıyla birlikte dijital cüzdan illüstrasyonu" : "Bakiye grafiği ve hareketleri gösteren telefon illüstrasyonu" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "feature-list", children: items.map((item) => /* @__PURE__ */ jsxDEV("div", { className: "feature-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "feature-icon", children: item.icon }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 37,
          columnNumber: 79
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: item.title }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
            lineNumber: 37,
            columnNumber: 134
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: item.text }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
            lineNumber: 37,
            columnNumber: 163
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 37,
          columnNumber: 128
        }, this)
      ] }, item.title, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 37,
        columnNumber: 32
      }, this)) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "visual-footnote", children: "Günlük finansınız için sade ve güvenli bir başlangıç." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "auth-form-side", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mobile-brand", children: /* @__PURE__ */ jsxDEV(Brand, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 42,
        columnNumber: 39
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      children,
      /* @__PURE__ */ jsxDEV("p", { className: "form-side-footnote", children: [
        /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 14 }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
          lineNumber: 44,
          columnNumber: 43
        }, this),
        " Güvenli bağlantı · Bilgileriniz şifrelenir"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_c = AuthLayout;
var _c;
$RefreshReg$(_c, "AuthLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/layouts/auth-layout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZWdCLFNBZ0JTLFVBaEJUO0FBZmhCLFNBQVNBLGVBQWVDLGNBQWNDLHFCQUFxQkMsYUFBYUMsV0FBVztBQUVuRixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxhQUFhO0FBT2YsZ0JBQVNDLFdBQVcsRUFBRUMsTUFBTUMsU0FBMEIsR0FBRztBQUM5RCxRQUFNQyxVQUFVRixTQUFTO0FBQ3pCLFFBQU1HLFFBQVFELFVBQ1Y7QUFBQSxJQUNFLEVBQUVFLE1BQU0sdUJBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEdBQUtDLE9BQU8sa0JBQWtCQyxNQUFNLHdDQUF3QztBQUFBLElBQ2xHLEVBQUVGLE1BQU0sdUJBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsR0FBS0MsT0FBTyxtQkFBbUJDLE1BQU0sNEJBQTRCO0FBQUEsSUFDL0YsRUFBRUYsTUFBTSx1QkFBQyx1QkFBb0IsTUFBTSxNQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEdBQUtDLE9BQU8sb0JBQW9CQyxNQUFNLG1DQUFtQztBQUFBLEVBQUMsSUFFbEg7QUFBQSxJQUNFLEVBQUVGLE1BQU0sdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLEdBQUtDLE9BQU8sbUJBQW1CQyxNQUFNLGlDQUFpQztBQUFBLElBQ3JHLEVBQUVGLE1BQU0sdUJBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsR0FBS0MsT0FBTyxpQkFBaUJDLE1BQU0sZ0NBQWdDO0FBQUEsSUFDakcsRUFBRUYsTUFBTSx1QkFBQyxpQkFBYyxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsR0FBS0MsT0FBTyxrQkFBa0JDLE1BQU0sMENBQTBDO0FBQUEsRUFBQztBQUdySCxTQUNFLHVCQUFDLFVBQUssV0FBVyxhQUFhSixVQUFVLGVBQWUsZUFBZSxJQUNwRTtBQUFBLDJCQUFDLGFBQVEsV0FBVSxlQUFjLGNBQVcsc0JBQzFDO0FBQUEsNkJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU07QUFBQSxNQUNOLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLFdBQVUsc0NBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFJQSxvQkFBVSxtQ0FBRTtBQUFBO0FBQUEsVUFBVyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUFHO0FBQUEsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxJQUFNLG1DQUFFO0FBQUE7QUFBQSxVQUFXLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQUc7QUFBQSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxRQUNwRyx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLGdGQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsV0FIcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQW9CLEtBQUtBLFVBQVVMLGFBQWFELFdBQVcsS0FBS00sVUFBVSxzREFBc0Qsa0VBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOE07QUFBQSxNQUM5TSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1pDLGdCQUFNSSxJQUFJLENBQUNDLFNBQVMsdUJBQUMsU0FBSSxXQUFVLGdCQUFnQztBQUFBLCtCQUFDLFVBQUssV0FBVSxnQkFBZ0JBLGVBQUtKLFFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUFPLHVCQUFDLFVBQUs7QUFBQSxpQ0FBQyxZQUFRSSxlQUFLSCxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFBUyx1QkFBQyxXQUFPRyxlQUFLRixRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsYUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBQTFIRSxLQUFLSCxPQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9LLENBQU0sS0FEak07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsbUJBQWtCLHFFQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GO0FBQUEsU0FYdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQSx1QkFBQyxhQUFRLFdBQVUsa0JBQ2pCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUFlLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFNLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUN0Q0o7QUFBQUEsTUFDRCx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCO0FBQUEsK0JBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQSxRQUFHO0FBQUEsV0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRztBQUFBLFNBSHhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLE9BbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFDUSxLQXBDZVY7QUFBVSxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJBcnJvd0Rvd25MZWZ0IiwiQXJyb3dVcFJpZ2h0IiwiQ2hhcnROb0F4ZXNDb21iaW5lZCIsIlNoaWVsZENoZWNrIiwiWmFwIiwicGhvbmVIZXJvIiwid2FsbGV0SGVybyIsIkJyYW5kIiwiQXV0aExheW91dCIsInBhZ2UiLCJjaGlsZHJlbiIsImlzTG9naW4iLCJpdGVtcyIsImljb24iLCJ0aXRsZSIsInRleHQiLCJtYXAiLCJpdGVtIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXV0aC1sYXlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFycm93RG93bkxlZnQsIEFycm93VXBSaWdodCwgQ2hhcnROb0F4ZXNDb21iaW5lZCwgU2hpZWxkQ2hlY2ssIFphcCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB0eXBlIHsgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcbmltcG9ydCBwaG9uZUhlcm8gZnJvbSAnLi4vYXNzZXRzL3Bob25lLWhlcm8uc3ZnJ1xuaW1wb3J0IHdhbGxldEhlcm8gZnJvbSAnLi4vYXNzZXRzL3dhbGxldC1oZXJvLnN2ZydcbmltcG9ydCB7IEJyYW5kIH0gZnJvbSAnLi4vY29tcG9uZW50cy9icmFuZCdcblxuaW50ZXJmYWNlIEF1dGhMYXlvdXRQcm9wcyBleHRlbmRzIFByb3BzV2l0aENoaWxkcmVuIHtcbiAgcGFnZTogJ2xvZ2luJyB8ICdyZWdpc3Rlcidcbn1cblxuLyoqIEF1dGggc2F5ZmFsYXLEsW5hIG9ydGFrIG1hcmthLCBpbGzDvHN0cmFzeW9uIHZlIG1vYmlsIGTDvHplbmkgc2HEn2xhci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBBdXRoTGF5b3V0KHsgcGFnZSwgY2hpbGRyZW4gfTogQXV0aExheW91dFByb3BzKSB7XG4gIGNvbnN0IGlzTG9naW4gPSBwYWdlID09PSAnbG9naW4nXG4gIGNvbnN0IGl0ZW1zID0gaXNMb2dpblxuICAgID8gW1xuICAgICAgICB7IGljb246IDxaYXAgc2l6ZT17MTl9IC8+LCB0aXRsZTogJ0jEsXpsxLEgacWfbGVtbGVyJywgdGV4dDogJ0fDvG5sw7xrIGnFn2xlbWxlcmluaXppIGtvbGF5Y2EgecO2bmV0aW4uJyB9LFxuICAgICAgICB7IGljb246IDxTaGllbGRDaGVjayBzaXplPXsxOX0gLz4sIHRpdGxlOiAnR8O8dmVubGkgYWx0eWFwxLEnLCB0ZXh0OiAnSGVzYWLEsW7EsXoga29ydW1hIGFsdMSxbmRhLicgfSxcbiAgICAgICAgeyBpY29uOiA8Q2hhcnROb0F4ZXNDb21iaW5lZCBzaXplPXsxOX0gLz4sIHRpdGxlOiAnRmluYW5zYWwga29udHJvbCcsIHRleHQ6ICdIYXJla2V0bGVyaW5pemkgdGVrIHllcmRlIGfDtnLDvG4uJyB9LFxuICAgICAgXVxuICAgIDogW1xuICAgICAgICB7IGljb246IDxBcnJvd1VwUmlnaHQgc2l6ZT17MTl9IC8+LCB0aXRsZTogJ0tvbGF5IGJhxZ9sYW5nxLHDpycsIHRleHQ6ICdCaXJrYcOnIGFkxLFtZGEgaGVzYWLEsW7EsXogaGF6xLFyLicgfSxcbiAgICAgICAgeyBpY29uOiA8U2hpZWxkQ2hlY2sgc2l6ZT17MTl9IC8+LCB0aXRsZTogJ0fDvHZlbmxpIGhlc2FwJywgdGV4dDogJ0JpbGdpbGVyaW5peiBnw7x2ZW5sZSBrb3J1bnVyLicgfSxcbiAgICAgICAgeyBpY29uOiA8QXJyb3dEb3duTGVmdCBzaXplPXsxOX0gLz4sIHRpdGxlOiAnTW9kZXJuIGRlbmV5aW0nLCB0ZXh0OiAnQ8O8emRhbsSxbsSxesSxIGRpbGVkacSfaW5peiB5ZXJkZW4gecO2bmV0aW4uJyB9LFxuICAgICAgXVxuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPXtgYXV0aC1wYWdlICR7aXNMb2dpbiA/ICdhdXRoLWxvZ2luJyA6ICdhdXRoLXJlZ2lzdGVyJ31gfT5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImF1dGgtdmlzdWFsXCIgYXJpYS1sYWJlbD1cIldhbGxldCDDtnplbGxpa2xlcmlcIj5cbiAgICAgICAgPEJyYW5kIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidmlzdWFsLWNvcHlcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJleWVicm93XCI+UEFSQU5JWiwgS09OVFJPTMOcTsOcWkRFPC9wPlxuICAgICAgICAgIDxoMT57aXNMb2dpbiA/IDw+RmluYW5zxLFuxLF6xLE8YnIgLz50ZWsgeWVyZGVuIHnDtm5ldGluLjwvPiA6IDw+Q8O8emRhbsSxbsSxesSxPGJyIC8+a29sYXljYSBvbHXFn3R1cnVuLjwvPn08L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInZpc3VhbC1kZXNjcmlwdGlvblwiPkfDvHZlbmxpLCBoxLF6bMSxIHZlIG1vZGVybiBiaXIgZGlqaXRhbCBjw7x6ZGFuIGRlbmV5aW1peWxlIHRhbsSxxZ/EsW4uPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGltZyBjbGFzc05hbWU9XCJoZXJvLWlsbHVzdHJhdGlvblwiIHNyYz17aXNMb2dpbiA/IHdhbGxldEhlcm8gOiBwaG9uZUhlcm99IGFsdD17aXNMb2dpbiA/ICdLYXJ0bGFyxLF5bGEgYmlybGlrdGUgZGlqaXRhbCBjw7x6ZGFuIGlsbMO8c3RyYXN5b251JyA6ICdCYWtpeWUgZ3JhZmnEn2kgdmUgaGFyZWtldGxlcmkgZ8O2c3RlcmVuIHRlbGVmb24gaWxsw7xzdHJhc3lvbnUnfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtbGlzdFwiPlxuICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1pdGVtXCIga2V5PXtpdGVtLnRpdGxlfT48c3BhbiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb25cIj57aXRlbS5pY29ufTwvc3Bhbj48c3Bhbj48c3Ryb25nPntpdGVtLnRpdGxlfTwvc3Ryb25nPjxzbWFsbD57aXRlbS50ZXh0fTwvc21hbGw+PC9zcGFuPjwvZGl2Pil9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ2aXN1YWwtZm9vdG5vdGVcIj5Hw7xubMO8ayBmaW5hbnPEsW7EsXogacOnaW4gc2FkZSB2ZSBnw7x2ZW5saSBiaXIgYmHFn2xhbmfEscOnLjwvcD5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImF1dGgtZm9ybS1zaWRlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9iaWxlLWJyYW5kXCI+PEJyYW5kIC8+PC9kaXY+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9ybS1zaWRlLWZvb3Rub3RlXCI+PFNoaWVsZENoZWNrIHNpemU9ezE0fSAvPiBHw7x2ZW5saSBiYcSfbGFudMSxIMK3IEJpbGdpbGVyaW5peiDFn2lmcmVsZW5pcjwvcD5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvbGF5b3V0cy9hdXRoLWxheW91dC50c3gifQ==