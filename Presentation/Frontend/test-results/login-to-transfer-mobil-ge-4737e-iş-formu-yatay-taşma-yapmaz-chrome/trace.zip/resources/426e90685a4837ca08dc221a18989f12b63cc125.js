import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/wallet/pages/money-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=88909849";
import { ArrowDownLeft, ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=88909849";
import { z } from "/node_modules/.vite/deps/zod.js?v=88909849";
import { errorMessage } from "/src/lib/error-message.ts";
import { formatMoney } from "/src/lib/format.ts";
import { positiveAmount } from "/src/lib/amount.ts";
import { QueryError, QuerySkeleton } from "/src/components/query-state.tsx";
import { useWallet } from "/src/features/wallet/hooks.ts";
import { useMoneyMutation } from "/src/features/wallet/mutations.ts";
const amountSchema = z.object({ amount: positiveAmount });
export function MoneyPage({ action }) {
  _s();
  const isDeposit = action === "deposit";
  const wallet = useWallet();
  const mutation = useMoneyMutation(action);
  const { register, handleSubmit, reset, formState: { errors } } = useForm({ resolver: zodResolver(amountSchema) });
  const submit = handleSubmit(async ({ amount }) => {
    try {
      await mutation.mutateAsync(amount);
      reset();
    } catch {
    }
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack narrow-content", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: isDeposit ? "BAKİYE EKLE" : "BAKİYE KULLAN" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 24,
        columnNumber: 89
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: isDeposit ? "Para yatırın" : "Para çekin" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 24,
        columnNumber: 171
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: isDeposit ? "Cüzdanınıza istediğiniz tutarı ekleyin." : "Cüzdanınızdan çekmek istediğiniz tutarı girin." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 24,
        columnNumber: 223
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
      lineNumber: 24,
      columnNumber: 56
    }, this),
    wallet.isPending ? /* @__PURE__ */ jsxDEV(QuerySkeleton, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
      lineNumber: 25,
      columnNumber: 25
    }, this) : wallet.isError ? /* @__PURE__ */ jsxDEV(QueryError, { retry: () => void wallet.refetch() }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
      lineNumber: 25,
      columnNumber: 62
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "compact-balance", children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Güncel bakiye" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 25,
        columnNumber: 148
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { children: formatMoney(wallet.data.balance) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 25,
        columnNumber: 174
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
      lineNumber: 25,
      columnNumber: 115
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "form-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: `large-action-icon ${isDeposit ? "mint" : "coral"}`, children: isDeposit ? /* @__PURE__ */ jsxDEV(ArrowDownLeft, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 119
      }, this) : /* @__PURE__ */ jsxDEV(ArrowUpRight, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 139
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 37
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: isDeposit ? "Cüzdanınıza para ekleyin" : "Cüzdanınızdan para çekin" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 162
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "İşlem sonrası güncel bakiyeniz otomatik yenilenir." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 240
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: submit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "amount", children: "Tutar (₺)" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "amount-input", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "₺" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
            lineNumber: 27,
            columnNumber: 78
          }, this),
          /* @__PURE__ */ jsxDEV("input", { id: "amount", inputMode: "decimal", placeholder: "0,00", "aria-invalid": Boolean(errors.amount), ...register("amount") }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
            lineNumber: 27,
            columnNumber: 92
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 27,
          columnNumber: 48
        }, this),
        errors.amount && /* @__PURE__ */ jsxDEV("small", { className: "field-error", children: errors.amount.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 27,
          columnNumber: 238
        }, this),
        mutation.isError && /* @__PURE__ */ jsxDEV("div", { role: "alert", className: "form-alert", children: errorMessage(mutation.error) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 28,
          columnNumber: 28
        }, this),
        mutation.isSuccess && /* @__PURE__ */ jsxDEV("div", { role: "status", className: "form-success", children: "İşlem başarıyla tamamlandı." }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 29,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "primary-button", type: "submit", disabled: mutation.isPending, children: mutation.isPending ? "İşleniyor..." : isDeposit ? "Para yatır" : "Para çek" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
          lineNumber: 30,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
        lineNumber: 26,
        columnNumber: 297
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
      lineNumber: 26,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_s(MoneyPage, "twUIZrhrW7pEozrKk0s0OaGr55w=", false, function() {
  return [useWallet, useMoneyMutation, useForm];
});
_c = MoneyPage;
var _c;
$RefreshReg$(_c, "MoneyPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/wallet/pages/money-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJ3Rjs7QUF2QnhGLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyxlQUFlQyxvQkFBb0I7QUFDNUMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxTQUFTO0FBQ2xCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLFlBQVlDLHFCQUFxQjtBQUMxQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msd0JBQTBDO0FBRW5ELE1BQU1DLGVBQWVSLEVBQUVTLE9BQU8sRUFBRUMsUUFBUVAsZUFBZSxDQUFDO0FBSWpELGdCQUFTUSxVQUFVLEVBQUVDLE9BQWdDLEdBQUc7QUFBQUMsS0FBQTtBQUM3RCxRQUFNQyxZQUFZRixXQUFXO0FBQzdCLFFBQU1HLFNBQVNULFVBQVU7QUFDekIsUUFBTVUsV0FBV1QsaUJBQWlCSyxNQUFNO0FBQ3hDLFFBQU0sRUFBRUssVUFBVUMsY0FBY0MsT0FBT0MsV0FBVyxFQUFFQyxPQUFPLEVBQUUsSUFBSXRCLFFBQThELEVBQUV1QixVQUFVMUIsWUFBWVksWUFBWSxFQUFFLENBQUM7QUFDdEssUUFBTWUsU0FBU0wsYUFBYSxPQUFPLEVBQUVSLE9BQU8sTUFBTTtBQUNoRCxRQUFJO0FBQUUsWUFBTU0sU0FBU1EsWUFBWWQsTUFBTTtBQUFHUyxZQUFNO0FBQUEsSUFBRSxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQzlELENBQUM7QUFDRCxTQUFPLHVCQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSwyQkFBQyxZQUFPLFdBQVUsZ0JBQWU7QUFBQSw2QkFBQyxVQUFLLFdBQVUsZUFBZUwsc0JBQVksZ0JBQWdCLG1CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFBTyx1QkFBQyxRQUFJQSxzQkFBWSxpQkFBaUIsZ0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxNQUFLLHVCQUFDLE9BQUdBLHNCQUFZLDRDQUE0QyxvREFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLFNBQXBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd1I7QUFBQSxJQUMxVUMsT0FBT1UsWUFBWSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWMsSUFBTVYsT0FBT1csVUFBVSx1QkFBQyxjQUFXLE9BQU8sTUFBTSxLQUFLWCxPQUFPWSxRQUFRLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0MsSUFBTSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsNkJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CO0FBQUEsTUFBTyx1QkFBQyxZQUFRekIsc0JBQVlhLE9BQU9hLEtBQUtDLE9BQU8sS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLFNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEc7QUFBQSxJQUM1Tix1QkFBQyxhQUFRLFdBQVUsY0FBYTtBQUFBLDZCQUFDLFNBQUksV0FBVyxxQkFBcUJmLFlBQVksU0FBUyxPQUFPLElBQUtBLHNCQUFZLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxJQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYSxLQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVIO0FBQUEsTUFBTSx1QkFBQyxRQUFJQSxzQkFBWSw2QkFBNkIsOEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUFLLHVCQUFDLE9BQUUsa0VBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQUksdUJBQUMsVUFBSyxVQUFVUyxRQUFRLFlBQVUsTUFDcFU7QUFBQSwrQkFBQyxXQUFNLFNBQVEsVUFBUyx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQVEsdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUEsaUNBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFBTyx1QkFBQyxXQUFNLElBQUcsVUFBUyxXQUFVLFdBQVUsYUFBWSxRQUFPLGdCQUFjTyxRQUFRVCxPQUFPWCxNQUFNLEdBQUcsR0FBSU8sU0FBUyxRQUFRLEtBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVIO0FBQUEsYUFBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSztBQUFBLFFBQU9JLE9BQU9YLFVBQVUsdUJBQUMsV0FBTSxXQUFVLGVBQWVXLGlCQUFPWCxPQUFPcUIsV0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQzVSZixTQUFTVSxXQUFXLHVCQUFDLFNBQUksTUFBSyxTQUFRLFdBQVUsY0FBY3pCLHVCQUFhZSxTQUFTZ0IsS0FBSyxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDM0ZoQixTQUFTaUIsYUFBYSx1QkFBQyxTQUFJLE1BQUssVUFBUyxXQUFVLGdCQUFlLDJDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDOUYsdUJBQUMsWUFBTyxXQUFVLGtCQUFpQixNQUFLLFVBQVMsVUFBVWpCLFNBQVNTLFdBQVlULG1CQUFTUyxZQUFZLGlCQUFpQlgsWUFBWSxlQUFlLGNBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEo7QUFBQSxXQUpzSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS3BTO0FBQUEsU0FMQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS087QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRUDtBQUNGO0FBQUNELEdBakJlRixXQUFTO0FBQUEsVUFFUkwsV0FDRUMsa0JBQ2dEUixPQUFPO0FBQUE7QUFBQSxLQUoxRFk7QUFBUyxJQUFBdUI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiem9kUmVzb2x2ZXIiLCJBcnJvd0Rvd25MZWZ0IiwiQXJyb3dVcFJpZ2h0IiwidXNlRm9ybSIsInoiLCJlcnJvck1lc3NhZ2UiLCJmb3JtYXRNb25leSIsInBvc2l0aXZlQW1vdW50IiwiUXVlcnlFcnJvciIsIlF1ZXJ5U2tlbGV0b24iLCJ1c2VXYWxsZXQiLCJ1c2VNb25leU11dGF0aW9uIiwiYW1vdW50U2NoZW1hIiwib2JqZWN0IiwiYW1vdW50IiwiTW9uZXlQYWdlIiwiYWN0aW9uIiwiX3MiLCJpc0RlcG9zaXQiLCJ3YWxsZXQiLCJtdXRhdGlvbiIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwicmVzZXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJyZXNvbHZlciIsInN1Ym1pdCIsIm11dGF0ZUFzeW5jIiwiaXNQZW5kaW5nIiwiaXNFcnJvciIsInJlZmV0Y2giLCJkYXRhIiwiYmFsYW5jZSIsIkJvb2xlYW4iLCJtZXNzYWdlIiwiZXJyb3IiLCJpc1N1Y2Nlc3MiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtb25leS1wYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xuaW1wb3J0IHsgQXJyb3dEb3duTGVmdCwgQXJyb3dVcFJpZ2h0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXG5pbXBvcnQgeyBlcnJvck1lc3NhZ2UgfSBmcm9tICcuLi8uLi8uLi9saWIvZXJyb3ItbWVzc2FnZSdcbmltcG9ydCB7IGZvcm1hdE1vbmV5IH0gZnJvbSAnLi4vLi4vLi4vbGliL2Zvcm1hdCdcbmltcG9ydCB7IHBvc2l0aXZlQW1vdW50IH0gZnJvbSAnLi4vLi4vLi4vbGliL2Ftb3VudCdcbmltcG9ydCB7IFF1ZXJ5RXJyb3IsIFF1ZXJ5U2tlbGV0b24gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3F1ZXJ5LXN0YXRlJ1xuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnLi4vaG9va3MnXG5pbXBvcnQgeyB1c2VNb25leU11dGF0aW9uLCB0eXBlIE1vbmV5QWN0aW9uIH0gZnJvbSAnLi4vbXV0YXRpb25zJ1xuXG5jb25zdCBhbW91bnRTY2hlbWEgPSB6Lm9iamVjdCh7IGFtb3VudDogcG9zaXRpdmVBbW91bnQgfSlcbnR5cGUgQW1vdW50VmFsdWVzID0gei5pbnB1dDx0eXBlb2YgYW1vdW50U2NoZW1hPlxuXG4vKiogUGFyYSB5YXTEsXJtYSB2ZSDDp2VrbWUgZm9ybXVudSBheW7EsSBrdXJhbGxhcmxhLCBheXLEsSBlbmRwb2ludCdsZXJlIGJhxJ9sYXIuICovXG5leHBvcnQgZnVuY3Rpb24gTW9uZXlQYWdlKHsgYWN0aW9uIH06IHsgYWN0aW9uOiBNb25leUFjdGlvbiB9KSB7XG4gIGNvbnN0IGlzRGVwb3NpdCA9IGFjdGlvbiA9PT0gJ2RlcG9zaXQnXG4gIGNvbnN0IHdhbGxldCA9IHVzZVdhbGxldCgpXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlTW9uZXlNdXRhdGlvbihhY3Rpb24pXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgcmVzZXQsIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSB9ID0gdXNlRm9ybTxBbW91bnRWYWx1ZXMsIHVua25vd24sIHoub3V0cHV0PHR5cGVvZiBhbW91bnRTY2hlbWE+Pih7IHJlc29sdmVyOiB6b2RSZXNvbHZlcihhbW91bnRTY2hlbWEpIH0pXG4gIGNvbnN0IHN1Ym1pdCA9IGhhbmRsZVN1Ym1pdChhc3luYyAoeyBhbW91bnQgfSkgPT4ge1xuICAgIHRyeSB7IGF3YWl0IG11dGF0aW9uLm11dGF0ZUFzeW5jKGFtb3VudCk7IHJlc2V0KCkgfSBjYXRjaCB7IC8qIEhhdGEgYcWfYcSfxLFkYSBnw7ZzdGVyaWxpci4gKi8gfVxuICB9KVxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJjb250ZW50LXN0YWNrIG5hcnJvdy1jb250ZW50XCI+PGhlYWRlciBjbGFzc05hbWU9XCJwYWdlLWhlYWRpbmdcIj48c3BhbiBjbGFzc05hbWU9XCJjYXJkLWtpY2tlclwiPntpc0RlcG9zaXQgPyAnQkFLxLBZRSBFS0xFJyA6ICdCQUvEsFlFIEtVTExBTid9PC9zcGFuPjxoMT57aXNEZXBvc2l0ID8gJ1BhcmEgeWF0xLFyxLFuJyA6ICdQYXJhIMOnZWtpbid9PC9oMT48cD57aXNEZXBvc2l0ID8gJ0PDvHpkYW7EsW7EsXphIGlzdGVkacSfaW5peiB0dXRhcsSxIGVrbGV5aW4uJyA6ICdDw7x6ZGFuxLFuxLF6ZGFuIMOnZWttZWsgaXN0ZWRpxJ9pbml6IHR1dGFyxLEgZ2lyaW4uJ308L3A+PC9oZWFkZXI+XG4gICAge3dhbGxldC5pc1BlbmRpbmcgPyA8UXVlcnlTa2VsZXRvbiAvPiA6IHdhbGxldC5pc0Vycm9yID8gPFF1ZXJ5RXJyb3IgcmV0cnk9eygpID0+IHZvaWQgd2FsbGV0LnJlZmV0Y2goKX0gLz4gOiA8ZGl2IGNsYXNzTmFtZT1cImNvbXBhY3QtYmFsYW5jZVwiPjxzcGFuPkfDvG5jZWwgYmFraXllPC9zcGFuPjxzdHJvbmc+e2Zvcm1hdE1vbmV5KHdhbGxldC5kYXRhLmJhbGFuY2UpfTwvc3Ryb25nPjwvZGl2Pn1cbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmb3JtLXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9e2BsYXJnZS1hY3Rpb24taWNvbiAke2lzRGVwb3NpdCA/ICdtaW50JyA6ICdjb3JhbCd9YH0+e2lzRGVwb3NpdCA/IDxBcnJvd0Rvd25MZWZ0IC8+IDogPEFycm93VXBSaWdodCAvPn08L2Rpdj48aDI+e2lzRGVwb3NpdCA/ICdDw7x6ZGFuxLFuxLF6YSBwYXJhIGVrbGV5aW4nIDogJ0PDvHpkYW7EsW7EsXpkYW4gcGFyYSDDp2VraW4nfTwvaDI+PHA+xLDFn2xlbSBzb25yYXPEsSBnw7xuY2VsIGJha2l5ZW5peiBvdG9tYXRpayB5ZW5pbGVuaXIuPC9wPjxmb3JtIG9uU3VibWl0PXtzdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICA8bGFiZWwgaHRtbEZvcj1cImFtb3VudFwiPlR1dGFyICjigropPC9sYWJlbD48ZGl2IGNsYXNzTmFtZT1cImFtb3VudC1pbnB1dFwiPjxzcGFuPuKCujwvc3Bhbj48aW5wdXQgaWQ9XCJhbW91bnRcIiBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgcGxhY2Vob2xkZXI9XCIwLDAwXCIgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9ycy5hbW91bnQpfSB7Li4ucmVnaXN0ZXIoJ2Ftb3VudCcpfSAvPjwvZGl2PntlcnJvcnMuYW1vdW50ICYmIDxzbWFsbCBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMuYW1vdW50Lm1lc3NhZ2V9PC9zbWFsbD59XG4gICAgICB7bXV0YXRpb24uaXNFcnJvciAmJiA8ZGl2IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImZvcm0tYWxlcnRcIj57ZXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yKX08L2Rpdj59XG4gICAgICB7bXV0YXRpb24uaXNTdWNjZXNzICYmIDxkaXYgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cImZvcm0tc3VjY2Vzc1wiPsSwxZ9sZW0gYmHFn2FyxLF5bGEgdGFtYW1sYW5kxLEuPC9kaXY+fVxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvblwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bXV0YXRpb24uaXNQZW5kaW5nfT57bXV0YXRpb24uaXNQZW5kaW5nID8gJ8SwxZ9sZW5peW9yLi4uJyA6IGlzRGVwb3NpdCA/ICdQYXJhIHlhdMSxcicgOiAnUGFyYSDDp2VrJ308L2J1dHRvbj5cbiAgICA8L2Zvcm0+PC9zZWN0aW9uPlxuICA8L2Rpdj5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvd2FsbGV0L3BhZ2VzL21vbmV5LXBhZ2UudHN4In0=