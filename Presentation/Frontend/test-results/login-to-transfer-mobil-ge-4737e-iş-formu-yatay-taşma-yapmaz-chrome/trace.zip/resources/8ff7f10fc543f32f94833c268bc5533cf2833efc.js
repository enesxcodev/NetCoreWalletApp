import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/error-boundary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const Component = __vite__cjsImport1_react["Component"];
export class ErrorBoundary extends Component {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch() {
  }
  render() {
    if (this.state.hasError) return /* @__PURE__ */ jsxDEV("main", { className: "route-loading", children: [
      /* @__PURE__ */ jsxDEV("h1", { children: "Bir şeyler ters gitti" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx",
        lineNumber: 17,
        columnNumber: 69
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Sayfayı yenileyerek tekrar deneyebilirsiniz." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx",
        lineNumber: 17,
        columnNumber: 99
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "primary-button error-retry", onClick: () => window.location.reload(), children: "Sayfayı yenile" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx",
        lineNumber: 17,
        columnNumber: 150
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx",
      lineNumber: 17,
      columnNumber: 37
    }, this);
    return this.props.children;
  }
}
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/app/error-boundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JvRTtBQWhCcEUsU0FBU0EsaUJBQWlDO0FBTW5DLGFBQU1DLHNCQUFzQkQsVUFBa0Q7QUFBQSxFQUNuRkUsUUFBNEIsRUFBRUMsVUFBVSxNQUFNO0FBQUEsRUFFOUMsT0FBT0MsMkJBQStDO0FBQUUsV0FBTyxFQUFFRCxVQUFVLEtBQUs7QUFBQSxFQUFFO0FBQUEsRUFFbEZFLG9CQUEwQjtBQUFBLEVBQ3hCO0FBQUEsRUFHRkMsU0FBUztBQUNQLFFBQUksS0FBS0osTUFBTUMsU0FBVSxRQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQSw2QkFBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUFLLHVCQUFDLE9BQUUsNERBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQUksdUJBQUMsWUFBTyxXQUFVLDhCQUE2QixTQUFTLE1BQU1JLE9BQU9DLFNBQVNDLE9BQU8sR0FBRyw4QkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRztBQUFBLFNBQXZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ087QUFDaFEsV0FBTyxLQUFLQyxNQUFNQztBQUFBQSxFQUNwQjtBQUNGIiwibmFtZXMiOlsiQ29tcG9uZW50IiwiRXJyb3JCb3VuZGFyeSIsInN0YXRlIiwiaGFzRXJyb3IiLCJnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IiLCJjb21wb25lbnREaWRDYXRjaCIsInJlbmRlciIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwicHJvcHMiLCJjaGlsZHJlbiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJlcnJvci1ib3VuZGFyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuXG5pbnRlcmZhY2UgRXJyb3JCb3VuZGFyeVByb3BzIHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9XG5pbnRlcmZhY2UgRXJyb3JCb3VuZGFyeVN0YXRlIHsgaGFzRXJyb3I6IGJvb2xlYW4gfVxuXG4vKiogQmVrbGVubWV5ZW4gcmVuZGVyIGhhdGFsYXLEsW5kYSBib8WfIGVrcmFuIHllcmluZSBnZXJpIGTDtm7DvMWfIHN1bmFyLiAqL1xuZXhwb3J0IGNsYXNzIEVycm9yQm91bmRhcnkgZXh0ZW5kcyBDb21wb25lbnQ8RXJyb3JCb3VuZGFyeVByb3BzLCBFcnJvckJvdW5kYXJ5U3RhdGU+IHtcbiAgc3RhdGU6IEVycm9yQm91bmRhcnlTdGF0ZSA9IHsgaGFzRXJyb3I6IGZhbHNlIH1cblxuICBzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yKCk6IEVycm9yQm91bmRhcnlTdGF0ZSB7IHJldHVybiB7IGhhc0Vycm9yOiB0cnVlIH0gfVxuXG4gIGNvbXBvbmVudERpZENhdGNoKCk6IHZvaWQge1xuICAgIC8vIEhhdGEgaWxlcmlkZSBtZXJrZXppIGl6bGVtZSBzZXJ2aXNpbmUgYmHEn2xhbmFiaWxpcjsgaGFzc2FzIHZlcmkgbG9nbGFubWF6LlxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIGlmICh0aGlzLnN0YXRlLmhhc0Vycm9yKSByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwicm91dGUtbG9hZGluZ1wiPjxoMT5CaXIgxZ9leWxlciB0ZXJzIGdpdHRpPC9oMT48cD5TYXlmYXnEsSB5ZW5pbGV5ZXJlayB0ZWtyYXIgZGVuZXllYmlsaXJzaW5pei48L3A+PGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBlcnJvci1yZXRyeVwiIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKX0+U2F5ZmF5xLEgeWVuaWxlPC9idXR0b24+PC9tYWluPlxuICAgIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuXG4gIH1cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvYXBwL2Vycm9yLWJvdW5kYXJ5LnRzeCJ9