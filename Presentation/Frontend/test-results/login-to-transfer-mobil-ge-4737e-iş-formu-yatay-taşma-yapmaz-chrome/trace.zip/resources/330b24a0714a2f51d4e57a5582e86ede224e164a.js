import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/network-status-banner.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
export function NetworkStatusBanner() {
  _s();
  const [online, setOnline] = useState(() => navigator.onLine);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);
  return online ? null : /* @__PURE__ */ jsxDEV("div", { className: "network-banner", role: "status", children: "İnternet bağlantısı yok. Bağlantı gelene kadar yeni işlemler gönderilemez." }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/network-status-banner.tsx",
    lineNumber: 12,
    columnNumber: 26
  }, this);
}
_s(NetworkStatusBanner, "nXnAX/msLfw78dsyNf1BTolBr98=");
_c = NetworkStatusBanner;
var _c;
$RefreshReg$(_c, "NetworkStatusBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/network-status-banner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/network-status-banner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/network-status-banner.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3lCOztBQVh6QixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFHN0IsZ0JBQVNDLHNCQUFzQjtBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJSixTQUFTLE1BQU1LLFVBQVVDLE1BQU07QUFDM0RQLFlBQVUsTUFBTTtBQUNkLFVBQU1RLFNBQVNBLE1BQU1ILFVBQVVDLFVBQVVDLE1BQU07QUFDL0NFLFdBQU9DLGlCQUFpQixVQUFVRixNQUFNO0FBQ3hDQyxXQUFPQyxpQkFBaUIsV0FBV0YsTUFBTTtBQUN6QyxXQUFPLE1BQU07QUFBRUMsYUFBT0Usb0JBQW9CLFVBQVVILE1BQU07QUFBR0MsYUFBT0Usb0JBQW9CLFdBQVdILE1BQU07QUFBQSxJQUFFO0FBQUEsRUFDN0csR0FBRyxFQUFFO0FBQ0wsU0FBT0osU0FBUyxPQUFPLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsTUFBSyxVQUFTLDBGQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdIO0FBQ2pKO0FBQUNELEdBVGVELHFCQUFtQjtBQUFBLEtBQW5CQTtBQUFtQixJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIk5ldHdvcmtTdGF0dXNCYW5uZXIiLCJfcyIsIm9ubGluZSIsInNldE9ubGluZSIsIm5hdmlnYXRvciIsIm9uTGluZSIsInVwZGF0ZSIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibmV0d29yay1zdGF0dXMtYmFubmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbi8qKiBUYXJhecSxY8SxIMOnZXZyaW1kxLHFn8SxIG9sZHXEn3VuZGEgacWfbGVtbGVyaW4gZ8O2bmRlcmlsZW1leWVjZcSfaW5pIGJpbGRpcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE5ldHdvcmtTdGF0dXNCYW5uZXIoKSB7XG4gIGNvbnN0IFtvbmxpbmUsIHNldE9ubGluZV0gPSB1c2VTdGF0ZSgoKSA9PiBuYXZpZ2F0b3Iub25MaW5lKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZSA9ICgpID0+IHNldE9ubGluZShuYXZpZ2F0b3Iub25MaW5lKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdvbmxpbmUnLCB1cGRhdGUpXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ29mZmxpbmUnLCB1cGRhdGUpXG4gICAgcmV0dXJuICgpID0+IHsgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ29ubGluZScsIHVwZGF0ZSk7IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgdXBkYXRlKSB9XG4gIH0sIFtdKVxuICByZXR1cm4gb25saW5lID8gbnVsbCA6IDxkaXYgY2xhc3NOYW1lPVwibmV0d29yay1iYW5uZXJcIiByb2xlPVwic3RhdHVzXCI+xLBudGVybmV0IGJhxJ9sYW50xLFzxLEgeW9rLiBCYcSfbGFudMSxIGdlbGVuZSBrYWRhciB5ZW5pIGnFn2xlbWxlciBnw7ZuZGVyaWxlbWV6LjwvZGl2PlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9jb21wb25lbnRzL25ldHdvcmstc3RhdHVzLWJhbm5lci50c3gifQ==