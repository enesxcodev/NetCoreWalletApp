import {
  appendErrors,
  get,
  set
} from "/node_modules/.vite/deps/chunk-OWHQPENV.js?v=88909849";
import "/node_modules/.vite/deps/chunk-R6VANOXX.js?v=88909849";
import "/node_modules/.vite/deps/chunk-ZPWHCABL.js?v=88909849";

// node_modules/@hookform/resolvers/dist/resolvers.mjs
var t = (r, t3, s3) => {
  if (r && "reportValidity" in r) {
    const o3 = get(s3, t3);
    r.setCustomValidity(o3 && o3.message || ""), r.reportValidity();
  }
};
var s = (e, r) => {
  for (const s3 in r.fields) {
    const o3 = r.fields[s3];
    o3 && o3.ref && "reportValidity" in o3.ref ? t(o3.ref, s3, e) : o3 && o3.refs && o3.refs.forEach((r2) => t(r2, s3, e));
  }
};
var o = (t3, o3) => {
  o3.shouldUseNativeValidation && s(t3, o3);
  const n2 = {};
  for (const s3 in t3) {
    const f = get(o3.fields, s3), c = Object.assign(t3[s3] || {}, { ref: f && f.refs ? f.refs[0] : f && f.ref });
    if (i(o3.names || Object.keys(t3), s3)) {
      const t4 = Object.assign({}, get(n2, s3));
      set(t4, "root", c), set(n2, s3, t4);
    } else set(n2, s3, c);
  }
  return n2;
};
var i = (e, r) => {
  const t3 = n(r).replace(/[.*+?^${}()|\\]/g, "\\$&");
  return e.some((e2) => n(e2).match(`^${t3}\\.\\d+`));
};
function n(e) {
  return e.replace(/\[(\d+)]/g, ".$1").replace(/[[\]]/g, "");
}

// node_modules/@hookform/resolvers/zod/dist/zod.mjs
function o2() {
  return o2 = Object.assign ? Object.assign.bind() : function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var n2 = arguments[e];
      for (var o3 in n2) ({}).hasOwnProperty.call(n2, o3) && (r[o3] = n2[o3]);
    }
    return r;
  }, o2.apply(null, arguments);
}
function t2(r, e) {
  try {
    var n2 = r();
  } catch (r2) {
    return e(r2);
  }
  return n2 && n2.then ? n2.then(void 0, e) : n2;
}
function s2(r, e) {
  for (var o3 = /* @__PURE__ */ Object.create(null); r.length; ) {
    var t3 = r[0], s3 = t3.code, i3 = t3.message, u2 = t3.path.join(".");
    if (!o3[u2]) if ("unionErrors" in t3) {
      var a, c, l = t3.unionErrors.reduce(function(r2, e2) {
        return e2.errors.length < r2.errors.length ? e2 : r2;
      }).errors[0];
      o3[u2] = { message: null != (a = null == l ? void 0 : l.message) ? a : i3, type: null != (c = null == l ? void 0 : l.code) ? c : s3 };
    } else o3[u2] = { message: i3, type: s3 };
    if ("unionErrors" in t3 && t3.unionErrors.forEach(function(e2) {
      return e2.errors.forEach(function(e3) {
        return r.push(e3);
      });
    }), e) {
      var f = o3[u2].types, d = f && f[t3.code];
      o3[u2] = appendErrors(u2, e, o3, s3, d ? [].concat(d, t3.message) : t3.message);
    }
    r.shift();
  }
  return o3;
}
function i2(r, e) {
  for (var t3 = /* @__PURE__ */ Object.create(null), s3 = function() {
    var s4 = r[0], i3 = s4.code, u2 = s4.message, a = s4.path.join(".");
    if (!t3[a]) if ("invalid_union" === s4.code && s4.errors.length > 0) {
      var c, l, f = s4.errors.reduce(function(r2, e2) {
        return e2.length < r2.length ? e2 : r2;
      })[0];
      t3[a] = { message: null != (c = null == f ? void 0 : f.message) ? c : u2, type: null != (l = null == f ? void 0 : f.code) ? l : i3 };
    } else t3[a] = { message: u2, type: i3 };
    if ("invalid_union" === s4.code && s4.errors.forEach(function(e2) {
      return e2.forEach(function(e3) {
        return r.push(o2({}, e3, { path: [].concat(s4.path, e3.path) }));
      });
    }), e) {
      var d = t3[a].types, h = d && d[s4.code];
      t3[a] = appendErrors(a, e, t3, i3, h ? [].concat(h, s4.message) : s4.message);
    }
    r.shift();
  }; r.length; ) s3();
  return t3;
}
function u(n2, o3, u2) {
  if (void 0 === u2 && (u2 = {}), (function(r) {
    return "_zod" in r && "object" == typeof r._zod;
  })(n2)) return function(s3, a, c) {
    try {
      return Promise.resolve(t2(function() {
        function e(e2) {
          return c.shouldUseNativeValidation && s({}, c), { errors: {}, values: u2.raw ? Object.assign({}, s3) : e2 };
        }
        var t3 = n2;
        return "sync" === u2.mode ? e(t3.parse(s3, o3)) : Promise.resolve(t3.parseAsync(s3, o3)).then(e);
      }, function(r) {
        if ((function(r2) {
          var e;
          return !(null == r2 || null == (e = r2._zod) || null == (e = e.traits) || !e.has("$ZodError"));
        })(r)) return { values: {}, errors: o(i2(r.issues, !c.shouldUseNativeValidation && "all" === c.criteriaMode), c) };
        throw r;
      }));
    } catch (r) {
      return Promise.reject(r);
    }
  };
  if ((function(r) {
    return "_def" in r && "object" == typeof r._def;
  })(n2)) return function(i3, a, c) {
    try {
      return Promise.resolve(t2(function() {
        return Promise.resolve(n2["sync" === u2.mode ? "parse" : "parseAsync"](i3, o3)).then(function(e) {
          return c.shouldUseNativeValidation && s({}, c), { errors: {}, values: u2.raw ? Object.assign({}, i3) : e };
        });
      }, function(r) {
        if ((function(r2) {
          return Array.isArray(null == r2 ? void 0 : r2.issues);
        })(r)) return { values: {}, errors: o(s2(r.errors, !c.shouldUseNativeValidation && "all" === c.criteriaMode), c) };
        throw r;
      }));
    } catch (r) {
      return Promise.reject(r);
    }
  };
  throw new Error("Invalid input: not a Zod schema");
}
export {
  u as zodResolver
};
//# sourceMappingURL=@hookform_resolvers_zod.js.map
