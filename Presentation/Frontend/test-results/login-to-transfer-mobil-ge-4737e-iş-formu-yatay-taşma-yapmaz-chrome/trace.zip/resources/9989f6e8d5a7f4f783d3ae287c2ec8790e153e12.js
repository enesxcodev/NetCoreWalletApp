import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/password-field.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport1_react["useState"];
import { Eye, EyeOff, LockKeyhole } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
export function PasswordField({ label, error, id, registration, ...props }) {
  _s();
  const [visible, setVisible] = useState(false);
  const fieldId = id ?? "password";
  return /* @__PURE__ */ jsxDEV("div", { className: "field-wrap", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "field-label", htmlFor: fieldId, children: label }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `input-shell ${error ? "input-error" : ""}`, children: [
      /* @__PURE__ */ jsxDEV(LockKeyhole, { className: "input-icon", size: 18, "aria-hidden": "true" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: fieldId, type: visible ? "text" : "password", autoComplete: props.autoComplete ?? "current-password", placeholder: props.placeholder, "aria-invalid": Boolean(error), "aria-describedby": error ? `${fieldId}-error` : void 0, ...registration }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "visibility-toggle", type: "button", onClick: () => setVisible((current) => !current), "aria-label": visible ? "Şifreyi gizle" : "Şifreyi göster", children: visible ? /* @__PURE__ */ jsxDEV(EyeOff, { size: 18 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
        lineNumber: 23,
        columnNumber: 22
      }, this) : /* @__PURE__ */ jsxDEV(Eye, { size: 18 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
        lineNumber: 23,
        columnNumber: 45
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "field-error", id: `${fieldId}-error`, children: error }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
      lineNumber: 26,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_s(PasswordField, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = PasswordField;
var _c;
$RefreshReg$(_c, "PasswordField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/password-field.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNOztBQWpCTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsS0FBS0MsUUFBUUMsbUJBQW1CO0FBV2xDLGdCQUFTQyxjQUFjLEVBQUVDLE9BQU9DLE9BQU9DLElBQUlDLGNBQWMsR0FBR0MsTUFBMEIsR0FBRztBQUFBQyxLQUFBO0FBQzlGLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJWixTQUFTLEtBQUs7QUFDNUMsUUFBTWEsVUFBVU4sTUFBTTtBQUN0QixTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsV0FBTSxXQUFVLGVBQWMsU0FBU00sU0FBVVIsbUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxJQUN4RCx1QkFBQyxTQUFJLFdBQVcsZUFBZUMsUUFBUSxnQkFBZ0IsRUFBRSxJQUN2RDtBQUFBLDZCQUFDLGVBQVksV0FBVSxjQUFhLE1BQU0sSUFBSSxlQUFZLFVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxXQUFNLElBQUlPLFNBQVMsTUFBTUYsVUFBVSxTQUFTLFlBQVksY0FBY0YsTUFBTUssZ0JBQWdCLG9CQUFvQixhQUFhTCxNQUFNTSxhQUFhLGdCQUFjQyxRQUFRVixLQUFLLEdBQUcsb0JBQWtCQSxRQUFRLEdBQUdPLE9BQU8sV0FBV0ksUUFBVyxHQUFJVCxnQkFBN087QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwUDtBQUFBLE1BQzFQLHVCQUFDLFlBQU8sV0FBVSxxQkFBb0IsTUFBSyxVQUFTLFNBQVMsTUFBTUksV0FBVyxDQUFDTSxZQUFZLENBQUNBLE9BQU8sR0FBRyxjQUFZUCxVQUFVLGtCQUFrQixrQkFDM0lBLG9CQUFVLHVCQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsSUFBTSx1QkFBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNDTCxTQUFTLHVCQUFDLE9BQUUsV0FBVSxlQUFjLElBQUksR0FBR08sT0FBTyxVQUFXUCxtQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BVHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUNJLEdBaEJlTixlQUFhO0FBQUEsS0FBYkE7QUFBYSxJQUFBZTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkV5ZSIsIkV5ZU9mZiIsIkxvY2tLZXlob2xlIiwiUGFzc3dvcmRGaWVsZCIsImxhYmVsIiwiZXJyb3IiLCJpZCIsInJlZ2lzdHJhdGlvbiIsInByb3BzIiwiX3MiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImZpZWxkSWQiLCJhdXRvQ29tcGxldGUiLCJwbGFjZWhvbGRlciIsIkJvb2xlYW4iLCJ1bmRlZmluZWQiLCJjdXJyZW50IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsicGFzc3dvcmQtZmllbGQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBFeWUsIEV5ZU9mZiwgTG9ja0tleWhvbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgdHlwZSB7IElucHV0SFRNTEF0dHJpYnV0ZXMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB0eXBlIHsgVXNlRm9ybVJlZ2lzdGVyUmV0dXJuIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuXG5pbnRlcmZhY2UgUGFzc3dvcmRGaWVsZFByb3BzIGV4dGVuZHMgSW5wdXRIVE1MQXR0cmlidXRlczxIVE1MSW5wdXRFbGVtZW50PiB7XG4gIGxhYmVsOiBzdHJpbmdcbiAgZXJyb3I/OiBzdHJpbmdcbiAgcmVnaXN0cmF0aW9uPzogVXNlRm9ybVJlZ2lzdGVyUmV0dXJuXG59XG5cbi8qKiDFnmlmcmV5aSBnaXpsaSBnw7ZzdGVyaXIgdmUga3VsbGFuxLFjxLEgaXN0ZXJzZSBnw7Zyw7xuw7xyIHlhcGFyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFBhc3N3b3JkRmllbGQoeyBsYWJlbCwgZXJyb3IsIGlkLCByZWdpc3RyYXRpb24sIC4uLnByb3BzIH06IFBhc3N3b3JkRmllbGRQcm9wcykge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgZmllbGRJZCA9IGlkID8/ICdwYXNzd29yZCdcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkLXdyYXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZC1sYWJlbFwiIGh0bWxGb3I9e2ZpZWxkSWR9PntsYWJlbH08L2xhYmVsPlxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BpbnB1dC1zaGVsbCAke2Vycm9yID8gJ2lucHV0LWVycm9yJyA6ICcnfWB9PlxuICAgICAgICA8TG9ja0tleWhvbGUgY2xhc3NOYW1lPVwiaW5wdXQtaWNvblwiIHNpemU9ezE4fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8aW5wdXQgaWQ9e2ZpZWxkSWR9IHR5cGU9e3Zpc2libGUgPyAndGV4dCcgOiAncGFzc3dvcmQnfSBhdXRvQ29tcGxldGU9e3Byb3BzLmF1dG9Db21wbGV0ZSA/PyAnY3VycmVudC1wYXNzd29yZCd9IHBsYWNlaG9sZGVyPXtwcm9wcy5wbGFjZWhvbGRlcn0gYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9yKX0gYXJpYS1kZXNjcmliZWRieT17ZXJyb3IgPyBgJHtmaWVsZElkfS1lcnJvcmAgOiB1bmRlZmluZWR9IHsuLi5yZWdpc3RyYXRpb259IC8+XG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidmlzaWJpbGl0eS10b2dnbGVcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0VmlzaWJsZSgoY3VycmVudCkgPT4gIWN1cnJlbnQpfSBhcmlhLWxhYmVsPXt2aXNpYmxlID8gJ8WeaWZyZXlpIGdpemxlJyA6ICfFnmlmcmV5aSBnw7ZzdGVyJ30+XG4gICAgICAgICAge3Zpc2libGUgPyA8RXllT2ZmIHNpemU9ezE4fSAvPiA6IDxFeWUgc2l6ZT17MTh9IC8+fVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCIgaWQ9e2Ake2ZpZWxkSWR9LWVycm9yYH0+e2Vycm9yfTwvcD59XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9wYXNzd29yZC1maWVsZC50c3gifQ==