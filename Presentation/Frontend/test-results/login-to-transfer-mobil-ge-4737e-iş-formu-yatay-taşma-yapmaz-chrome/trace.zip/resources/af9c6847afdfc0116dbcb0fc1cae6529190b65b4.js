import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/components/register-form.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=88909849";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=88909849";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { FormField } from "/src/features/auth/components/form-field.tsx";
import { PasswordField } from "/src/components/password-field.tsx";
import { errorMessage } from "/src/lib/error-message.ts";
import { registerSchema } from "/src/features/auth/schemas/auth-schemas.ts";
import { useRegisterMutation } from "/src/features/auth/hooks/use-auth-mutations.ts";
export function RegisterForm() {
  _s();
  const navigate = useNavigate();
  const mutation = useRegisterMutation();
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(registerSchema), mode: "onBlur" });
  const onSubmit = handleSubmit(async (values) => {
    try {
      await mutation.mutateAsync(values);
      navigate("/login", { replace: true, state: { notice: "Hesabınız oluşturuldu. Şimdi giriş yapabilirsiniz." } });
    } catch {
    }
  });
  const serverError = mutation.error ? errorMessage(mutation.error) : null;
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-card register-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "card-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "WALLET AİLESİNE KATILIN" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Hesabınızı oluşturun" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Güvenli cüzdanınız birkaç adımda hazır." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "auth-form register-form", onSubmit, noValidate: true, children: [
      serverError && /* @__PURE__ */ jsxDEV("div", { className: "form-alert", role: "alert", children: serverError }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 37,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "field-row", children: [
        /* @__PURE__ */ jsxDEV(FormField, { label: "Ad", placeholder: "Adınız", autoComplete: "given-name", registration: register("firstName"), error: errors.firstName?.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FormField, { label: "Soyad", placeholder: "Soyadınız", autoComplete: "family-name", registration: register("lastName"), error: errors.lastName?.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 40,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FormField, { label: "E-posta", placeholder: "ornek@posta.com", autoComplete: "email", type: "email", icon: "email", registration: register("email"), error: errors.email?.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FormField, { label: "Kullanıcı adı", placeholder: "Kullanıcı adınızı seçin", autoComplete: "username", icon: "at", registration: register("userName"), error: errors.userName?.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PasswordField, { label: "Şifre", placeholder: "En az 6 karakter", autoComplete: "new-password", registration: register("password"), error: errors.password?.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "password-hint", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "hint-check", children: "✓" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 45,
          columnNumber: 38
        }, this),
        " En az 6 karakter kullanın."
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "primary-button", type: "submit", disabled: mutation.isPending, children: mutation.isPending ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 47,
          columnNumber: 35
        }, this),
        " Hesap oluşturuluyor"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 47,
        columnNumber: 33
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        "Ücretsiz hesap oluştur ",
        /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 47,
          columnNumber: 114
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 47,
        columnNumber: 89
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-switch", children: [
      "Zaten hesabınız var mı? ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: [
        "Giriş yapın ",
        /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
          lineNumber: 50,
          columnNumber: 88
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
        lineNumber: 50,
        columnNumber: 58
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_s(RegisterForm, "vs6fy5TjlIGOVGedf+dejBQJnqU=", false, function() {
  return [useNavigate, useRegisterMutation, useForm];
});
_c = RegisterForm;
var _c;
$RefreshReg$(_c, "RegisterForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/register-form.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JRLFNBZXdCLFVBZnhCOztBQS9CUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBRS9CLFNBQVNDLDJCQUEyQjtBQUs3QixnQkFBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQzdCLFFBQU1DLFdBQVdSLFlBQVk7QUFDN0IsUUFBTVMsV0FBV0osb0JBQW9CO0FBQ3JDLFFBQU0sRUFBRUssVUFBVUMsY0FBY0MsV0FBVyxFQUFFQyxPQUFPLEVBQUUsSUFBSWYsUUFBd0IsRUFBRWdCLFVBQVVqQixZQUFZTyxjQUFjLEdBQUdXLE1BQU0sU0FBUyxDQUFDO0FBRTNJLFFBQU1DLFdBQVdMLGFBQWEsT0FBT00sV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTVIsU0FBU1MsWUFBWUQsTUFBTTtBQUNqQ1QsZUFBUyxVQUFVLEVBQUVXLFNBQVMsTUFBTUMsT0FBTyxFQUFFQyxRQUFRLHFEQUFxRCxFQUFFLENBQUM7QUFBQSxJQUMvRyxRQUFRO0FBQUEsSUFDTjtBQUFBLEVBRUosQ0FBQztBQUNELFFBQU1DLGNBQWNiLFNBQVNjLFFBQVFwQixhQUFhTSxTQUFTYyxLQUFLLElBQUk7QUFFcEUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsZUFBYyx1Q0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQ3JELHVCQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLE9BQUUsdURBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLFNBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQixVQUFvQixZQUFVLE1BQ3JFRDtBQUFBQSxxQkFBZSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxNQUFLLFNBQVNBLHlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNEO0FBQUEsTUFDdEUsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxhQUFVLE9BQU0sTUFBSyxhQUFZLFVBQVMsY0FBYSxjQUFhLGNBQWNaLFNBQVMsV0FBVyxHQUFHLE9BQU9HLE9BQU9XLFdBQVdDLFdBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkk7QUFBQSxRQUMzSSx1QkFBQyxhQUFVLE9BQU0sU0FBUSxhQUFZLGFBQVksY0FBYSxlQUFjLGNBQWNmLFNBQVMsVUFBVSxHQUFHLE9BQU9HLE9BQU9hLFVBQVVELFdBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0o7QUFBQSxXQUZsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGFBQVUsT0FBTSxXQUFVLGFBQVksbUJBQWtCLGNBQWEsU0FBUSxNQUFLLFNBQVEsTUFBSyxTQUFRLGNBQWNmLFNBQVMsT0FBTyxHQUFHLE9BQU9HLE9BQU9jLE9BQU9GLFdBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0s7QUFBQSxNQUN0Syx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLGFBQVksMkJBQTBCLGNBQWEsWUFBVyxNQUFLLE1BQUssY0FBY2YsU0FBUyxVQUFVLEdBQUcsT0FBT0csT0FBT2UsVUFBVUgsV0FBcks7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2SztBQUFBLE1BQzdLLHVCQUFDLGlCQUFjLE9BQU0sU0FBUSxhQUFZLG9CQUFtQixjQUFhLGdCQUFlLGNBQWNmLFNBQVMsVUFBVSxHQUFHLE9BQU9HLE9BQU9nQixVQUFVSixXQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRKO0FBQUEsTUFDNUosdUJBQUMsT0FBRSxXQUFVLGlCQUFnQjtBQUFBLCtCQUFDLFVBQUssV0FBVSxjQUFhLGlCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsUUFBTztBQUFBLFdBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkY7QUFBQSxNQUM3Rix1QkFBQyxZQUFPLFdBQVUsa0JBQWlCLE1BQUssVUFBUyxVQUFVaEIsU0FBU3FCLFdBQ2pFckIsbUJBQVNxQixZQUFZLG1DQUFFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUFHO0FBQUEsV0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRCxJQUFNLG1DQUFFO0FBQUE7QUFBQSxRQUF1Qix1QkFBQyxVQUFLLGVBQVksUUFBTyxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFdBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQsS0FEMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUNBLHVCQUFDLE9BQUUsV0FBVSxlQUFjO0FBQUE7QUFBQSxNQUF3Qix1QkFBQyxRQUFLLElBQUcsVUFBUztBQUFBO0FBQUEsUUFBWSx1QkFBQyxVQUFLLGVBQVksUUFBTyxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxTQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlIO0FBQUEsT0FwQjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQkE7QUFFSjtBQUFDdkIsR0F2Q2VELGNBQVk7QUFBQSxVQUNUTixhQUNBSyxxQkFDeUNQLE9BQU87QUFBQTtBQUFBLEtBSG5EUTtBQUFZLElBQUF5QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ6b2RSZXNvbHZlciIsInVzZUZvcm0iLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJGb3JtRmllbGQiLCJQYXNzd29yZEZpZWxkIiwiZXJyb3JNZXNzYWdlIiwicmVnaXN0ZXJTY2hlbWEiLCJ1c2VSZWdpc3Rlck11dGF0aW9uIiwiUmVnaXN0ZXJGb3JtIiwiX3MiLCJuYXZpZ2F0ZSIsIm11dGF0aW9uIiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJyZXNvbHZlciIsIm1vZGUiLCJvblN1Ym1pdCIsInZhbHVlcyIsIm11dGF0ZUFzeW5jIiwicmVwbGFjZSIsInN0YXRlIiwibm90aWNlIiwic2VydmVyRXJyb3IiLCJlcnJvciIsImZpcnN0TmFtZSIsIm1lc3NhZ2UiLCJsYXN0TmFtZSIsImVtYWlsIiwidXNlck5hbWUiLCJwYXNzd29yZCIsImlzUGVuZGluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInJlZ2lzdGVyLWZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgRm9ybUZpZWxkIH0gZnJvbSAnLi9mb3JtLWZpZWxkJ1xuaW1wb3J0IHsgUGFzc3dvcmRGaWVsZCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcGFzc3dvcmQtZmllbGQnXG5pbXBvcnQgeyBlcnJvck1lc3NhZ2UgfSBmcm9tICcuLi8uLi8uLi9saWIvZXJyb3ItbWVzc2FnZSdcbmltcG9ydCB7IHJlZ2lzdGVyU2NoZW1hIH0gZnJvbSAnLi4vc2NoZW1hcy9hdXRoLXNjaGVtYXMnXG5pbXBvcnQgdHlwZSB7IHogfSBmcm9tICd6b2QnXG5pbXBvcnQgeyB1c2VSZWdpc3Rlck11dGF0aW9uIH0gZnJvbSAnLi4vaG9va3MvdXNlLWF1dGgtbXV0YXRpb25zJ1xuXG50eXBlIFJlZ2lzdGVyVmFsdWVzID0gei5pbmZlcjx0eXBlb2YgcmVnaXN0ZXJTY2hlbWE+XG5cbi8qKiBLYXnEsXQgYWxhbmxhcsSxbsSxIGRvxJ9ydWxhciB2ZSBiYcWfYXLEsWzEsSBoZXNhcCBhw6fEsWzEscWfxLFuxLEga3VsbGFuxLFjxLF5YSBiaWxkaXJpci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSZWdpc3RlckZvcm0oKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBtdXRhdGlvbiA9IHVzZVJlZ2lzdGVyTXV0YXRpb24oKVxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSB9ID0gdXNlRm9ybTxSZWdpc3RlclZhbHVlcz4oeyByZXNvbHZlcjogem9kUmVzb2x2ZXIocmVnaXN0ZXJTY2hlbWEpLCBtb2RlOiAnb25CbHVyJyB9KVxuXG4gIGNvbnN0IG9uU3VibWl0ID0gaGFuZGxlU3VibWl0KGFzeW5jICh2YWx1ZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbXV0YXRpb24ubXV0YXRlQXN5bmModmFsdWVzKVxuICAgICAgbmF2aWdhdGUoJy9sb2dpbicsIHsgcmVwbGFjZTogdHJ1ZSwgc3RhdGU6IHsgbm90aWNlOiAnSGVzYWLEsW7EsXogb2x1xZ90dXJ1bGR1LiDFnmltZGkgZ2lyacWfIHlhcGFiaWxpcnNpbml6LicgfSB9KVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gTXV0YXRpb24gaGF0YXPEsSBmb3JtIMO8emVyaW5kZSBnw7ZzdGVyaWxpci5cbiAgICB9XG4gIH0pXG4gIGNvbnN0IHNlcnZlckVycm9yID0gbXV0YXRpb24uZXJyb3IgPyBlcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpIDogbnVsbFxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNhcmQgcmVnaXN0ZXItY2FyZFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWhlYWRpbmdcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FyZC1raWNrZXJcIj5XQUxMRVQgQcSwTEVTxLBORSBLQVRJTElOPC9zcGFuPlxuICAgICAgICA8aDI+SGVzYWLEsW7EsXrEsSBvbHXFn3R1cnVuPC9oMj5cbiAgICAgICAgPHA+R8O8dmVubGkgY8O8emRhbsSxbsSxeiBiaXJrYcOnIGFkxLFtZGEgaGF6xLFyLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiYXV0aC1mb3JtIHJlZ2lzdGVyLWZvcm1cIiBvblN1Ym1pdD17b25TdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICAgIHtzZXJ2ZXJFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tYWxlcnRcIiByb2xlPVwiYWxlcnRcIj57c2VydmVyRXJyb3J9PC9kaXY+fVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkLXJvd1wiPlxuICAgICAgICAgIDxGb3JtRmllbGQgbGFiZWw9XCJBZFwiIHBsYWNlaG9sZGVyPVwiQWTEsW7EsXpcIiBhdXRvQ29tcGxldGU9XCJnaXZlbi1uYW1lXCIgcmVnaXN0cmF0aW9uPXtyZWdpc3RlcignZmlyc3ROYW1lJyl9IGVycm9yPXtlcnJvcnMuZmlyc3ROYW1lPy5tZXNzYWdlfSAvPlxuICAgICAgICAgIDxGb3JtRmllbGQgbGFiZWw9XCJTb3lhZFwiIHBsYWNlaG9sZGVyPVwiU295YWTEsW7EsXpcIiBhdXRvQ29tcGxldGU9XCJmYW1pbHktbmFtZVwiIHJlZ2lzdHJhdGlvbj17cmVnaXN0ZXIoJ2xhc3ROYW1lJyl9IGVycm9yPXtlcnJvcnMubGFzdE5hbWU/Lm1lc3NhZ2V9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8Rm9ybUZpZWxkIGxhYmVsPVwiRS1wb3N0YVwiIHBsYWNlaG9sZGVyPVwib3JuZWtAcG9zdGEuY29tXCIgYXV0b0NvbXBsZXRlPVwiZW1haWxcIiB0eXBlPVwiZW1haWxcIiBpY29uPVwiZW1haWxcIiByZWdpc3RyYXRpb249e3JlZ2lzdGVyKCdlbWFpbCcpfSBlcnJvcj17ZXJyb3JzLmVtYWlsPy5tZXNzYWdlfSAvPlxuICAgICAgICA8Rm9ybUZpZWxkIGxhYmVsPVwiS3VsbGFuxLFjxLEgYWTEsVwiIHBsYWNlaG9sZGVyPVwiS3VsbGFuxLFjxLEgYWTEsW7EsXrEsSBzZcOnaW5cIiBhdXRvQ29tcGxldGU9XCJ1c2VybmFtZVwiIGljb249XCJhdFwiIHJlZ2lzdHJhdGlvbj17cmVnaXN0ZXIoJ3VzZXJOYW1lJyl9IGVycm9yPXtlcnJvcnMudXNlck5hbWU/Lm1lc3NhZ2V9IC8+XG4gICAgICAgIDxQYXNzd29yZEZpZWxkIGxhYmVsPVwixZ5pZnJlXCIgcGxhY2Vob2xkZXI9XCJFbiBheiA2IGthcmFrdGVyXCIgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCIgcmVnaXN0cmF0aW9uPXtyZWdpc3RlcigncGFzc3dvcmQnKX0gZXJyb3I9e2Vycm9ycy5wYXNzd29yZD8ubWVzc2FnZX0gLz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicGFzc3dvcmQtaGludFwiPjxzcGFuIGNsYXNzTmFtZT1cImhpbnQtY2hlY2tcIj7inJM8L3NwYW4+IEVuIGF6IDYga2FyYWt0ZXIga3VsbGFuxLFuLjwvcD5cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvblwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bXV0YXRpb24uaXNQZW5kaW5nfT5cbiAgICAgICAgICB7bXV0YXRpb24uaXNQZW5kaW5nID8gPD48c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyXCIgLz4gSGVzYXAgb2x1xZ90dXJ1bHV5b3I8Lz4gOiA8PsOcY3JldHNpeiBoZXNhcCBvbHXFn3R1ciA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7ihpI8L3NwYW4+PC8+fVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cImF1dGgtc3dpdGNoXCI+WmF0ZW4gaGVzYWLEsW7EsXogdmFyIG3EsT8gPExpbmsgdG89XCIvbG9naW5cIj5HaXJpxZ8geWFwxLFuIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj48L0xpbms+PC9wPlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3Jvb3Qvc291cmNlL3JlcG9zL1dhbGxldC9QcmVzZW50YXRpb24vRnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2F1dGgvY29tcG9uZW50cy9yZWdpc3Rlci1mb3JtLnRzeCJ9