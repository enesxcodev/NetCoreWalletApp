import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/components/form-field.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { AtSign, Mail, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
const icons = { user: UserRound, email: Mail, at: AtSign };
export function FormField({ label, error, icon = "user", id, registration, ...props }) {
  const Icon = icons[icon];
  const fieldId = id ?? registration?.name ?? props.name;
  return /* @__PURE__ */ jsxDEV("div", { className: "field-wrap", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "field-label", htmlFor: fieldId, children: label }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `input-shell ${error ? "input-error" : ""}`, children: [
      /* @__PURE__ */ jsxDEV(Icon, { className: "input-icon", size: 18, "aria-hidden": "true" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: fieldId, autoComplete: props.autoComplete, type: props.type, placeholder: props.placeholder, "aria-invalid": Boolean(error), "aria-describedby": error ? `${fieldId}-error` : void 0, ...registration }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "field-error", id: `${fieldId}-error`, children: error }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
      lineNumber: 25,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_c = FormField;
var _c;
$RefreshReg$(_c, "FormField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/form-field.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNO0FBbkJOLFNBQVNBLFFBQVFDLE1BQU1DLGlCQUFpQjtBQUl4QyxNQUFNQyxRQUFRLEVBQUVDLE1BQU1GLFdBQVdHLE9BQU9KLE1BQU1LLElBQUlOLE9BQU87QUFVbEQsZ0JBQVNPLFVBQVUsRUFBRUMsT0FBT0MsT0FBT0MsT0FBTyxRQUFRQyxJQUFJQyxjQUFjLEdBQUdDLE1BQXNCLEdBQUc7QUFDckcsUUFBTUMsT0FBT1gsTUFBTU8sSUFBSTtBQUN2QixRQUFNSyxVQUFVSixNQUFNQyxjQUFjSSxRQUFRSCxNQUFNRztBQUNsRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsV0FBTSxXQUFVLGVBQWMsU0FBU0QsU0FBVVAsbUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxJQUN4RCx1QkFBQyxTQUFJLFdBQVcsZUFBZUMsUUFBUSxnQkFBZ0IsRUFBRSxJQUN2RDtBQUFBLDZCQUFDLFFBQUssV0FBVSxjQUFhLE1BQU0sSUFBSSxlQUFZLFVBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUN6RCx1QkFBQyxXQUFNLElBQUlNLFNBQVMsY0FBY0YsTUFBTUksY0FBYyxNQUFNSixNQUFNSyxNQUFNLGFBQWFMLE1BQU1NLGFBQWEsZ0JBQWNDLFFBQVFYLEtBQUssR0FBRyxvQkFBa0JBLFFBQVEsR0FBR00sT0FBTyxXQUFXTSxRQUFXLEdBQUlULGdCQUFwTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlOO0FBQUEsU0FGbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQ0gsU0FBUyx1QkFBQyxPQUFFLFdBQVUsZUFBYyxJQUFJLEdBQUdNLE9BQU8sVUFBV04sbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxPQU50RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDYSxLQWJlZjtBQUFTLElBQUFlO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkF0U2lnbiIsIk1haWwiLCJVc2VyUm91bmQiLCJpY29ucyIsInVzZXIiLCJlbWFpbCIsImF0IiwiRm9ybUZpZWxkIiwibGFiZWwiLCJlcnJvciIsImljb24iLCJpZCIsInJlZ2lzdHJhdGlvbiIsInByb3BzIiwiSWNvbiIsImZpZWxkSWQiLCJuYW1lIiwiYXV0b0NvbXBsZXRlIiwidHlwZSIsInBsYWNlaG9sZGVyIiwiQm9vbGVhbiIsInVuZGVmaW5lZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImZvcm0tZmllbGQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEF0U2lnbiwgTWFpbCwgVXNlclJvdW5kIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHR5cGUgeyBJbnB1dEhUTUxBdHRyaWJ1dGVzIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgdHlwZSB7IFVzZUZvcm1SZWdpc3RlclJldHVybiB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcblxuY29uc3QgaWNvbnMgPSB7IHVzZXI6IFVzZXJSb3VuZCwgZW1haWw6IE1haWwsIGF0OiBBdFNpZ24gfVxuXG5pbnRlcmZhY2UgRm9ybUZpZWxkUHJvcHMgZXh0ZW5kcyBJbnB1dEhUTUxBdHRyaWJ1dGVzPEhUTUxJbnB1dEVsZW1lbnQ+IHtcbiAgbGFiZWw6IHN0cmluZ1xuICBlcnJvcj86IHN0cmluZ1xuICBpY29uPzoga2V5b2YgdHlwZW9mIGljb25zXG4gIHJlZ2lzdHJhdGlvbj86IFVzZUZvcm1SZWdpc3RlclJldHVyblxufVxuXG4vKiogRm9ybSBhbGFuxLFuxLEgaWtvbiwgZXJpxZ9pbGViaWxpciBoYXRhIHZlIG9ydGFrIGfDtnJzZWwgc3RpbGxlIHN1bmFyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZvcm1GaWVsZCh7IGxhYmVsLCBlcnJvciwgaWNvbiA9ICd1c2VyJywgaWQsIHJlZ2lzdHJhdGlvbiwgLi4ucHJvcHMgfTogRm9ybUZpZWxkUHJvcHMpIHtcbiAgY29uc3QgSWNvbiA9IGljb25zW2ljb25dXG4gIGNvbnN0IGZpZWxkSWQgPSBpZCA/PyByZWdpc3RyYXRpb24/Lm5hbWUgPz8gcHJvcHMubmFtZVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtd3JhcFwiPlxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCIgaHRtbEZvcj17ZmllbGRJZH0+e2xhYmVsfTwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGlucHV0LXNoZWxsICR7ZXJyb3IgPyAnaW5wdXQtZXJyb3InIDogJyd9YH0+XG4gICAgICAgIDxJY29uIGNsYXNzTmFtZT1cImlucHV0LWljb25cIiBzaXplPXsxOH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgPGlucHV0IGlkPXtmaWVsZElkfSBhdXRvQ29tcGxldGU9e3Byb3BzLmF1dG9Db21wbGV0ZX0gdHlwZT17cHJvcHMudHlwZX0gcGxhY2Vob2xkZXI9e3Byb3BzLnBsYWNlaG9sZGVyfSBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3IpfSBhcmlhLWRlc2NyaWJlZGJ5PXtlcnJvciA/IGAke2ZpZWxkSWR9LWVycm9yYCA6IHVuZGVmaW5lZH0gey4uLnJlZ2lzdHJhdGlvbn0gLz5cbiAgICAgIDwvZGl2PlxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCIgaWQ9e2Ake2ZpZWxkSWR9LWVycm9yYH0+e2Vycm9yfTwvcD59XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvYXV0aC9jb21wb25lbnRzL2Zvcm0tZmllbGQudHN4In0=