import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/pages/login-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { AuthLayout } from "/src/layouts/auth-layout.tsx";
import { LoginForm } from "/src/features/auth/components/login-form.tsx";
export function LoginPage() {
  _s();
  const location = useLocation();
  const notice = location.state?.notice;
  return /* @__PURE__ */ jsxDEV(AuthLayout, { page: "login", children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    notice && /* @__PURE__ */ jsxDEV("p", { className: "form-success", role: "status", children: notice }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx",
      lineNumber: 9,
      columnNumber: 48
    }, this),
    /* @__PURE__ */ jsxDEV(LoginForm, {}, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx",
      lineNumber: 9,
      columnNumber: 103
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx",
    lineNumber: 9,
    columnNumber: 35
  }, this) }, void 0, false, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_s(LoginPage, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/pages/login-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUWtDLG1CQUFhLGNBQWI7O0FBUmxDLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBR25CLGdCQUFTQyxZQUFZO0FBQUFDLEtBQUE7QUFDMUIsUUFBTUMsV0FBV0wsWUFBWTtBQUM3QixRQUFNTSxTQUFVRCxTQUFTRSxPQUFzQ0Q7QUFDL0QsU0FBTyx1QkFBQyxjQUFXLE1BQUssU0FBUSw2Q0FBR0E7QUFBQUEsY0FBVSx1QkFBQyxPQUFFLFdBQVUsZ0JBQWUsTUFBSyxVQUFVQSxvQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRDtBQUFBLElBQUssdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxPQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlGLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkc7QUFDdEg7QUFBQ0YsR0FKZUQsV0FBUztBQUFBLFVBQ05ILFdBQVc7QUFBQTtBQUFBLEtBRGRHO0FBQVMsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTG9jYXRpb24iLCJBdXRoTGF5b3V0IiwiTG9naW5Gb3JtIiwiTG9naW5QYWdlIiwiX3MiLCJsb2NhdGlvbiIsIm5vdGljZSIsInN0YXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibG9naW4tcGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQXV0aExheW91dCB9IGZyb20gJy4uLy4uLy4uL2xheW91dHMvYXV0aC1sYXlvdXQnXG5pbXBvcnQgeyBMb2dpbkZvcm0gfSBmcm9tICcuLi9jb21wb25lbnRzL2xvZ2luLWZvcm0nXG5cbi8qKiBPdHVydW0gYcOnbWEgZWtyYW7EsW7EsSBvcnRhayBhdXRoIGfDtnLDvG7DvG3DvCBpw6dpbmRlIHN1bmFyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IG5vdGljZSA9IChsb2NhdGlvbi5zdGF0ZSBhcyB7IG5vdGljZT86IHN0cmluZyB9IHwgbnVsbCk/Lm5vdGljZVxuICByZXR1cm4gPEF1dGhMYXlvdXQgcGFnZT1cImxvZ2luXCI+PD57bm90aWNlICYmIDxwIGNsYXNzTmFtZT1cImZvcm0tc3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIj57bm90aWNlfTwvcD59PExvZ2luRm9ybSAvPjwvPjwvQXV0aExheW91dD5cbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvcm9vdC9zb3VyY2UvcmVwb3MvV2FsbGV0L1ByZXNlbnRhdGlvbi9Gcm9udGVuZC9zcmMvZmVhdHVyZXMvYXV0aC9wYWdlcy9sb2dpbi1wYWdlLnRzeCJ9