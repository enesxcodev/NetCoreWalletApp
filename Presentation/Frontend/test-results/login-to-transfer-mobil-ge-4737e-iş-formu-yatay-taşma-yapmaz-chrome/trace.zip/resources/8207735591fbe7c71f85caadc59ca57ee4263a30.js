import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/components/login-form.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=88909849";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=88909849";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=88909849";
import { useAuth } from "/src/app/auth-context.tsx";
import { PasswordField } from "/src/components/password-field.tsx";
import { ApiError } from "/src/types/api.ts";
import { errorMessage } from "/src/lib/error-message.ts";
import { loginSchema } from "/src/features/auth/schemas/auth-schemas.ts";
import { useLoginMutation } from "/src/features/auth/hooks/use-auth-mutations.ts";
import { FormField } from "/src/features/auth/components/form-field.tsx";
export function LoginForm() {
  _s();
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const mutation = useLoginMutation();
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(loginSchema), mode: "onBlur" });
  const onSubmit = handleSubmit(async (values) => {
    try {
      const token = await mutation.mutateAsync(values);
      if (!token) throw new ApiError("Sunucu oturum anahtarı döndürmedi.", 500);
      signIn(token);
      navigate("/dashboard", { replace: true });
    } catch {
    }
  });
  const serverError = mutation.error ? errorMessage(mutation.error) : null;
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "card-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "YENİDEN MERHABA" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Tekrar hoş geldiniz" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Hesabınıza giriş yaparak kaldığınız yerden devam edin." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "auth-form", onSubmit, noValidate: true, children: [
      serverError && /* @__PURE__ */ jsxDEV("div", { className: "form-alert", role: "alert", children: serverError }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 42,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV(FormField, { label: "Kullanıcı adı", placeholder: "Kullanıcı adınızı girin", autoComplete: "username", registration: register("userName"), error: errors.userName?.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PasswordField, { label: "Şifre", placeholder: "Şifrenizi girin", autoComplete: "current-password", registration: register("password"), error: errors.password?.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-meta", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Hesabınız güvende" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 45,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "secure-dot" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 45,
          columnNumber: 66
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "primary-button", type: "submit", disabled: mutation.isPending, children: mutation.isPending ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 47,
          columnNumber: 35
        }, this),
        " Giriş yapılıyor"
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 47,
        columnNumber: 33
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        "Giriş yap ",
        /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 47,
          columnNumber: 97
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 47,
        columnNumber: 85
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-divider", children: /* @__PURE__ */ jsxDEV("span", { children: "veya" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 49,
        columnNumber: 39
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "secondary-button", type: "button", disabled: true, title: "GitHub ile giriş yakında eklenecek", children: [
        /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("path", { fill: "currentColor", d: "M12 .9a11.1 11.1 0 0 0-3.51 21.63c.55.1.76-.24.76-.54v-2.1c-3.1.67-3.75-1.31-3.75-1.31-.5-1.28-1.24-1.62-1.24-1.62-1.01-.7.08-.69.08-.69 1.12.08 1.7 1.15 1.7 1.15.99 1.7 2.6 1.21 3.24.92.1-.72.39-1.21.7-1.49-2.48-.28-5.09-1.24-5.09-5.52 0-1.22.44-2.22 1.15-3-.11-.28-.5-1.42.11-2.96 0 0 .94-.3 3.06 1.15a10.6 10.6 0 0 1 5.57 0c2.13-1.45 3.06-1.15 3.06-1.15.61 1.54.23 2.68.12 2.96.72.78 1.15 1.78 1.15 3 0 4.3-2.61 5.24-5.1 5.51.4.34.75 1.02.75 2.06v3.09c0 .3.2.65.77.54A11.1 11.1 0 0 0 12 .9Z" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 51,
          columnNumber: 55
        }, this) }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        "GitHub ile giriş yap ",
        /* @__PURE__ */ jsxDEV("span", { className: "soon-label", children: "Yakında" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 52,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 50,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-switch", children: [
      "Henüz hesabınız yok mu? ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/register", children: [
        "Hesap oluşturun ",
        /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
          lineNumber: 55,
          columnNumber: 95
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
        lineNumber: 55,
        columnNumber: 58
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_s(LoginForm, "4aMisCZi/EEB7RWqvagCxNK1ERs=", false, function() {
  return [useNavigate, useAuth, useLoginMutation, useForm];
});
_c = LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/auth/components/login-form.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NRLFNBVXdCLFVBVnhCOztBQXBDUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLGlCQUFpQjtBQUtuQixnQkFBU0MsWUFBWTtBQUFBQyxLQUFBO0FBQzFCLFFBQU1DLFdBQVdWLFlBQVk7QUFDN0IsUUFBTSxFQUFFVyxPQUFPLElBQUlWLFFBQVE7QUFDM0IsUUFBTVcsV0FBV04saUJBQWlCO0FBQ2xDLFFBQU0sRUFBRU8sVUFBVUMsY0FBY0MsV0FBVyxFQUFFQyxPQUFPLEVBQUUsSUFBSWxCLFFBQXFCLEVBQUVtQixVQUFVcEIsWUFBWVEsV0FBVyxHQUFHYSxNQUFNLFNBQVMsQ0FBQztBQUVySSxRQUFNQyxXQUFXTCxhQUFhLE9BQU9NLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU1DLFFBQVEsTUFBTVQsU0FBU1UsWUFBWUYsTUFBTTtBQUMvQyxVQUFJLENBQUNDLE1BQU8sT0FBTSxJQUFJbEIsU0FBUyxzQ0FBc0MsR0FBRztBQUN4RVEsYUFBT1UsS0FBSztBQUNaWCxlQUFTLGNBQWMsRUFBRWEsU0FBUyxLQUFLLENBQUM7QUFBQSxJQUMxQyxRQUFRO0FBQUEsSUFDTjtBQUFBLEVBRUosQ0FBQztBQUNELFFBQU1DLGNBQWNaLFNBQVNhLFFBQVFyQixhQUFhUSxTQUFTYSxLQUFLLElBQUk7QUFFcEUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxlQUFjLCtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDO0FBQUEsTUFDN0MsdUJBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDdkIsdUJBQUMsT0FBRSxzRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsU0FIM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFvQixZQUFVLE1BQ3ZERDtBQUFBQSxxQkFBZSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxNQUFLLFNBQVNBLHlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNEO0FBQUEsTUFDdEUsdUJBQUMsYUFBVSxPQUFNLGlCQUFnQixhQUFZLDJCQUEwQixjQUFhLFlBQVcsY0FBY1gsU0FBUyxVQUFVLEdBQUcsT0FBT0csT0FBT1UsVUFBVUMsV0FBM0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSztBQUFBLE1BQ25LLHVCQUFDLGlCQUFjLE9BQU0sU0FBUSxhQUFZLG1CQUFrQixjQUFhLG9CQUFtQixjQUFjZCxTQUFTLFVBQVUsR0FBRyxPQUFPRyxPQUFPWSxVQUFVRCxXQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStKO0FBQUEsTUFDL0osdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSwrQkFBQyxVQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUFPLHVCQUFDLFVBQUssV0FBVSxnQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Y7QUFBQSxNQUN4Rix1QkFBQyxZQUFPLFdBQVUsa0JBQWlCLE1BQUssVUFBUyxVQUFVZixTQUFTaUIsV0FDakVqQixtQkFBU2lCLFlBQVksbUNBQUU7QUFBQSwrQkFBQyxVQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQUc7QUFBQSxXQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDLElBQU0sbUNBQUU7QUFBQTtBQUFBLFFBQVUsdUJBQUMsVUFBSyxlQUFZLFFBQU8saUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxXQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDLEtBRHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGlDQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxNQUMvQyx1QkFBQyxZQUFPLFdBQVUsb0JBQW1CLE1BQUssVUFBUyxVQUFRLE1BQUMsT0FBTSxzQ0FDaEU7QUFBQSwrQkFBQyxTQUFJLFNBQVEsYUFBWSxlQUFZLFFBQU8saUNBQUMsVUFBSyxNQUFLLGdCQUFlLEdBQUUsbWZBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMmdCLEtBQXZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlqQjtBQUFBLFFBQUs7QUFBQSxRQUN6aUIsdUJBQUMsVUFBSyxXQUFVLGNBQWEsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxXQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLGVBQWM7QUFBQTtBQUFBLE1BQXdCLHVCQUFDLFFBQUssSUFBRyxhQUFZO0FBQUE7QUFBQSxRQUFnQix1QkFBQyxVQUFLLGVBQVksUUFBTyxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFdBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxTQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdJO0FBQUEsT0FwQmxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQkE7QUFFSjtBQUFDcEIsR0ExQ2VELFdBQVM7QUFBQSxVQUNOUixhQUNFQyxTQUNGSyxrQkFDeUNSLE9BQU87QUFBQTtBQUFBLEtBSm5EVTtBQUFTLElBQUFzQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ6b2RSZXNvbHZlciIsInVzZUZvcm0iLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwiUGFzc3dvcmRGaWVsZCIsIkFwaUVycm9yIiwiZXJyb3JNZXNzYWdlIiwibG9naW5TY2hlbWEiLCJ1c2VMb2dpbk11dGF0aW9uIiwiRm9ybUZpZWxkIiwiTG9naW5Gb3JtIiwiX3MiLCJuYXZpZ2F0ZSIsInNpZ25JbiIsIm11dGF0aW9uIiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJyZXNvbHZlciIsIm1vZGUiLCJvblN1Ym1pdCIsInZhbHVlcyIsInRva2VuIiwibXV0YXRlQXN5bmMiLCJyZXBsYWNlIiwic2VydmVyRXJyb3IiLCJlcnJvciIsInVzZXJOYW1lIiwibWVzc2FnZSIsInBhc3N3b3JkIiwiaXNQZW5kaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibG9naW4tZm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXBwL2F1dGgtY29udGV4dCdcbmltcG9ydCB7IFBhc3N3b3JkRmllbGQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3Bhc3N3b3JkLWZpZWxkJ1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi8uLi90eXBlcy9hcGknXG5pbXBvcnQgeyBlcnJvck1lc3NhZ2UgfSBmcm9tICcuLi8uLi8uLi9saWIvZXJyb3ItbWVzc2FnZSdcbmltcG9ydCB7IGxvZ2luU2NoZW1hIH0gZnJvbSAnLi4vc2NoZW1hcy9hdXRoLXNjaGVtYXMnXG5pbXBvcnQgdHlwZSB7IHogfSBmcm9tICd6b2QnXG5pbXBvcnQgeyB1c2VMb2dpbk11dGF0aW9uIH0gZnJvbSAnLi4vaG9va3MvdXNlLWF1dGgtbXV0YXRpb25zJ1xuaW1wb3J0IHsgRm9ybUZpZWxkIH0gZnJvbSAnLi9mb3JtLWZpZWxkJ1xuXG50eXBlIExvZ2luVmFsdWVzID0gei5pbmZlcjx0eXBlb2YgbG9naW5TY2hlbWE+XG5cbi8qKiBHaXJpxZ8gYmlsZ2lsZXJpbmkgZG/En3J1bGFyLCBvdHVydW0gYcOnYXIgdmUgZGFzaGJvYXJkJ2EgecO2bmxlbmRpcmlyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIExvZ2luRm9ybSgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgc2lnbkluIH0gPSB1c2VBdXRoKClcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VMb2dpbk11dGF0aW9uKClcbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBmb3JtU3RhdGU6IHsgZXJyb3JzIH0gfSA9IHVzZUZvcm08TG9naW5WYWx1ZXM+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGxvZ2luU2NoZW1hKSwgbW9kZTogJ29uQmx1cicgfSlcblxuICBjb25zdCBvblN1Ym1pdCA9IGhhbmRsZVN1Ym1pdChhc3luYyAodmFsdWVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRva2VuID0gYXdhaXQgbXV0YXRpb24ubXV0YXRlQXN5bmModmFsdWVzKVxuICAgICAgaWYgKCF0b2tlbikgdGhyb3cgbmV3IEFwaUVycm9yKCdTdW51Y3Ugb3R1cnVtIGFuYWh0YXLEsSBkw7ZuZMO8cm1lZGkuJywgNTAwKVxuICAgICAgc2lnbkluKHRva2VuKVxuICAgICAgbmF2aWdhdGUoJy9kYXNoYm9hcmQnLCB7IHJlcGxhY2U6IHRydWUgfSlcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIE11dGF0aW9uIGhhdGFzxLEgYcWfYcSfxLFkYSBnw7x2ZW5saSB2ZSBrdWxsYW7EsWPEsSBkb3N0dSBiacOnaW1kZSBnw7ZzdGVyaWxpci5cbiAgICB9XG4gIH0pXG4gIGNvbnN0IHNlcnZlckVycm9yID0gbXV0YXRpb24uZXJyb3IgPyBlcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpIDogbnVsbFxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNhcmRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1oZWFkaW5nXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcmQta2lja2VyXCI+WUVOxLBERU4gTUVSSEFCQTwvc3Bhbj5cbiAgICAgICAgPGgyPlRla3JhciBob8WfIGdlbGRpbml6PC9oMj5cbiAgICAgICAgPHA+SGVzYWLEsW7EsXphIGdpcmnFnyB5YXBhcmFrIGthbGTEscSfxLFuxLF6IHllcmRlbiBkZXZhbSBlZGluLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiYXV0aC1mb3JtXCIgb25TdWJtaXQ9e29uU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICB7c2VydmVyRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWFsZXJ0XCIgcm9sZT1cImFsZXJ0XCI+e3NlcnZlckVycm9yfTwvZGl2Pn1cbiAgICAgICAgPEZvcm1GaWVsZCBsYWJlbD1cIkt1bGxhbsSxY8SxIGFkxLFcIiBwbGFjZWhvbGRlcj1cIkt1bGxhbsSxY8SxIGFkxLFuxLF6xLEgZ2lyaW5cIiBhdXRvQ29tcGxldGU9XCJ1c2VybmFtZVwiIHJlZ2lzdHJhdGlvbj17cmVnaXN0ZXIoJ3VzZXJOYW1lJyl9IGVycm9yPXtlcnJvcnMudXNlck5hbWU/Lm1lc3NhZ2V9IC8+XG4gICAgICAgIDxQYXNzd29yZEZpZWxkIGxhYmVsPVwixZ5pZnJlXCIgcGxhY2Vob2xkZXI9XCLFnmlmcmVuaXppIGdpcmluXCIgYXV0b0NvbXBsZXRlPVwiY3VycmVudC1wYXNzd29yZFwiIHJlZ2lzdHJhdGlvbj17cmVnaXN0ZXIoJ3Bhc3N3b3JkJyl9IGVycm9yPXtlcnJvcnMucGFzc3dvcmQ/Lm1lc3NhZ2V9IC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1tZXRhXCI+PHNwYW4+SGVzYWLEsW7EsXogZ8O8dmVuZGU8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwic2VjdXJlLWRvdFwiIC8+PC9kaXY+XG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ30+XG4gICAgICAgICAge211dGF0aW9uLmlzUGVuZGluZyA/IDw+PHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiIC8+IEdpcmnFnyB5YXDEsWzEsXlvcjwvPiA6IDw+R2lyacWfIHlhcCA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7ihpI8L3NwYW4+PC8+fVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWRpdmlkZXJcIj48c3Bhbj52ZXlhPC9zcGFuPjwvZGl2PlxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNlY29uZGFyeS1idXR0b25cIiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQgdGl0bGU9XCJHaXRIdWIgaWxlIGdpcmnFnyB5YWvEsW5kYSBla2xlbmVjZWtcIj5cbiAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48cGF0aCBmaWxsPVwiY3VycmVudENvbG9yXCIgZD1cIk0xMiAuOWExMS4xIDExLjEgMCAwIDAtMy41MSAyMS42M2MuNTUuMS43Ni0uMjQuNzYtLjU0di0yLjFjLTMuMS42Ny0zLjc1LTEuMzEtMy43NS0xLjMxLS41LTEuMjgtMS4yNC0xLjYyLTEuMjQtMS42Mi0xLjAxLS43LjA4LS42OS4wOC0uNjkgMS4xMi4wOCAxLjcgMS4xNSAxLjcgMS4xNS45OSAxLjcgMi42IDEuMjEgMy4yNC45Mi4xLS43Mi4zOS0xLjIxLjctMS40OS0yLjQ4LS4yOC01LjA5LTEuMjQtNS4wOS01LjUyIDAtMS4yMi40NC0yLjIyIDEuMTUtMy0uMTEtLjI4LS41LTEuNDIuMTEtMi45NiAwIDAgLjk0LS4zIDMuMDYgMS4xNWExMC42IDEwLjYgMCAwIDEgNS41NyAwYzIuMTMtMS40NSAzLjA2LTEuMTUgMy4wNi0xLjE1LjYxIDEuNTQuMjMgMi42OC4xMiAyLjk2LjcyLjc4IDEuMTUgMS43OCAxLjE1IDMgMCA0LjMtMi42MSA1LjI0LTUuMSA1LjUxLjQuMzQuNzUgMS4wMi43NSAyLjA2djMuMDljMCAuMy4yLjY1Ljc3LjU0QTExLjEgMTEuMSAwIDAgMCAxMiAuOVpcIi8+PC9zdmc+XG4gICAgICAgICAgR2l0SHViIGlsZSBnaXJpxZ8geWFwIDxzcGFuIGNsYXNzTmFtZT1cInNvb24tbGFiZWxcIj5ZYWvEsW5kYTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN3aXRjaFwiPkhlbsO8eiBoZXNhYsSxbsSxeiB5b2sgbXU/IDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCI+SGVzYXAgb2x1xZ90dXJ1biA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7ihpI8L3NwYW4+PC9MaW5rPjwvcD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy9hdXRoL2NvbXBvbmVudHMvbG9naW4tZm9ybS50c3gifQ==