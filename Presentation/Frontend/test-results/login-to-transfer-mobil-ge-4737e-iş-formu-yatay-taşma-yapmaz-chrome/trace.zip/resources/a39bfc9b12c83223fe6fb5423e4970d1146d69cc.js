import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/toast-provider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=88909849"; const createContext = __vite__cjsImport1_react["createContext"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useContext = __vite__cjsImport1_react["useContext"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { CheckCircle2, CircleAlert, X } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
const ToastContext = createContext(null);
export function ToastProvider({ children }) {
  _s();
  const [items, setItems] = useState([]);
  const showToast = useCallback((message, kind = "success") => {
    const id = Date.now() + Math.random();
    setItems((current) => [...current.slice(-2), { id, message, kind }]);
    window.setTimeout(() => setItems((current) => current.filter((item) => item.id !== id)), 4500);
  }, []);
  const value = useMemo(() => ({ showToast }), [showToast]);
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value, children: [
    children,
    /* @__PURE__ */ jsxDEV("div", { className: "toast-region", "aria-label": "Bildirimler", children: items.map((item) => /* @__PURE__ */ jsxDEV("div", { className: `toast-item ${item.kind}`, role: item.kind === "error" ? "alert" : "status", children: [
      /* @__PURE__ */ jsxDEV("span", { children: item.kind === "error" ? /* @__PURE__ */ jsxDEV(CircleAlert, { size: 18 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 271
      }, this) : /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 18 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 299
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 240
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: item.message }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 333
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", "aria-label": "Bildirimi kapat", onClick: () => setItems((current) => current.filter((entry) => entry.id !== item.id)), children: /* @__PURE__ */ jsxDEV(X, { size: 15 }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 492
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
        lineNumber: 18,
        columnNumber: 354
      }, this)
    ] }, item.id, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
      lineNumber: 18,
      columnNumber: 133
    }, this)) }, void 0, false, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
      lineNumber: 18,
      columnNumber: 57
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
}
_s(ToastProvider, "HUlEyasyJzRHrmhThYv7fdVhf6I=");
_c = ToastProvider;
export function useToast() {
  _s2();
  const value = useContext(ToastContext);
  if (!value) throw new Error("useToast, ToastProvider içinde kullanılmalıdır.");
  return value;
}
_s2(useToast, "ksutO2/Ix3UeCrGnhyM+QEP505Y=");
var _c;
$RefreshReg$(_c, "ToastProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/components/toast-provider.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUI4UTs7QUFqQjlRLFNBQVNBLGVBQWVDLGFBQWFDLFlBQVlDLFNBQVNDLGdCQUF3QztBQUNsRyxTQUFTQyxjQUFjQyxhQUFhQyxTQUFTO0FBSzdDLE1BQU1DLGVBQWVSLGNBQStCLElBQUk7QUFHakQsZ0JBQVNTLGNBQWMsRUFBRUMsU0FBNEIsR0FBRztBQUFBQyxLQUFBO0FBQzdELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJVCxTQUFzQixFQUFFO0FBQ2xELFFBQU1VLFlBQVliLFlBQVksQ0FBQ2MsU0FBaUJDLE9BQWtCLGNBQWM7QUFDOUUsVUFBTUMsS0FBS0MsS0FBS0MsSUFBSSxJQUFJQyxLQUFLQyxPQUFPO0FBQ3BDUixhQUFTLENBQUNTLFlBQVksQ0FBQyxHQUFHQSxRQUFRQyxNQUFNLEVBQUUsR0FBRyxFQUFFTixJQUFJRixTQUFTQyxLQUFLLENBQUMsQ0FBQztBQUNuRVEsV0FBT0MsV0FBVyxNQUFNWixTQUFTLENBQUNTLFlBQVlBLFFBQVFJLE9BQU8sQ0FBQ0MsU0FBU0EsS0FBS1YsT0FBT0EsRUFBRSxDQUFDLEdBQUcsSUFBSTtBQUFBLEVBQy9GLEdBQUcsRUFBRTtBQUNMLFFBQU1XLFFBQVF6QixRQUFRLE9BQU8sRUFBRVcsVUFBVSxJQUFJLENBQUNBLFNBQVMsQ0FBQztBQUN4RCxTQUFPLHVCQUFDLGFBQWEsVUFBYixFQUFzQixPQUFlSjtBQUFBQTtBQUFBQSxJQUFTLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxjQUFXLGVBQWVFLGdCQUFNaUIsSUFBSSxDQUFDRixTQUFTLHVCQUFDLFNBQUksV0FBVyxjQUFjQSxLQUFLWCxJQUFJLElBQWtCLE1BQU1XLEtBQUtYLFNBQVMsVUFBVSxVQUFVLFVBQVU7QUFBQSw2QkFBQyxVQUFNVyxlQUFLWCxTQUFTLFVBQVUsdUJBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0IsSUFBTSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUIsS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRjtBQUFBLE1BQU8sdUJBQUMsT0FBR1csZUFBS1osV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFBSSx1QkFBQyxZQUFPLE1BQUssVUFBUyxjQUFXLG1CQUFrQixTQUFTLE1BQU1GLFNBQVMsQ0FBQ1MsWUFBWUEsUUFBUUksT0FBTyxDQUFDSSxVQUFVQSxNQUFNYixPQUFPVSxLQUFLVixFQUFFLENBQUMsR0FBRyxpQ0FBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksS0FBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5SjtBQUFBLFNBQXRVVSxLQUFLVixJQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStYLENBQU0sS0FBamQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtZDtBQUFBLE9BQWxnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdnQjtBQUNqaEI7QUFHQU4sR0FaZ0JGLGVBQWE7QUFBQSxLQUFiQTtBQWFULGdCQUFTc0IsV0FBVztBQUFBQyxNQUFBO0FBQ3pCLFFBQU1KLFFBQVExQixXQUFXTSxZQUFZO0FBQ3JDLE1BQUksQ0FBQ29CLE1BQU8sT0FBTSxJQUFJSyxNQUFNLGlEQUFpRDtBQUM3RSxTQUFPTDtBQUNUO0FBQUNJLElBSmVELFVBQVE7QUFBQSxJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ2hlY2tDaXJjbGUyIiwiQ2lyY2xlQWxlcnQiLCJYIiwiVG9hc3RDb250ZXh0IiwiVG9hc3RQcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJpdGVtcyIsInNldEl0ZW1zIiwic2hvd1RvYXN0IiwibWVzc2FnZSIsImtpbmQiLCJpZCIsIkRhdGUiLCJub3ciLCJNYXRoIiwicmFuZG9tIiwiY3VycmVudCIsInNsaWNlIiwid2luZG93Iiwic2V0VGltZW91dCIsImZpbHRlciIsIml0ZW0iLCJ2YWx1ZSIsIm1hcCIsImVudHJ5IiwidXNlVG9hc3QiLCJfczIiLCJFcnJvciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInRvYXN0LXByb3ZpZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlTWVtbywgdXNlU3RhdGUsIHR5cGUgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENoZWNrQ2lyY2xlMiwgQ2lyY2xlQWxlcnQsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbnR5cGUgVG9hc3RLaW5kID0gJ3N1Y2Nlc3MnIHwgJ2Vycm9yJ1xudHlwZSBUb2FzdEl0ZW0gPSB7IGlkOiBudW1iZXI7IG1lc3NhZ2U6IHN0cmluZzsga2luZDogVG9hc3RLaW5kIH1cbnR5cGUgVG9hc3RBcGkgPSB7IHNob3dUb2FzdDogKG1lc3NhZ2U6IHN0cmluZywga2luZD86IFRvYXN0S2luZCkgPT4gdm9pZCB9XG5jb25zdCBUb2FzdENvbnRleHQgPSBjcmVhdGVDb250ZXh0PFRvYXN0QXBpIHwgbnVsbD4obnVsbClcblxuLyoqIEvEsXNhIGJhxZ9hcsSxIHZlIGhhdGEgYmlsZGlyaW1sZXJpbmkgZXJpxZ9pbGViaWxpciBiacOnaW1kZSB1eWd1bGFtYSDDp2FwxLFuZGEgc3VuYXIuICovXG5leHBvcnQgZnVuY3Rpb24gVG9hc3RQcm92aWRlcih7IGNoaWxkcmVuIH06IFByb3BzV2l0aENoaWxkcmVuKSB7XG4gIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8VG9hc3RJdGVtW10+KFtdKVxuICBjb25zdCBzaG93VG9hc3QgPSB1c2VDYWxsYmFjaygobWVzc2FnZTogc3RyaW5nLCBraW5kOiBUb2FzdEtpbmQgPSAnc3VjY2VzcycpID0+IHtcbiAgICBjb25zdCBpZCA9IERhdGUubm93KCkgKyBNYXRoLnJhbmRvbSgpXG4gICAgc2V0SXRlbXMoKGN1cnJlbnQpID0+IFsuLi5jdXJyZW50LnNsaWNlKC0yKSwgeyBpZCwgbWVzc2FnZSwga2luZCB9XSlcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRJdGVtcygoY3VycmVudCkgPT4gY3VycmVudC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uaWQgIT09IGlkKSksIDQ1MDApXG4gIH0sIFtdKVxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oKCkgPT4gKHsgc2hvd1RvYXN0IH0pLCBbc2hvd1RvYXN0XSlcbiAgcmV0dXJuIDxUb2FzdENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PGRpdiBjbGFzc05hbWU9XCJ0b2FzdC1yZWdpb25cIiBhcmlhLWxhYmVsPVwiQmlsZGlyaW1sZXJcIj57aXRlbXMubWFwKChpdGVtKSA9PiA8ZGl2IGNsYXNzTmFtZT17YHRvYXN0LWl0ZW0gJHtpdGVtLmtpbmR9YH0ga2V5PXtpdGVtLmlkfSByb2xlPXtpdGVtLmtpbmQgPT09ICdlcnJvcicgPyAnYWxlcnQnIDogJ3N0YXR1cyd9PjxzcGFuPntpdGVtLmtpbmQgPT09ICdlcnJvcicgPyA8Q2lyY2xlQWxlcnQgc2l6ZT17MTh9IC8+IDogPENoZWNrQ2lyY2xlMiBzaXplPXsxOH0gLz59PC9zcGFuPjxwPntpdGVtLm1lc3NhZ2V9PC9wPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9XCJCaWxkaXJpbWkga2FwYXRcIiBvbkNsaWNrPXsoKSA9PiBzZXRJdGVtcygoY3VycmVudCkgPT4gY3VycmVudC5maWx0ZXIoKGVudHJ5KSA9PiBlbnRyeS5pZCAhPT0gaXRlbS5pZCkpfT48WCBzaXplPXsxNX0gLz48L2J1dHRvbj48L2Rpdj4pfTwvZGl2PjwvVG9hc3RDb250ZXh0LlByb3ZpZGVyPlxufVxuXG4vKiogQmlsZGlyaW0gc2HEn2xhecSxY8Sxc8SxbsSxIGt1bGxhbmFuIGNvbXBvbmVudCdlIGvEsXNhIHRvYXN0IGfDtm5kZXJtZSBpxZ9sZXZpIHZlcmlyLiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LXJlZnJlc2gvb25seS1leHBvcnQtY29tcG9uZW50c1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvYXN0KCkge1xuICBjb25zdCB2YWx1ZSA9IHVzZUNvbnRleHQoVG9hc3RDb250ZXh0KVxuICBpZiAoIXZhbHVlKSB0aHJvdyBuZXcgRXJyb3IoJ3VzZVRvYXN0LCBUb2FzdFByb3ZpZGVyIGnDp2luZGUga3VsbGFuxLFsbWFsxLFkxLFyLicpXG4gIHJldHVybiB2YWx1ZVxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3RvYXN0LXByb3ZpZGVyLnRzeCJ9