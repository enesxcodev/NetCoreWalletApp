import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transfer/transfer-page.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88909849"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=88909849";
import { ArrowRight, Send } from "/node_modules/.vite/deps/lucide-react.js?v=88909849";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=88909849"; const useState = __vite__cjsImport3_react["useState"];
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=88909849";
import { formatMoney } from "/src/lib/format.ts";
import { ApiError } from "/src/types/api.ts";
import { errorMessage } from "/src/lib/error-message.ts";
import { useWallet } from "/src/features/wallet/hooks.ts";
import { useTransfer } from "/src/features/transfer/hooks.ts";
import { useToast } from "/src/components/toast-provider.tsx";
import { transferSchema } from "/src/features/transfer/schema.ts";
export function TransferPage() {
  _s();
  const wallet = useWallet();
  const transfer = useTransfer();
  const { showToast } = useToast();
  const [pending, setPending] = useState(null);
  const [transactionId, setTransactionId] = useState(null);
  const { register, handleSubmit, reset, formState: { errors } } = useForm({ resolver: zodResolver(transferSchema), defaultValues: { description: "" } });
  const prepare = handleSubmit((values) => {
    transfer.reset();
    setTransactionId(null);
    setPending({ values, key: crypto.randomUUID() });
  });
  const confirm = async () => {
    if (!pending) return;
    try {
      setTransactionId(await transfer.mutateAsync({ values: pending.values, idempotencyKey: pending.key }));
      setPending(null);
      reset();
      showToast("Transfer başarıyla kaydedildi.");
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "content-stack narrow-content", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "card-kicker", children: "GÜVENLİ TRANSFER" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 26,
        columnNumber: 89
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: "Para gönderin" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 26,
        columnNumber: 142
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Alıcının cüzdan kodunu girin, tutarı kontrol edin ve onaylayın." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 26,
        columnNumber: 164
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
      lineNumber: 26,
      columnNumber: 56
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "form-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "large-action-icon lilac", children: /* @__PURE__ */ jsxDEV(Send, {}, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 27,
        columnNumber: 78
      }, this) }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 27,
        columnNumber: 37
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Transfer bilgileri" }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 27,
        columnNumber: 92
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "İşlem onaylanmadan önce bilgileri gözden geçirebilirsiniz." }, void 0, false, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 27,
        columnNumber: 119
      }, this),
      transactionId && /* @__PURE__ */ jsxDEV("div", { role: "status", className: "transfer-result", children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Transfer kaydedildi" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 28,
          columnNumber: 72
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "İşlem no: ",
          transactionId
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 28,
          columnNumber: 108
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 28,
        columnNumber: 25
      }, this),
      !pending ? /* @__PURE__ */ jsxDEV("form", { onSubmit: prepare, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "walletCode", children: "Alıcı cüzdan kodu" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 29,
          columnNumber: 55
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "walletCode", className: "plain-input", placeholder: "WLT-XXXXXXXX", "aria-invalid": Boolean(errors.walletCode), ...register("walletCode") }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 29,
          columnNumber: 108
        }, this),
        errors.walletCode && /* @__PURE__ */ jsxDEV("small", { className: "field-error", children: errors.walletCode.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 29,
          columnNumber: 276
        }, this),
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "transferAmount", children: "Tutar (₺)" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 30,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "amount-input", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "₺" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 30,
            columnNumber: 88
          }, this),
          /* @__PURE__ */ jsxDEV("input", { id: "transferAmount", inputMode: "decimal", placeholder: "0,00", "aria-invalid": Boolean(errors.amount), ...register("amount") }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 30,
            columnNumber: 102
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 30,
          columnNumber: 58
        }, this),
        errors.amount && /* @__PURE__ */ jsxDEV("small", { className: "field-error", children: errors.amount.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 30,
          columnNumber: 256
        }, this),
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "description", children: [
          "Açıklama ",
          /* @__PURE__ */ jsxDEV("span", { className: "optional-label", children: "İsteğe bağlı" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 31,
            columnNumber: 47
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 31,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "description", className: "plain-input", placeholder: "Örn. kira ödemesi", ...register("description") }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 31,
          columnNumber: 107
        }, this),
        errors.description && /* @__PURE__ */ jsxDEV("small", { className: "field-error", children: errors.description.message }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 31,
          columnNumber: 241
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "primary-button", type: "submit", children: [
          "Özeti görüntüle ",
          /* @__PURE__ */ jsxDEV(ArrowRight, { size: 17 }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 74
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 29,
        columnNumber: 19
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "transfer-confirm", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Transfer özeti" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 151
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Alıcı" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 179
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: pending.values.walletCode }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 197
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 174
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Gönderilecek tutar" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 252
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: formatMoney(pending.values.amount) }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 283
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 247
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Açıklama" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 347
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: pending.values.description || "Transfer" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 368
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 342
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Mevcut bakiye" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 438
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: wallet.data ? formatMoney(wallet.data.balance) : "Yükleniyor" }, void 0, false, {
            fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
            lineNumber: 32,
            columnNumber: 464
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 32,
          columnNumber: 433
        }, this),
        transfer.isError && /* @__PURE__ */ jsxDEV("div", { role: "alert", className: "form-alert", children: [
          errorMessage(transfer.error),
          transfer.error instanceof ApiError && transfer.error.status === 409 ? " Farklı işlem için yeni transfer başlatın." : " Durum belirsizse aynı isteği yeniden deneyin."
        ] }, void 0, true, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 33,
          columnNumber: 32
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "primary-button", type: "button", disabled: transfer.isPending || transfer.error instanceof ApiError && transfer.error.status === 409, onClick: () => void confirm(), children: transfer.isPending ? "Gönderiliyor..." : transfer.isError ? "Aynı transferi yeniden dene" : "Transferi onayla" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 34,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "text-button", type: "button", disabled: transfer.isPending, onClick: () => {
          setPending(null);
          transfer.reset();
        }, children: "Bilgileri düzenle" }, void 0, false, {
          fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
          lineNumber: 34,
          columnNumber: 313
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
        lineNumber: 32,
        columnNumber: 117
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
      lineNumber: 27,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
}
_s(TransferPage, "EImhlo+wb2K1EVEQGOovNSaS1t4=", false, function() {
  return [useWallet, useTransfer, useToast, useForm];
});
_c = TransferPage;
var _c;
$RefreshReg$(_c, "TransferPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "C:/Users/root/source/repos/Wallet/Presentation/Frontend/src/features/transfer/transfer-page.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJ3Rjs7QUF6QnhGLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyxZQUFZQyxZQUFZO0FBQ2pDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUEyQztBQUc3QyxnQkFBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQzdCLFFBQU1DLFNBQVNOLFVBQVU7QUFDekIsUUFBTU8sV0FBV04sWUFBWTtBQUM3QixRQUFNLEVBQUVPLFVBQVUsSUFBSU4sU0FBUztBQUMvQixRQUFNLENBQUNPLFNBQVNDLFVBQVUsSUFBSWYsU0FBeUQsSUFBSTtBQUMzRixRQUFNLENBQUNnQixlQUFlQyxnQkFBZ0IsSUFBSWpCLFNBQXdCLElBQUk7QUFDdEUsUUFBTSxFQUFFa0IsVUFBVUMsY0FBY0MsT0FBT0MsV0FBVyxFQUFFQyxPQUFPLEVBQUUsSUFBSXJCLFFBQTZFLEVBQUVzQixVQUFVMUIsWUFBWVcsY0FBYyxHQUFHZ0IsZUFBZSxFQUFFQyxhQUFhLEdBQUcsRUFBRSxDQUFDO0FBQzNOLFFBQU1DLFVBQVVQLGFBQWEsQ0FBQ1EsV0FBVztBQUFFZixhQUFTUSxNQUFNO0FBQUdILHFCQUFpQixJQUFJO0FBQUdGLGVBQVcsRUFBRVksUUFBUUMsS0FBS0MsT0FBT0MsV0FBVyxFQUFFLENBQUM7QUFBQSxFQUFFLENBQUM7QUFDdkksUUFBTUMsVUFBVSxZQUFZO0FBQzFCLFFBQUksQ0FBQ2pCLFFBQVM7QUFDZCxRQUFJO0FBQUVHLHVCQUFpQixNQUFNTCxTQUFTb0IsWUFBWSxFQUFFTCxRQUFRYixRQUFRYSxRQUFRTSxnQkFBZ0JuQixRQUFRYyxJQUFJLENBQUMsQ0FBQztBQUFHYixpQkFBVyxJQUFJO0FBQUdLLFlBQU07QUFBR1AsZ0JBQVUsZ0NBQWdDO0FBQUEsSUFBRSxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ2hNO0FBQ0EsU0FBTyx1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsMkJBQUMsWUFBTyxXQUFVLGdCQUFlO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGVBQWMsZ0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUFPLHVCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQUssdUJBQUMsT0FBRSwrRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsU0FBOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrTDtBQUFBLElBQ3JPLHVCQUFDLGFBQVEsV0FBVSxjQUFhO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUEwQixpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSyxLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFBTSx1QkFBQyxRQUFHLGtDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUFLLHVCQUFDLE9BQUUsMEVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzVLRyxpQkFBaUIsdUJBQUMsU0FBSSxNQUFLLFVBQVMsV0FBVSxtQkFBa0I7QUFBQSwrQkFBQyxZQUFPLG1DQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUFTLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQVdBO0FBQUFBLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlIO0FBQUEsTUFDMUksQ0FBQ0YsVUFBVSx1QkFBQyxVQUFLLFVBQVVZLFNBQVMsWUFBVSxNQUFDO0FBQUEsK0JBQUMsV0FBTSxTQUFRLGNBQWEsaUNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUFRLHVCQUFDLFdBQU0sSUFBRyxjQUFhLFdBQVUsZUFBYyxhQUFZLGdCQUFlLGdCQUFjUSxRQUFRWixPQUFPYSxVQUFVLEdBQUcsR0FBSWpCLFNBQVMsWUFBWSxLQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStJO0FBQUEsUUFBSUksT0FBT2EsY0FBYyx1QkFBQyxXQUFNLFdBQVUsZUFBZWIsaUJBQU9hLFdBQVdDLFdBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxRQUNyVSx1QkFBQyxXQUFNLFNBQVEsa0JBQWlCLHlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsUUFBUSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU87QUFBQSxVQUFPLHVCQUFDLFdBQU0sSUFBRyxrQkFBaUIsV0FBVSxXQUFVLGFBQVksUUFBTyxnQkFBY0YsUUFBUVosT0FBT2UsTUFBTSxHQUFHLEdBQUluQixTQUFTLFFBQVEsS0FBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0g7QUFBQSxhQUEzSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThLO0FBQUEsUUFBT0ksT0FBT2UsVUFBVSx1QkFBQyxXQUFNLFdBQVUsZUFBZWYsaUJBQU9lLE9BQU9ELFdBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUM3Uyx1QkFBQyxXQUFNLFNBQVEsZUFBYztBQUFBO0FBQUEsVUFBUyx1QkFBQyxVQUFLLFdBQVUsa0JBQWlCLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLGFBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUFRLHVCQUFDLFdBQU0sSUFBRyxlQUFjLFdBQVUsZUFBYyxhQUFZLHFCQUFvQixHQUFJbEIsU0FBUyxhQUFhLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEc7QUFBQSxRQUFJSSxPQUFPRyxlQUFlLHVCQUFDLFdBQU0sV0FBVSxlQUFlSCxpQkFBT0csWUFBWVcsV0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFFBQ25TLHVCQUFDLFlBQU8sV0FBVSxrQkFBaUIsTUFBSyxVQUFTO0FBQUE7QUFBQSxVQUFnQix1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxhQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FIL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUd3RixJQUFVLHVCQUFDLFNBQUksV0FBVSxvQkFBbUI7QUFBQSwrQkFBQyxRQUFHLDhCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUFLLHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVc7QUFBQSxVQUFPLHVCQUFDLFlBQVF0QixrQkFBUWEsT0FBT1EsY0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxhQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFBTSx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQU8sdUJBQUMsWUFBUWpDLHNCQUFZWSxRQUFRYSxPQUFPVSxNQUFNLEtBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsYUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFFBQU0sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFVBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLFVBQU8sdUJBQUMsWUFBUXZCLGtCQUFRYSxPQUFPRixlQUFlLGNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBQU0sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUFPLHVCQUFDLFlBQVFkLGlCQUFPMkIsT0FBT3BDLFlBQVlTLE9BQU8yQixLQUFLQyxPQUFPLElBQUksZ0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsYUFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRztBQUFBLFFBQ3BoQjNCLFNBQVM0QixXQUFXLHVCQUFDLFNBQUksTUFBSyxTQUFRLFdBQVUsY0FBY3BDO0FBQUFBLHVCQUFhUSxTQUFTNkIsS0FBSztBQUFBLFVBQUc3QixTQUFTNkIsaUJBQWlCdEMsWUFBWVMsU0FBUzZCLE1BQU1DLFdBQVcsTUFBTSwrQ0FBK0M7QUFBQSxhQUE3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThPO0FBQUEsUUFDblEsdUJBQUMsWUFBTyxXQUFVLGtCQUFpQixNQUFLLFVBQVMsVUFBVTlCLFNBQVMrQixhQUFjL0IsU0FBUzZCLGlCQUFpQnRDLFlBQVlTLFNBQVM2QixNQUFNQyxXQUFXLEtBQU0sU0FBUyxNQUFNLEtBQUtYLFFBQVEsR0FBSW5CLG1CQUFTK0IsWUFBWSxvQkFBb0IvQixTQUFTNEIsVUFBVSxnQ0FBZ0Msc0JBQXBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdVM7QUFBQSxRQUFTLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxVQUFVNUIsU0FBUytCLFdBQVcsU0FBUyxNQUFNO0FBQUU1QixxQkFBVyxJQUFJO0FBQUdILG1CQUFTUSxNQUFNO0FBQUEsUUFBRSxHQUFHLGlDQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9KO0FBQUEsV0FGMVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUc1RztBQUFBLFNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0FWSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV1A7QUFDRjtBQUFDVixHQXhCZUQsY0FBWTtBQUFBLFVBQ1hKLFdBQ0VDLGFBQ0tDLFVBRzJDTixPQUFPO0FBQUE7QUFBQSxLQU4xRFE7QUFBWSxJQUFBbUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiem9kUmVzb2x2ZXIiLCJBcnJvd1JpZ2h0IiwiU2VuZCIsInVzZVN0YXRlIiwidXNlRm9ybSIsImZvcm1hdE1vbmV5IiwiQXBpRXJyb3IiLCJlcnJvck1lc3NhZ2UiLCJ1c2VXYWxsZXQiLCJ1c2VUcmFuc2ZlciIsInVzZVRvYXN0IiwidHJhbnNmZXJTY2hlbWEiLCJUcmFuc2ZlclBhZ2UiLCJfcyIsIndhbGxldCIsInRyYW5zZmVyIiwic2hvd1RvYXN0IiwicGVuZGluZyIsInNldFBlbmRpbmciLCJ0cmFuc2FjdGlvbklkIiwic2V0VHJhbnNhY3Rpb25JZCIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwicmVzZXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJyZXNvbHZlciIsImRlZmF1bHRWYWx1ZXMiLCJkZXNjcmlwdGlvbiIsInByZXBhcmUiLCJ2YWx1ZXMiLCJrZXkiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiY29uZmlybSIsIm11dGF0ZUFzeW5jIiwiaWRlbXBvdGVuY3lLZXkiLCJCb29sZWFuIiwid2FsbGV0Q29kZSIsIm1lc3NhZ2UiLCJhbW91bnQiLCJkYXRhIiwiYmFsYW5jZSIsImlzRXJyb3IiLCJlcnJvciIsInN0YXR1cyIsImlzUGVuZGluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInRyYW5zZmVyLXBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyBBcnJvd1JpZ2h0LCBTZW5kIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXG5pbXBvcnQgeyBmb3JtYXRNb25leSB9IGZyb20gJy4uLy4uL2xpYi9mb3JtYXQnXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uL3R5cGVzL2FwaSdcbmltcG9ydCB7IGVycm9yTWVzc2FnZSB9IGZyb20gJy4uLy4uL2xpYi9lcnJvci1tZXNzYWdlJ1xuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnLi4vd2FsbGV0L2hvb2tzJ1xuaW1wb3J0IHsgdXNlVHJhbnNmZXIgfSBmcm9tICcuL2hvb2tzJ1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3RvYXN0LXByb3ZpZGVyJ1xuaW1wb3J0IHsgdHJhbnNmZXJTY2hlbWEsIHR5cGUgVHJhbnNmZXJWYWx1ZXMgfSBmcm9tICcuL3NjaGVtYSdcblxuLyoqIFRyYW5zZmVyaSDDtm5jZSDDtnpldGxlcjsgYmVsaXJzaXogYcSfIGhhdGFzxLFuZGEgYXluxLEgaWRlbXBvdGVuY3kgYW5haHRhcsSxeWxhIHllbmlkZW4gZGVuZXIuICovXG5leHBvcnQgZnVuY3Rpb24gVHJhbnNmZXJQYWdlKCkge1xuICBjb25zdCB3YWxsZXQgPSB1c2VXYWxsZXQoKVxuICBjb25zdCB0cmFuc2ZlciA9IHVzZVRyYW5zZmVyKClcbiAgY29uc3QgeyBzaG93VG9hc3QgfSA9IHVzZVRvYXN0KClcbiAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGU8eyB2YWx1ZXM6IFRyYW5zZmVyVmFsdWVzOyBrZXk6IHN0cmluZyB9IHwgbnVsbD4obnVsbClcbiAgY29uc3QgW3RyYW5zYWN0aW9uSWQsIHNldFRyYW5zYWN0aW9uSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCByZXNldCwgZm9ybVN0YXRlOiB7IGVycm9ycyB9IH0gPSB1c2VGb3JtPGltcG9ydCgnem9kJykuaW5wdXQ8dHlwZW9mIHRyYW5zZmVyU2NoZW1hPiwgdW5rbm93biwgVHJhbnNmZXJWYWx1ZXM+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHRyYW5zZmVyU2NoZW1hKSwgZGVmYXVsdFZhbHVlczogeyBkZXNjcmlwdGlvbjogJycgfSB9KVxuICBjb25zdCBwcmVwYXJlID0gaGFuZGxlU3VibWl0KCh2YWx1ZXMpID0+IHsgdHJhbnNmZXIucmVzZXQoKTsgc2V0VHJhbnNhY3Rpb25JZChudWxsKTsgc2V0UGVuZGluZyh7IHZhbHVlcywga2V5OiBjcnlwdG8ucmFuZG9tVVVJRCgpIH0pIH0pXG4gIGNvbnN0IGNvbmZpcm0gPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFwZW5kaW5nKSByZXR1cm5cbiAgICB0cnkgeyBzZXRUcmFuc2FjdGlvbklkKGF3YWl0IHRyYW5zZmVyLm11dGF0ZUFzeW5jKHsgdmFsdWVzOiBwZW5kaW5nLnZhbHVlcywgaWRlbXBvdGVuY3lLZXk6IHBlbmRpbmcua2V5IH0pKTsgc2V0UGVuZGluZyhudWxsKTsgcmVzZXQoKTsgc2hvd1RvYXN0KCdUcmFuc2ZlciBiYcWfYXLEsXlsYSBrYXlkZWRpbGRpLicpIH0gY2F0Y2ggeyAvKiBBeW7EsSBpc3RlayDDtnpldGkgdmUgVVVJRCB5ZW5pZGVuIGRlbmVtZSBpw6dpbiBrb3J1bnVyLiAqLyB9XG4gIH1cbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudC1zdGFjayBuYXJyb3ctY29udGVudFwiPjxoZWFkZXIgY2xhc3NOYW1lPVwicGFnZS1oZWFkaW5nXCI+PHNwYW4gY2xhc3NOYW1lPVwiY2FyZC1raWNrZXJcIj5Hw5xWRU5MxLAgVFJBTlNGRVI8L3NwYW4+PGgxPlBhcmEgZ8O2bmRlcmluPC9oMT48cD5BbMSxY8SxbsSxbiBjw7x6ZGFuIGtvZHVudSBnaXJpbiwgdHV0YXLEsSBrb250cm9sIGVkaW4gdmUgb25heWxhecSxbi48L3A+PC9oZWFkZXI+XG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZm9ybS1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwibGFyZ2UtYWN0aW9uLWljb24gbGlsYWNcIj48U2VuZCAvPjwvZGl2PjxoMj5UcmFuc2ZlciBiaWxnaWxlcmk8L2gyPjxwPsSwxZ9sZW0gb25heWxhbm1hZGFuIMO2bmNlIGJpbGdpbGVyaSBnw7Z6ZGVuIGdlw6dpcmViaWxpcnNpbml6LjwvcD5cbiAgICAgIHt0cmFuc2FjdGlvbklkICYmIDxkaXYgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cInRyYW5zZmVyLXJlc3VsdFwiPjxzdHJvbmc+VHJhbnNmZXIga2F5ZGVkaWxkaTwvc3Ryb25nPjxzcGFuPsSwxZ9sZW0gbm86IHt0cmFuc2FjdGlvbklkfTwvc3Bhbj48L2Rpdj59XG4gICAgICB7IXBlbmRpbmcgPyA8Zm9ybSBvblN1Ym1pdD17cHJlcGFyZX0gbm9WYWxpZGF0ZT48bGFiZWwgaHRtbEZvcj1cIndhbGxldENvZGVcIj5BbMSxY8SxIGPDvHpkYW4ga29kdTwvbGFiZWw+PGlucHV0IGlkPVwid2FsbGV0Q29kZVwiIGNsYXNzTmFtZT1cInBsYWluLWlucHV0XCIgcGxhY2Vob2xkZXI9XCJXTFQtWFhYWFhYWFhcIiBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3JzLndhbGxldENvZGUpfSB7Li4ucmVnaXN0ZXIoJ3dhbGxldENvZGUnKX0gLz57ZXJyb3JzLndhbGxldENvZGUgJiYgPHNtYWxsIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2Vycm9ycy53YWxsZXRDb2RlLm1lc3NhZ2V9PC9zbWFsbD59XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwidHJhbnNmZXJBbW91bnRcIj5UdXRhciAo4oK6KTwvbGFiZWw+PGRpdiBjbGFzc05hbWU9XCJhbW91bnQtaW5wdXRcIj48c3Bhbj7igro8L3NwYW4+PGlucHV0IGlkPVwidHJhbnNmZXJBbW91bnRcIiBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgcGxhY2Vob2xkZXI9XCIwLDAwXCIgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9ycy5hbW91bnQpfSB7Li4ucmVnaXN0ZXIoJ2Ftb3VudCcpfSAvPjwvZGl2PntlcnJvcnMuYW1vdW50ICYmIDxzbWFsbCBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMuYW1vdW50Lm1lc3NhZ2V9PC9zbWFsbD59XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZGVzY3JpcHRpb25cIj5Bw6fEsWtsYW1hIDxzcGFuIGNsYXNzTmFtZT1cIm9wdGlvbmFsLWxhYmVsXCI+xLBzdGXEn2UgYmHEn2zEsTwvc3Bhbj48L2xhYmVsPjxpbnB1dCBpZD1cImRlc2NyaXB0aW9uXCIgY2xhc3NOYW1lPVwicGxhaW4taW5wdXRcIiBwbGFjZWhvbGRlcj1cIsOWcm4uIGtpcmEgw7ZkZW1lc2lcIiB7Li4ucmVnaXN0ZXIoJ2Rlc2NyaXB0aW9uJyl9IC8+e2Vycm9ycy5kZXNjcmlwdGlvbiAmJiA8c21hbGwgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57ZXJyb3JzLmRlc2NyaXB0aW9uLm1lc3NhZ2V9PC9zbWFsbD59XG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiB0eXBlPVwic3VibWl0XCI+w5Z6ZXRpIGfDtnLDvG50w7xsZSA8QXJyb3dSaWdodCBzaXplPXsxN30gLz48L2J1dHRvbj48L2Zvcm0+IDogPGRpdiBjbGFzc05hbWU9XCJ0cmFuc2Zlci1jb25maXJtXCI+PGgzPlRyYW5zZmVyIMO2emV0aTwvaDM+PGRpdj48c3Bhbj5BbMSxY8SxPC9zcGFuPjxzdHJvbmc+e3BlbmRpbmcudmFsdWVzLndhbGxldENvZGV9PC9zdHJvbmc+PC9kaXY+PGRpdj48c3Bhbj5Hw7ZuZGVyaWxlY2VrIHR1dGFyPC9zcGFuPjxzdHJvbmc+e2Zvcm1hdE1vbmV5KHBlbmRpbmcudmFsdWVzLmFtb3VudCl9PC9zdHJvbmc+PC9kaXY+PGRpdj48c3Bhbj5Bw6fEsWtsYW1hPC9zcGFuPjxzdHJvbmc+e3BlbmRpbmcudmFsdWVzLmRlc2NyaXB0aW9uIHx8ICdUcmFuc2Zlcid9PC9zdHJvbmc+PC9kaXY+PGRpdj48c3Bhbj5NZXZjdXQgYmFraXllPC9zcGFuPjxzdHJvbmc+e3dhbGxldC5kYXRhID8gZm9ybWF0TW9uZXkod2FsbGV0LmRhdGEuYmFsYW5jZSkgOiAnWcO8a2xlbml5b3InfTwvc3Ryb25nPjwvZGl2PlxuICAgICAgICAgIHt0cmFuc2Zlci5pc0Vycm9yICYmIDxkaXYgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZm9ybS1hbGVydFwiPntlcnJvck1lc3NhZ2UodHJhbnNmZXIuZXJyb3IpfXt0cmFuc2Zlci5lcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yICYmIHRyYW5zZmVyLmVycm9yLnN0YXR1cyA9PT0gNDA5ID8gJyBGYXJrbMSxIGnFn2xlbSBpw6dpbiB5ZW5pIHRyYW5zZmVyIGJhxZ9sYXTEsW4uJyA6ICcgRHVydW0gYmVsaXJzaXpzZSBheW7EsSBpc3RlxJ9pIHllbmlkZW4gZGVuZXlpbi4nfTwvZGl2Pn1cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInByaW1hcnktYnV0dG9uXCIgdHlwZT1cImJ1dHRvblwiIGRpc2FibGVkPXt0cmFuc2Zlci5pc1BlbmRpbmcgfHwgKHRyYW5zZmVyLmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgdHJhbnNmZXIuZXJyb3Iuc3RhdHVzID09PSA0MDkpfSBvbkNsaWNrPXsoKSA9PiB2b2lkIGNvbmZpcm0oKX0+e3RyYW5zZmVyLmlzUGVuZGluZyA/ICdHw7ZuZGVyaWxpeW9yLi4uJyA6IHRyYW5zZmVyLmlzRXJyb3IgPyAnQXluxLEgdHJhbnNmZXJpIHllbmlkZW4gZGVuZScgOiAnVHJhbnNmZXJpIG9uYXlsYSd9PC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9XCJ0ZXh0LWJ1dHRvblwiIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17dHJhbnNmZXIuaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB7IHNldFBlbmRpbmcobnVsbCk7IHRyYW5zZmVyLnJlc2V0KCkgfX0+QmlsZ2lsZXJpIGTDvHplbmxlPC9idXR0b24+XG4gICAgICAgIDwvZGl2Pn1cbiAgICA8L3NlY3Rpb24+XG4gIDwvZGl2PlxufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9yb290L3NvdXJjZS9yZXBvcy9XYWxsZXQvUHJlc2VudGF0aW9uL0Zyb250ZW5kL3NyYy9mZWF0dXJlcy90cmFuc2Zlci90cmFuc2Zlci1wYWdlLnRzeCJ9